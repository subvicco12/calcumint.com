import json,pathlib,hashlib,csv,collections,datetime
p=pathlib.Path(__file__).parent;b=p.parent/'source-verification-1482'
def read(path):return json.loads(path.read_text())
def write(name,d):(p/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
prior=read(b/'updated-evidence-readiness.json');matrix=read(b/'source-verification-matrix.json')['rows'];base=read(b/'baseline-readiness-register.json')
expected={r['masterId'] for r in prior['rows'] if r['allCitedURLsRelevantContentVerified']}
rows=[]
for name in ['finance-decisions.json','retirement-decisions.json','tax-decisions.json','other-decisions.json']:
 for raw in read(p/name):
  r=dict(raw);i=r['masterId'];packet=read(b/'baseline-packets'/f'{i:03}.json');a=packet['analysis']
  r['revisionEffectivePeriod']=r.pop('revision/effectiveperiod',r.get('revisionEffectivePeriod',None))
  r['actualEngineAcceptance']=r.pop('actualengineacceptance',False)
  r['approval']='PENDING';r['evidenceComplete']=False;r['sourceCompleteAcceptance']=False
  r['selectedContractApproved']=False;r['implementationBindingApproved']=False
  r['candidateFormula']=a.get('candidateFormula',a.get('proposedFormula'))
  r['baselinePacketSHA256']=hashlib.sha256((b/'baseline-packets'/f'{i:03}.json').read_bytes()).hexdigest()
  r['originalRemainingGaps']=packet['remainingGaps'];r['sourceReferences']=[{k:m[k] for k in ['sourceOrdinal','url','title','publisher','classification','observationRecordSHA256']} for m in matrix if i in m['catalogIds']]
  r['originalImplementationEvidence']=packet.get('implementationBinding',a.get('implementationBinding',a.get('engineBinding')))
  r['readinessClassification']='METHODOLOGY_PROPOSAL_PREPARED_DECISIONS_PENDING'
  r['retainedQualifiedReviewRequirement']=False
  r['qualifiedReviewClassificationMeaning']='Recommendation for full intended claims/applicability; not a new statutory-signature finding or amendment to the retained11 governance requirements.' if r['decisionClassification']=='QUALIFIED_REVIEW_REQUIRED' else 'Existing applicable governance and obligation screening still apply; no exemption inferred.'
  r['scopeAdopted']=False;r['fullProductScopePreserved']=True
  rows.append(r)
rows.sort(key=lambda r:r['masterId']);assert len(rows)==50 and {r['masterId'] for r in rows}==expected
counts=dict(collections.Counter(r['decisionClassification'] for r in rows))
register={'schemaVersion':1,'date':'2026-10-26','baselinePR':1482,'baselineSHA':'f8d85c8671daf8a621cf109a034d07e5639f85d6','inputZipSHA256':'72b28e4edb98c586d70402b5ca6361836bbffe2f06473f5a0acecba20beae2ae','status':'PROPOSALS_PREPARED_NOT_APPROVED','noNewBrowsing':True,'releaseHold':True,'summary':{'cases':50,'primaryDecisionCounts':counts,'purelyEngineeringResolvableCases':0,'casesWithEngineeringPreparationTasks':50,'evidenceComplete':0,'ownerApprovalsObtained':0,'actualEngineAcceptances':0,'retainedQualifiedRequirementsUnchanged':11},'classificationRule':'Primary decision is the next dominant dependency, not exclusive; additionalBlockers remain. Source readability is not source completeness. No case can be closed solely by engineering while its original contract and identity remain unselected.','rows':rows}
write('methodology-decision-register-50.json',register)
owner=[]
for r in rows:
 owner.append({'masterId':r['masterId'],'title':r['title'],'status':'PENDING','decisionVersion':'proposal-2026-10-26-1','primaryDependency':r['decisionClassification'],'proposedFirstContract':r['narrowestRecommendedScope'],'proposedDefaults':r['proposedDefaults'],'consequences':r['consequences'],'questions':r['ownerQuestions'],'ownerMayApprove':'Product scope, assumptions, input/output semantics and nonprescribed display choices only. Approval does not establish source validity, qualified competence, engine acceptance or publication.','fullScopePreserved':True,'approvedBy':None,'approvedAt':None,'approvedContractSHA256':None})
shared=[
 {'decisionId':'OWNER-01','coverage':'All50','proposal':'Require explicit currency, jurisdiction/profile and applicable period; no geolocation-based or browser-availability-based defaults. Version profile selection and reject unsupported scope with reason.','consequence':'Some cases require more input; prevents a wrong jurisdiction/rule pack from silently producing a plausible answer.'},
 {'decisionId':'OWNER-02','coverage':'All50, except source-prescribed rules override','proposal':'For illustrative supplied-input arithmetic: decimal/rational intermediates, final currency display at explicitly selected currency minor-unit precision, percentages4decimals and GPA3decimals, half-up ties. No intermediate rounding unless the approved method prescribes it. Keep unrounded values for boundary comparisons.','consequence':'This is a proposed display contract, not a tax, lender, provider or institutional rounding rule. Prescribed rounding must be sourced before rule-pack acceptance; changing historical rounding requires a new immutable technical revision.'},
 {'decisionId':'OWNER-03','coverage':'All50','proposal':'Accept narrow named profiles as components/first implementation contracts only; retain every intended full-product branch as tracked unresolved work.','consequence':'Does not allow declaring a generic arithmetic component to be the completed full calculator or dropping regulated/account/policy features.'},
 {'decisionId':'OWNER-04','coverage':'Retirement80-91 and financial comparison profiles','proposal':'Require explicit supplied returns, inflation, horizons and cashflow timing; do not prefill an endorsed safe withdrawal rate or guaranteed return.','consequence':'Supports reproducibility; empirical adequacy/safety claims remain dependent on evidence and qualified review.'},
 {'decisionId':'OWNER-05','coverage':'198,199,488,516','proposal':'Select first provider/bank country/institution/system-boundary profile from the individual proposals; all others remain open full-scope work.','consequence':'An initial US Etsy or Stanford example is not automatically appropriate to the owner or all users. Owner may select alternatives, triggering new source requirements.'}]
for d in shared:d.update(status='PENDING',approvedBy=None,approvedAt=None)
write('owner-approval-register.json',{'status':'PENDING_NO_APPROVALS_OBTAINED','sharedDecisions':shared,'rows':owner})
with (p/'methodology-decisions-50.csv').open('w') as f:
 cols=['masterId','title','decisionClassification','narrowestRecommendedScope','sourceSupportedMethodology','candidateFormula','units','revisionEffectivePeriod','rounding','proposedDefaults','consequences','ownerQuestions','additionalBlockers','approval','evidenceComplete'];w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
 for r in rows:w.writerow({k:json.dumps(r[k],ensure_ascii=False) if isinstance(r[k],(dict,list)) else r[k] for k in cols})
write('updated-readiness-summary.json',{'releaseHold':True,'productionDecision':'NO_GO','methodologyWork':'50_PROPOSALS_PREPARED','summary':register['summary'],'remainingSourceCoverageCases':[r['masterId'] for r in prior['rows'] if not r['allCitedURLsRelevantContentVerified']],'retainedQualifiedIds':[r['masterId'] for r in base['rows'] if r['status']=='QUALIFIED_REVIEW_RETAINED'],'newConditionalQualifiedReviewRecommendations':[r['masterId'] for r in rows if r['decisionClassification']=='QUALIFIED_REVIEW_REQUIRED'],'acceptanceLedgerChanged':False,'catalogChanged':False,'originalReadinessRegisterChanged':False,'certificationAuthorized':False,'publicationAuthorized':False})
print(json.dumps(register['summary'],indent=2))
