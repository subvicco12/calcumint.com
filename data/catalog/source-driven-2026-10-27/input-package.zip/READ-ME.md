# CalcuMint — 50 readable-source methodology decisions

Baseline: PR #1482, `f8d85c8671daf8a621cf109a034d07e5639f85d6`. Prepared 26 October 2026 using the existing source-verification package. No new browsing or source implementation changes.

**Result: 50 per-ID methodology proposals prepared; 0 owner approvals obtained; 0 source-complete or engine-accepted cases. RELEASE HOLD remains active.**

| Primary next dependency | Cases |
|---|---:|
| OWNER_SELECTION_REQUIRED |30|
| SOURCE_GAP despite cited-page readability |15|
| QUALIFIED_REVIEW_REQUIRED recommendation for intended claims/applicability |5|
| ENGINEERING_RESOLVABLE as sole remaining whole-case dependency |0|

Every case has engineering-resolvable mapping and validation preparation tasks. None can be promoted solely by coding while its complete intended contract, source applicability and identity remain unapproved. These classifications describe the dominant next dependency; secondary blockers remain recorded per ID.

The five review recommendations are IDs88,89,90,91,136. They are **not** amendments to the existing11 retained qualified-review requirements, nor findings that a law mandates an external signature. FIRE adequacy/sustainability and salary-sacrifice eligibility/payroll interpretation need competent review for those intended claims. The retained11 are unchanged and listed separately below.

## Exact50 cases

| ID | Calculator | Primary dependency |
|---:|---|---|
|19|Credit Card Minimum Payment Calculator|SOURCE_GAP|
|20|Balance Transfer Calculator|SOURCE_GAP|
|21|Debt Consolidation Calculator|OWNER_SELECTION_REQUIRED|
|32|Rent vs Buy Calculator|OWNER_SELECTION_REQUIRED|
|34|Property Tax Calculator|SOURCE_GAP|
|35|Closing Cost Calculator|OWNER_SELECTION_REQUIRED|
|36|Rental Property Calculator|OWNER_SELECTION_REQUIRED|
|43|Rental ROI Calculator|OWNER_SELECTION_REQUIRED|
|46|House Flipping Profit Calculator|OWNER_SELECTION_REQUIRED|
|49|Mortgage + Rental Combined Model|OWNER_SELECTION_REQUIRED|
|80|Retirement Corpus Calculator|OWNER_SELECTION_REQUIRED|
|81|Retirement Savings Calculator|OWNER_SELECTION_REQUIRED|
|82|Retirement Age Calculator|OWNER_SELECTION_REQUIRED|
|84|Inflation-Adjusted Retirement Need Calculator|OWNER_SELECTION_REQUIRED|
|85|Retirement Withdrawal Calculator|OWNER_SELECTION_REQUIRED|
|86|Retirement Longevity Calculator|OWNER_SELECTION_REQUIRED|
|88|FIRE Calculator|QUALIFIED_REVIEW_REQUIRED|
|89|Coast FIRE Calculator|QUALIFIED_REVIEW_REQUIRED|
|90|Lean FIRE Calculator|QUALIFIED_REVIEW_REQUIRED|
|91|Fat FIRE Calculator|QUALIFIED_REVIEW_REQUIRED|
|95|Required Minimum Distribution Calculator|SOURCE_GAP|
|96|401(k) Calculator|SOURCE_GAP|
|97|Roth IRA Calculator|SOURCE_GAP|
|98|Traditional IRA Calculator|SOURCE_GAP|
|120|Income Tax Calculator|OWNER_SELECTION_REQUIRED|
|121|Take-Home Pay Calculator|SOURCE_GAP|
|122|Gross-to-Net Salary Calculator|SOURCE_GAP|
|123|Net-to-Gross Salary Calculator|SOURCE_GAP|
|124|Payroll Tax Calculator|OWNER_SELECTION_REQUIRED|
|125|Sales Tax Calculator|OWNER_SELECTION_REQUIRED|
|126|GST Calculator|OWNER_SELECTION_REQUIRED|
|127|VAT Calculator|SOURCE_GAP|
|128|Capital Gains Tax Calculator|OWNER_SELECTION_REQUIRED|
|129|Dividend Tax Calculator|OWNER_SELECTION_REQUIRED|
|130|Self-Employment Tax Calculator|OWNER_SELECTION_REQUIRED|
|131|Freelancer Tax Reserve Calculator|OWNER_SELECTION_REQUIRED|
|132|Corporate Tax Estimate Calculator|SOURCE_GAP|
|133|Property Tax Estimate Calculator|OWNER_SELECTION_REQUIRED|
|134|Tax Effective Rate Calculator|OWNER_SELECTION_REQUIRED|
|135|Tax Marginal Rate Calculator|OWNER_SELECTION_REQUIRED|
|136|Salary Sacrifice Calculator|QUALIFIED_REVIEW_REQUIRED|
|137|Bonus Tax Calculator|SOURCE_GAP|
|198|Marketplace Fee Calculator|SOURCE_GAP|
|199|Etsy Profit Calculator|OWNER_SELECTION_REQUIRED|
|468|Car Affordability Calculator|OWNER_SELECTION_REQUIRED|
|469|Auto Lease Calculator|SOURCE_GAP|
|470|Lease vs Buy Calculator|OWNER_SELECTION_REQUIRED|
|472|Loan vs Cash Calculator|OWNER_SELECTION_REQUIRED|
|488|Heat Pump Savings Calculator|OWNER_SELECTION_REQUIRED|
|516|GPA Calculator|OWNER_SELECTION_REQUIRED|

## What has been resolved analytically

The register distinguishes directly observed source rules, candidate mathematical derivations, and optional product choices. Each row contains units, observed edition/update/effective information, jurisdiction limitations, source-prescribed versus proposed rounding, narrowest proposed contract, consequences, exact questions and conditional Codex work. Unknown effective dates and unobserved rounding rules stay unknown; a browser reading does not create a complete governing rule pack.

Some sources support specific arithmetic directly: New Zealand GST addition/extraction; New York assessment-times-rate with rate-per-thousand conversion; Stanford unit-weighted GPA under its institutional rules; and selected US payroll rate/cap components for the observed year. They do not settle complete catalog contracts. Generic CFPB explanations and SEC educational calculators do not authoritatively define full property, retirement, debt or safety models. Etsy policy observations are country/account/fee-base dependent. ETL SCOP definitions do not prove installed savings. Full source-body hashes remain unavailable; the input contains observation hashes, which are not relabeled as original source hashes.

## Owner approval package

owner-approval-register.json has50 PENDING per-ID rows and five shared PENDING proposals. OWNER-DECISIONS.md is the concise reading view. No proposed default is adopted. Owner authority covers product choices and nonprescribed presentation, not professional competence, factual source validity, actual-engine acceptance or publication authority.

The fastest review order is seven batches: (1)14consumer/property/automotive contracts; (2)10retirement projection/FIRE contracts; (3)4IRA/401(k)/RMD profiles; (4)18tax/payroll profiles; (5)2marketplace profiles; (6)heat-pump boundary; (7)GPA institution. Approve only individually identified clauses; one blanket approval cannot supply a missing rule or qualified decision. Initial named profiles are components of the full product, not exclusions of intended functionality. All unimplemented/unsupported branches remain tracked.

## Nine incomplete-coverage cases

The full missing-source records preserve exact original URLs and limitations in missing-source-cases-9.json.

| ID | Calculator | Exact missing document or evidence |
|---:|---|---|
|23|HELOC|Readable complete CFPB HELOC brochure, plus selected actual agreement/index rules: draw/repayment phases, index/margin/caps/reset/day count/fees and official cases|
|48|Investment Property Affordability|Same HELOC brochure; selected lender underwriting guide for rent credit, DTI/debt service, reserves, LTV and eligibility. Generic budget arithmetic is insufficient|
|92|Pension|Readable DOL ERISA FAQ; named plan governing document/amendments, benefit/accrual/vesting/retirement/survivor/COLA rules and participant examples|
|112|Overtime|Readable DOL Fact Sheet23; applicable selected jurisdiction/worker classification, regular-rate/premium/period rules and exceptions|
|173|Customer Lifetime Value|Complete nine-page Fader/Hardie March2012 CLV PDF; conditional versus unconditional flow timing and selected cohort/retention model contract|
|204|Return Rate Impact|AASB15 AppendixB compilation applicability/effective-date evidence and full selected return/refund/inventory-recovery recognition contract; relevant appendix HTML was read|
|485|Carbon Footprint|2026 conversion-factor workbook/full set and methodology attachments, July correction provenance, exact activity/factor/GWP/boundary/year selections|
|522|Race Time Predictor|Full Riegel1981 article/ARHE PDF, not PubMed bibliographic record; supported/calibrated exponent, population/distance/training applicability and uncertainty|
|527|Golf Handicap|Complete applicable Rules of Handicapping2024 source and Rule5.1a, readable formula/tables/definitions and national applicability; R&A partial text and blocked USGA links are insufficient|

These nine differ from the15 SOURCE_GAP cases inside the readable50. A cited page can be readable while additional required documents, tables or rule clauses are still missing.

## Retained11 qualified requirements — unchanged

87, 404, 405, 406, 407, 408, 409, 410, 502, 526, 530. All remain pending. Their original version-bound requirements are preserved in retained-qualified-cases-11.json. No approvals, signatures or qualifications were manufactured.

## Shortest next path

1. Review grouped owner choices and adopt only explicit, complete contracts. Engineering can prepare exact mapping proposals and independent expected-case specifications now; it cannot silently adopt policy defaults.
2. In parallel, close the per-ID source gaps: the nine incomplete-coverage cases and missing governing rules identified within the readable50. Obtain qualified applicability review where the proposed full contract needs it; preserve existing11 requirements separately.
3. After contract/source decisions, bind each catalog ID to exact immutable engine version/fullSHA/dependencies and execute the ID-specific golden, boundary, rounding and failure-domain cases in CODEX-HANDOFF.md/codex-tasks-50.json. Reference arithmetic is not an actual-engine pass. Source implementation changes require the applicable separate engineering authorization; none are performed here.
4. Complete competent source/obligation review and existing authenticated lifecycle gates. No production GO, certification or publication follows from these proposals.

## Integrity and files

The input ZIP SHA-256 is `72b28e4edb98c586d70402b5ca6361836bbffe2f06473f5a0acecba20beae2ae`; all76 input manifest entries verified. All59 baseline packets were read across the independent domain reviews and root review, and all59 packet hashes match the original register. Exact50/9/11 partition coverage is validated. The catalog540 identities,424ledger records,14privateDRAFTs, immutable versions and frozen PR heads were not modified. Preservation is by no writes, not a new production audit.

- methodology-decision-register-50.json / methodology-decisions-50.csv: exact50 proposals and source/candidate distinctions.
- owner-approval-register.json / OWNER-DECISIONS.md: PENDING proposed defaults, consequences and questions.
- codex-tasks-50.json / CODEX-HANDOFF.md: mapping/validation preparation and exact conditional tasks.
- missing-source-cases-9.json and retained-qualified-cases-11.json: separate remaining cohorts.
- updated-readiness-summary.json: no unsupported promotions.
- input-evidence/: complete original source-verification package members.
- REVIEW-AND-VALIDATION.md and MANIFEST-SHA256.json: review findings, checks and package integrity.

**Readiness: PARTIAL. Production NO-GO. RELEASE HOLD.**
