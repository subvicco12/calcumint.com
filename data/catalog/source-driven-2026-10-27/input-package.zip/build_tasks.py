import json,pathlib
p=pathlib.Path(__file__).parent;r=json.loads((p/'methodology-decision-register-50.json').read_text())['rows']
tests={
19:'Issuer floor/percentage crossover; interest/fees/past-due additions; final-debt cap; statement-day timing using selected agreement examples.',
20:'Transfer fee paid upfront versus capitalized; promotional expiry/rate transition; payment allocation; matched horizon and terminal balance.',
21:'Equal payment horizons; unequal terminal debt; fees exactly once; zero-rate; no saving versus negative saving.',
32:'Same dated rent/buy horizon; upfront cash and opportunity cost once; terminal property value/debt/selling costs; tax eligibility only with approved rules.',
34:'Selected tax class/year; taxable versus assessed/billable values; exemptions versus abatements; illustrative NYC rate must not become current default.',
35:'Closing-cost components versus cash-to-close; prepaids/escrow/credits allocation; lender credit sign; no duplicate down payment.',
36:'NOI excludes debt service; financing cashflow separate; vacancy, capex and reserves distinguished; cash versus taxable result labels.',
43:'Cash-on-cash versus total return/IRR denominator and period; zero denominator; terminal equity and financing contributions exactly once.',
46:'Sale proceeds less acquisition/rehab/holding/finance/selling items; payoff principal treatment; zero/negative profit; elapsed-time choice.',
49:'Mortgage terminal debt reconciles with rental cashflows; interest/principal not double-counted; sale payoff once; equal periodic basis.',
80:'Dated finite spending/benefit cashflow present value; zero return; negative real return; finite horizon; no perpetuity substituted for finite corpus.',
81:'Begin/end contribution timing; monthly/annual rate conversion; zero rate; contribution growth and tax/account rules only when approved.',
82:'Approved forward projection and target evaluated at identical ages; first crossing versus never; finite age bound; horizon and dependency version binding.',
84:'Nominal/real consistency; one-year inflation and zero inflation; inflated spending is not automatically a retirement corpus.',
85:'Before/after growth withdrawals; final balance; taxable benefits/inflation only when selected; no safety inference from deterministic recurrence.',
86:'Distinguish exact-zero depletion from first insufficient withdrawal; interest covers withdrawal; finite horizon cap and never-depletes result.',
88:'Positive supplied withdrawal fraction; no universal4% default; unreachable accumulation target; qualified target/sustainability model dependency.',
89:'Zero years returns target; zero/negative selected return; no later contributions scenario explicitly selected; approved future target dependency.',
90:'Owner supplied Lean spending threshold; same FIRE target/risk dependency as88; no normative universal Lean threshold.',
91:'Owner supplied Fat spending threshold; same FIRE target/risk dependency as88; no normative universal Fat threshold.',
95:'Prior-year December31 balance; exact applicable table/age/spouse/inherited branch; official denominator provenance; year transition and mandated rounding.',
96:'Employee-owned versus employer-origin contribution buckets; contribution-date vesting tranches; total versus vested balance; selected plan limits, no stale2024 cap reuse.',
97:'Roth contribution permission versus accumulation versus distribution treatment; tax year and income limits; five-year/qualified branches once sourced.',
98:'Traditional IRA contribution permission versus deductibility/basis; selected filing/account profile; no after-tax basis double tax; approved distribution dependency.',
120:'Selected non-savings bands and allowance taper boundaries; Scotland unsupported in proposed first profile; savings/dividend branches stay tracked, not silently zeroed.',
121:'Selected W-4 vintage/pay-frequency tables; annualization; pre/post-tax deductions; covered wage bases; federal withholding distinct from total tax.',
122:'Same selected payroll forward contract as121; gross/deductions/withholding/net reconciliation; no state/local zero assumption.',
123:'Feed inverse result into exact approved forward payroll engine; finite bracket; monotonicity proof or safe no-solution; ties and discontinuous rounding.',
124:'Social Security wage-base crossing and cumulative periodic increments; Additional Medicare employer withholding threshold; employee/employer separate; no employer Additional Medicare.',
125:'Selected delivery-locality rate; discount/rebate/trade-in/shipping taxable-base distinctions; tax-inclusive conversion only when selected.',
126:'IRD reference100 exclusive ->15GST/115inclusive;115inclusive ->15GST via3/23; zero-rated/exempt not inferred; return/input-credit branches remain separate.',
127:'Selected taxability/rate and date; exclusive versus inclusive price; zero-rated versus exempt distinction; return/input-credit rules remain sourced dependencies.',
128:'Selected tax-year gains/losses/allowance and other income; basic/higher split; trusts/special reliefs not invented; reference values explicitly source-bound.',
129:'Dividend allowance uses band capacity as sourced; other income interactions; selected2026/27 rates; no foreign tax relief invented.',
130:'Eligible self-employment profit thresholds; Class4 versus Class2 status separately; no UK NI arithmetic relabeled as US self-employment tax.',
131:'Forward selected income/NI liabilities minus supplied payments; annual reserve versus remaining-period contribution; taxYear and period mismatch rejected.',
132:'Selected accounting period/associated-company threshold reduction; small-profit/main-rate boundaries; marginal relief formula must be sourced before implementation.',
133:'Taxable assessment minus eligible exemptions times selected rate/1000;150000*50/1000=7500 reference; clarify identity distinction from34.',
134:'100*supplied liability/selected positive denominator; zero/negative denominator; included taxes and same period; no statutory ratio definition inferred.',
135:'Statutory band versus finite-difference marginal effective rate; allowance taper can differ; increment crossing bands and tax rounding must be explicit.',
136:'Before/after same approved payroll engine; benefit eligibility and NMW cap; registered pension exception; employee versus employer NI; no universal savings percentage.',
137:'Supplemental/aggregate withholding method and year; separately identified bonus; annual liability distinct; threshold and gross-up rules sourced.',
198:'Gross versus net supplied components equivalent; refunds/eligible credits exactly once; provider assessed-fee bases only after selected rule pack.',
199:'Different transaction/processing fee bases; seller versus platform-funded refund; ads threshold/cap and eligibility; provider rounding only after sourced.',
468:'Budget minus supplied ownership costs; zero/negative capacity; fixed-rate inverse zero-rate limit; no lender approval/DTI claim.',
469:'Federal Reserve disclosed example11745/48 ->244.6875; displayed base244.69 plus supplied12.25tax ->256.94; no inferred money factor or current tax.',
470:'Same lease/buy horizon; lease mileage/disposition charges; buy terminal equity and debt; cashflow timing matched; no sample tax rate default.',
472:'Cash versus borrowing cashflows discounted at owner-selected scenario rate; upfront outlay exactly once; terminal debt and no guaranteed investment return.',
488:'Q10000,eta1,SCOP4,tariffs.10/.30 ->250 before external auxiliary;100kWh extra ->220; efficiency/domain/currency and system-boundary validation.',
516:'(2.7*3+3.7*4+3.3*3)/10=3.28; A4 and NP0 equally weighted ->2; excluded symbol ->4; Ltemporary2.0 rule and program/repeat eligibility source-bound.'}
assert set(tests)=={x['masterId'] for x in r}
tasks=[]
for x in r:
 tasks.append({'masterId':x['masterId'],'title':x['title'],'classification':'ENGINEERING_RESOLVABLE','status':'PREPARATION_READY_EXECUTION_CONDITIONAL','readyNow':['Prepare exact catalog-to-candidate implementation/version/dependency-SHA mapping proposal using existing packet file references; do not adopt mapping or change source.','Turn the named contract branches below into independent expected-case specifications; distinguish source examples from synthetic mathematical witnesses.','Preserve source/observation hash distinction and classify unsupported scope explicitly; do not rerun the42URL exercise.'],'requiresBeforeImplementation':['Owner-selected complete contract, source revision/applicability and prescribed rounding','Qualified applicability decision where required; no substitute signature','Separate authorization for source engineering changes, which this task explicitly prohibits'],'idSpecificValidationSpecification':tests[x['masterId']],'candidateImplementationEvidence':x['originalImplementationEvidence'],'existingDetailedTasks':x['exactCodexTasks'],'testsExecutedThisTask':False,'claim':'Task specification, not implementation or passed acceptance.','releaseHold':True})
(p/'codex-tasks-50.json').write_text(json.dumps({'all50HaveEngineeringTasks':True,'pureCaseClosureByEngineeringAlone':0,'rows':tasks},ensure_ascii=False,indent=2)+'\n')
with (p/'CODEX-HANDOFF.md').open('w') as f:
 f.write('# Exact Codex handoff — no changes authorized by this package\n\nBaseline PR1482 `f8d85c8671daf8a621cf109a034d07e5639f85d6`. Use existing source evidence; do not repeat42URL browsing or general audits. All50 contract proposals remain PENDING.\n\nReady now: prepare mapping proposals and independent case specifications below. Implementation/execution is conditional on approved complete contract and any missing source/qualified decisions, plus the applicable engineering authorization. Do not modify formulas or frozen heads on the strength of this handoff.\n\n')
 for t in tasks:f.write(f"- **{t['masterId']} {t['title']}** — {t['idSpecificValidationSpecification']}\n")
 f.write('\nFor every selected contract, record ID, immutable version, exact full implementation/dependency SHA, source clause/revision, selected applicability, independent expected value, actual result, rounding/domain boundary and reviewer disposition. Compare historical outputs; any approved method change uses a new technical revision. Preserve14DRAFTs, SIPv1/Slopev1, history,540identities,424ledger and RELEASE HOLD. Build with `next build --webpack` when a separately authorized engineering change reaches validation. No database writes, merges, deployment, certification or publication.\n')
