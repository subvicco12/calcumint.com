# Exact Codex handoff — no changes authorized by this package

Baseline PR1482 `f8d85c8671daf8a621cf109a034d07e5639f85d6`. Use existing source evidence; do not repeat42URL browsing or general audits. All50 contract proposals remain PENDING.

Ready now: prepare mapping proposals and independent case specifications below. Implementation/execution is conditional on approved complete contract and any missing source/qualified decisions, plus the applicable engineering authorization. Do not modify formulas or frozen heads on the strength of this handoff.

- **19 Credit Card Minimum Payment Calculator** — Issuer floor/percentage crossover; interest/fees/past-due additions; final-debt cap; statement-day timing using selected agreement examples.
- **20 Balance Transfer Calculator** — Transfer fee paid upfront versus capitalized; promotional expiry/rate transition; payment allocation; matched horizon and terminal balance.
- **21 Debt Consolidation Calculator** — Equal payment horizons; unequal terminal debt; fees exactly once; zero-rate; no saving versus negative saving.
- **32 Rent vs Buy Calculator** — Same dated rent/buy horizon; upfront cash and opportunity cost once; terminal property value/debt/selling costs; tax eligibility only with approved rules.
- **34 Property Tax Calculator** — Selected tax class/year; taxable versus assessed/billable values; exemptions versus abatements; illustrative NYC rate must not become current default.
- **35 Closing Cost Calculator** — Closing-cost components versus cash-to-close; prepaids/escrow/credits allocation; lender credit sign; no duplicate down payment.
- **36 Rental Property Calculator** — NOI excludes debt service; financing cashflow separate; vacancy, capex and reserves distinguished; cash versus taxable result labels.
- **43 Rental ROI Calculator** — Cash-on-cash versus total return/IRR denominator and period; zero denominator; terminal equity and financing contributions exactly once.
- **46 House Flipping Profit Calculator** — Sale proceeds less acquisition/rehab/holding/finance/selling items; payoff principal treatment; zero/negative profit; elapsed-time choice.
- **49 Mortgage + Rental Combined Model** — Mortgage terminal debt reconciles with rental cashflows; interest/principal not double-counted; sale payoff once; equal periodic basis.
- **80 Retirement Corpus Calculator** — Dated finite spending/benefit cashflow present value; zero return; negative real return; finite horizon; no perpetuity substituted for finite corpus.
- **81 Retirement Savings Calculator** — Begin/end contribution timing; monthly/annual rate conversion; zero rate; contribution growth and tax/account rules only when approved.
- **82 Retirement Age Calculator** — Approved forward projection and target evaluated at identical ages; first crossing versus never; finite age bound; horizon and dependency version binding.
- **84 Inflation-Adjusted Retirement Need Calculator** — Nominal/real consistency; one-year inflation and zero inflation; inflated spending is not automatically a retirement corpus.
- **85 Retirement Withdrawal Calculator** — Before/after growth withdrawals; final balance; taxable benefits/inflation only when selected; no safety inference from deterministic recurrence.
- **86 Retirement Longevity Calculator** — Distinguish exact-zero depletion from first insufficient withdrawal; interest covers withdrawal; finite horizon cap and never-depletes result.
- **88 FIRE Calculator** — Positive supplied withdrawal fraction; no universal4% default; unreachable accumulation target; qualified target/sustainability model dependency.
- **89 Coast FIRE Calculator** — Zero years returns target; zero/negative selected return; no later contributions scenario explicitly selected; approved future target dependency.
- **90 Lean FIRE Calculator** — Owner supplied Lean spending threshold; same FIRE target/risk dependency as88; no normative universal Lean threshold.
- **91 Fat FIRE Calculator** — Owner supplied Fat spending threshold; same FIRE target/risk dependency as88; no normative universal Fat threshold.
- **95 Required Minimum Distribution Calculator** — Prior-year December31 balance; exact applicable table/age/spouse/inherited branch; official denominator provenance; year transition and mandated rounding.
- **96 401(k) Calculator** — Employee-owned versus employer-origin contribution buckets; contribution-date vesting tranches; total versus vested balance; selected plan limits, no stale2024 cap reuse.
- **97 Roth IRA Calculator** — Roth contribution permission versus accumulation versus distribution treatment; tax year and income limits; five-year/qualified branches once sourced.
- **98 Traditional IRA Calculator** — Traditional IRA contribution permission versus deductibility/basis; selected filing/account profile; no after-tax basis double tax; approved distribution dependency.
- **120 Income Tax Calculator** — Selected non-savings bands and allowance taper boundaries; Scotland unsupported in proposed first profile; savings/dividend branches stay tracked, not silently zeroed.
- **121 Take-Home Pay Calculator** — Selected W-4 vintage/pay-frequency tables; annualization; pre/post-tax deductions; covered wage bases; federal withholding distinct from total tax.
- **122 Gross-to-Net Salary Calculator** — Same selected payroll forward contract as121; gross/deductions/withholding/net reconciliation; no state/local zero assumption.
- **123 Net-to-Gross Salary Calculator** — Feed inverse result into exact approved forward payroll engine; finite bracket; monotonicity proof or safe no-solution; ties and discontinuous rounding.
- **124 Payroll Tax Calculator** — Social Security wage-base crossing and cumulative periodic increments; Additional Medicare employer withholding threshold; employee/employer separate; no employer Additional Medicare.
- **125 Sales Tax Calculator** — Selected delivery-locality rate; discount/rebate/trade-in/shipping taxable-base distinctions; tax-inclusive conversion only when selected.
- **126 GST Calculator** — IRD reference100 exclusive ->15GST/115inclusive;115inclusive ->15GST via3/23; zero-rated/exempt not inferred; return/input-credit branches remain separate.
- **127 VAT Calculator** — Selected taxability/rate and date; exclusive versus inclusive price; zero-rated versus exempt distinction; return/input-credit rules remain sourced dependencies.
- **128 Capital Gains Tax Calculator** — Selected tax-year gains/losses/allowance and other income; basic/higher split; trusts/special reliefs not invented; reference values explicitly source-bound.
- **129 Dividend Tax Calculator** — Dividend allowance uses band capacity as sourced; other income interactions; selected2026/27 rates; no foreign tax relief invented.
- **130 Self-Employment Tax Calculator** — Eligible self-employment profit thresholds; Class4 versus Class2 status separately; no UK NI arithmetic relabeled as US self-employment tax.
- **131 Freelancer Tax Reserve Calculator** — Forward selected income/NI liabilities minus supplied payments; annual reserve versus remaining-period contribution; taxYear and period mismatch rejected.
- **132 Corporate Tax Estimate Calculator** — Selected accounting period/associated-company threshold reduction; small-profit/main-rate boundaries; marginal relief formula must be sourced before implementation.
- **133 Property Tax Estimate Calculator** — Taxable assessment minus eligible exemptions times selected rate/1000;150000*50/1000=7500 reference; clarify identity distinction from34.
- **134 Tax Effective Rate Calculator** — 100*supplied liability/selected positive denominator; zero/negative denominator; included taxes and same period; no statutory ratio definition inferred.
- **135 Tax Marginal Rate Calculator** — Statutory band versus finite-difference marginal effective rate; allowance taper can differ; increment crossing bands and tax rounding must be explicit.
- **136 Salary Sacrifice Calculator** — Before/after same approved payroll engine; benefit eligibility and NMW cap; registered pension exception; employee versus employer NI; no universal savings percentage.
- **137 Bonus Tax Calculator** — Supplemental/aggregate withholding method and year; separately identified bonus; annual liability distinct; threshold and gross-up rules sourced.
- **198 Marketplace Fee Calculator** — Gross versus net supplied components equivalent; refunds/eligible credits exactly once; provider assessed-fee bases only after selected rule pack.
- **199 Etsy Profit Calculator** — Different transaction/processing fee bases; seller versus platform-funded refund; ads threshold/cap and eligibility; provider rounding only after sourced.
- **468 Car Affordability Calculator** — Budget minus supplied ownership costs; zero/negative capacity; fixed-rate inverse zero-rate limit; no lender approval/DTI claim.
- **469 Auto Lease Calculator** — Federal Reserve disclosed example11745/48 ->244.6875; displayed base244.69 plus supplied12.25tax ->256.94; no inferred money factor or current tax.
- **470 Lease vs Buy Calculator** — Same lease/buy horizon; lease mileage/disposition charges; buy terminal equity and debt; cashflow timing matched; no sample tax rate default.
- **472 Loan vs Cash Calculator** — Cash versus borrowing cashflows discounted at owner-selected scenario rate; upfront outlay exactly once; terminal debt and no guaranteed investment return.
- **488 Heat Pump Savings Calculator** — Q10000,eta1,SCOP4,tariffs.10/.30 ->250 before external auxiliary;100kWh extra ->220; efficiency/domain/currency and system-boundary validation.
- **516 GPA Calculator** — (2.7*3+3.7*4+3.3*3)/10=3.28; A4 and NP0 equally weighted ->2; excluded symbol ->4; Ltemporary2.0 rule and program/repeat eligibility source-bound.

For every selected contract, record ID, immutable version, exact full implementation/dependency SHA, source clause/revision, selected applicability, independent expected value, actual result, rounding/domain boundary and reviewer disposition. Compare historical outputs; any approved method change uses a new technical revision. Preserve14DRAFTs, SIPv1/Slopev1, history,540identities,424ledger and RELEASE HOLD. Build with `next build --webpack` when a separately authorized engineering change reaches validation. No database writes, merges, deployment, certification or publication.
