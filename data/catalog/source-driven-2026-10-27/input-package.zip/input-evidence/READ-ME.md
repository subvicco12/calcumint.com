# CalcuMint — cloud-browser source acceptance

Evidence baseline: PR #1482, `f8d85c8671daf8a621cf109a034d07e5639f85d6`.
Browser observation date: 26 October 2026. RELEASE HOLD remains active.

## Decision

PARTIAL source progress. Production release NO-GO. No certification or publication authorized.

| Result | Count |
|---|---:|
| Exact indexed URLs attempted in cloud browser |42|
| Relevant substantive content verified |31|
| Blocked or limited sources |11|
| Catalog IDs covered by index |59|
| Source-to-ID links reconciled |84|
| Cases with at least one relevant source verified |51|
| Cases with all cited URLs' relevant content verified |50|
| Cases with substantively complete governing source evidence |0|
| Evidence-complete cases |0|
| Retained qualified-review requirements |11|
| CalcuMint actual-engine tests executed in this task |0|

“Relevant content verified” means direct browser reading of relevant publisher content, not exhaustive validation of a publication, normative approval, currency for every jurisdiction or a complete calculator contract. The two SEC calculators are official illustrative tools, not governing mathematical specifications. Several official pages are general guidance or worked examples. The matrix records original observations without turning page review dates into effective dates.

## Remaining blocked or limited sources

Ordinals are one-based and match source-verification-matrix.json/CSV.

| Ordinal | Source | IDs | Limitation |
|---:|---|---|---|
|1|Hardie/Fader CLV PDF|173|First page inspected; remaining eight pages unreviewed|
|3|CFPB HELOC PDF|23,48|PDF viewer exposed no substantive document text|
|4|PubMed Riegel record|522|Bibliographic identity only; no abstract/full paper|
|5|RRTC ARHE PDF|522|PDF viewer exposed no substantive document text|
|6|AASB 15 Appendix B|204|Relevant full HTML observed; exact compilation applicability/effective date unresolved|
|13|DOL ERISA FAQ|92|Site Access Denied|
|14|DOL overtime fact sheet|112|Site Access Denied|
|21|GOV.UK 2026 emissions factors|485|Publication landing page read; XLSX factors/methodology attachments unreviewed|
|38|R&A Rule 5|527|Relevant sections read; formulas/image tables incomplete in accessibility representation|
|41|USGA 2024 PDF|527|Site Access Denied|
|42|USGA Rule 5.1a|527|Site Access Denied|

These exact URLs are preserved. No replacement sources, network reconfiguration or alternate transport were used. Access denial in this browser does not imply a publisher outage.

## Material findings

- IRS Publication 15/15-T exposed 2026 editions; 527/590-A/590-B exposed 2025 editions with some explicitly marked 2026 provisions. Select applicable tax year per clause; do not treat the page's update date as a blanket rule year.
- The IRS 401(k) overview includes a 2024 compensation-cap example despite a 2026 review date. NYC's property-tax rate is expressly illustrative. Neither is accepted as a current rate table.
- GOV.UK 2026/27 rates were read directly; jurisdiction, residency, exceptions, tax year and product scope remain case decisions. Emissions landing-page change history reports a July 2026 zero-to-blank correction; factors were not validated.
- Etsy country-specific payment fees and marketplace policies were read. Country, currency, transaction basis, refunds and applicable policy date still require selection.
- ETL heat-pump eligibility/SCOP rules do not establish installed seasonal performance or a universal savings guarantee. Stanford GPA rules are institution-specific.
- SEC compound-interest calculator: $1,000 principal, no contributions, one year, 5%, annual compounding returned $1,050, matching independent arithmetic. The savings-goal calculator rejected a zero interest rate. These are external reference observations, not CalcuMint engine tests or defects.
- No application formula was changed and no demonstrated implementation defect is asserted from this source-reading exercise.

## Per-ID reconciliation and next actions

updated-evidence-readiness.json contains all 59 cases, their newly observed source coverage, original gaps and six original gap categories: formula, jurisdiction, rounding, applicability, version and actual-engine acceptance. per-id-evidence-gaps.csv is the flat review view. packet-gap-analysis.json preserves original source evidence, register rows, exact gaps and baseline classifications. A page loading does not close those substantive requirements.

Shortest dependency-ordered path:

1. For the 50 cases whose cited relevant content is readable, resolve the exact per-ID methodology, jurisdiction/period, domain and rounding choices now. In parallel, obtain readable complete copies of the 11 limited sources and establish applicable revisions. Owner/provider/issuer-specific agreements are still needed where generic pages are insufficient.
2. Bind each selected contract to catalog ID, immutable technical version, implementation SHA and source revision; retain an authentic source snapshot when required. Complete competent applicability and obligation review. The prospective governance policy is still unadopted; this report grants no authority to adopt it.
3. Run independent actual-engine golden, boundary, rounding and error-domain tests against those exact bindings. Synthetic candidate checks do not substitute for these tests.
4. Obtain genuine version-bound qualified decisions for retained IDs 87,404,405,406,407,408,409,410,502,526,530. No AI source review substitutes for qualified acceptance.
5. Satisfy remaining authorized QA/lifecycle and external release gates before any separate release decision. This task neither re-audited nor cleared database, recovery, provider, physical accessibility, PDF/UA or production gates.

## Provenance and preservation

All 59 baseline packet SHA-256 values match the PR register. Source-index SHA-256 is `deb8dfbbdde85fdc00e3fe4c006e5bb4dd8bbbbd3abc59d65ec8c5e79b2f1efa`, matching its recorded baseline. 42 URLs map to exactly 59 IDs and 84 links, with no missing/extra associations.

No raw HTTP/PDF bodies were retained by these browser observations: sourceBodySHA256 is null. Observation-record and selected-passage hashes are explicitly labeled; they prove integrity of these local observations, not authenticity of original publisher bytes. Publication/last-reviewed/effective dates are separate where known; unknown dates remain unknown. Retrieval dates are dates of browser observation, not fabricated exact request timestamps.

No source PR, repository branch, environment configuration, production system, formula, historical version, ledger or publication control was modified. The 540 catalog identities, 424 acceptance records and 14 private DRAFTs were not altered; preservation is by no writes, not a fresh production-state audit. Baseline inputs are retained in this package for comparison. The 11 qualified requirements remain pending.

## Files

- source-verification-matrix.json and .csv: 42 exact source rows, original observations, coverage and observation hashes.
- updated-evidence-readiness.json: 59-row nonpromoting overlay.
- per-id-evidence-gaps.csv: exact original per-ID gaps and categorized choices.
- packet-gap-analysis.json: full baseline reconciliation.
- *-results.json and *-observations*: publisher-group browser evidence.
- baseline-packets/, baseline-readiness-register.json, source-index.json: exact baseline inputs.
- MANIFEST-SHA256.json: checksums of package members except the manifest itself.
