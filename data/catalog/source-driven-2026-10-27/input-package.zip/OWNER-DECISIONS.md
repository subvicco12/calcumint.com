# Owner decisions — proposed, not approved

All50 cases remain PENDING. Approval applies only to identified product choices; source/rule, engine, qualified and lifecycle gates remain separate. No full-scope feature is waived by accepting an initial profile.

## OWNER-01 — All50

**Proposed:** Require explicit currency, jurisdiction/profile and applicable period; no geolocation-based or browser-availability-based defaults. Version profile selection and reject unsupported scope with reason.

**Consequence:** Some cases require more input; prevents a wrong jurisdiction/rule pack from silently producing a plausible answer.

Status: PENDING.

## OWNER-02 — All50, except source-prescribed rules override

**Proposed:** For illustrative supplied-input arithmetic: decimal/rational intermediates, final currency display at explicitly selected currency minor-unit precision, percentages4decimals and GPA3decimals, half-up ties. No intermediate rounding unless the approved method prescribes it. Keep unrounded values for boundary comparisons.

**Consequence:** This is a proposed display contract, not a tax, lender, provider or institutional rounding rule. Prescribed rounding must be sourced before rule-pack acceptance; changing historical rounding requires a new immutable technical revision.

Status: PENDING.

## OWNER-03 — All50

**Proposed:** Accept narrow named profiles as components/first implementation contracts only; retain every intended full-product branch as tracked unresolved work.

**Consequence:** Does not allow declaring a generic arithmetic component to be the completed full calculator or dropping regulated/account/policy features.

Status: PENDING.

## OWNER-04 — Retirement80-91 and financial comparison profiles

**Proposed:** Require explicit supplied returns, inflation, horizons and cashflow timing; do not prefill an endorsed safe withdrawal rate or guaranteed return.

**Consequence:** Supports reproducibility; empirical adequacy/safety claims remain dependent on evidence and qualified review.

Status: PENDING.

## OWNER-05 — 198,199,488,516

**Proposed:** Select first provider/bank country/institution/system-boundary profile from the individual proposals; all others remain open full-scope work.

**Consequence:** An initial US Etsy or Stanford example is not automatically appropriate to the owner or all users. Owner may select alternatives, triggering new source requirements.

Status: PENDING.

## Per-ID choices

**19 — Credit Card Minimum Payment Calculator** (SOURCE_GAP)

Proposed first contract: One explicitly selected issuer/card statement minimum under its pinned agreement.

Questions: ["Issuer formula, percent/floor basis, interest/fees inclusion, due dates and payoff assumptions.", "Actual issuer rule missing; no percent/floor default.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**20 — Balance Transfer Calculator** (SOURCE_GAP)

Proposed first contract: One explicitly selected transfer offer and card agreement compared over an owner-selected matched horizon.

Questions: ["Fee capitalization, promotional duration, payment order and rate reset.", "Promotion reset, allocation and loss-of-promotion conditions unselected.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**21 — Debt Consolidation Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Supplied finite debt-payment/fee vectors with equal horizons and explicit terminal balances.

Questions: ["Debt types, fees, payment policy and cost-comparison basis.", "Unequal horizons need residual liabilities/discounting; cannot infer consolidation eligibility.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**32 — Rent vs Buy Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Supplied dated pre-tax rent/buy cash-flow comparison with explicit financing and terminal settlement.

Questions: ["Discounting, tax treatment, financing, maintenance and terminal-sale inclusions.", "Cash-flow accounting proposal only; no official universal rent-buy method selected.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**34 — Property Tax Calculator** (SOURCE_GAP)

Proposed first contract: One selected jurisdiction, tax year and property class with supplied billable assessment and selected exemption/abatement rules.

Questions: ["Assessed versus market value, exemptions, caps, levies and jurisdiction.", "NYC form is illustrative; jurisdiction/year/class and assessment rules unselected.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**35 — Closing Cost Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Supplied itemized closing costs and allocations, with a separate reconciled cash-to-close output.

Questions: ["Buyer/seller scope, taxes, lender fees, escrows and prepaid-item treatment.", "Buyer/seller and financing allocations must be pinned; avoid double-counting deposits/down payment.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**36 — Rental Property Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Supplied periodic pre-tax operating and financing cash flows with explicit expense classification.

Questions: ["Expense classification, financing, capex, depreciation and sale assumptions.", "NOI/capex classification proposed; taxable income differs from cash flow.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**43 — Rental ROI Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Explicitly named pre-tax cash-on-cash and/or holding-period return from supplied cash flows.

Questions: ["Return metric, leverage, sale proceeds, costs and annualization convention.", "Return definition not selected; annualized IRR is a different metric.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**46 — House Flipping Profit Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Supplied pre-tax project cash profit over a selected holding period.

Questions: ["Fee/tax inclusions, finance timing, budget contingencies and return basis.", "Taxes and timing remain explicit; accounting identity is not market forecast.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**49 — Mortgage + Rental Combined Model** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Explicitly dated mortgage recurrence joined to supplied periodic rental cash flows and terminal debt.

Questions: ["Mortgage schedule version, cash-flow alignment, operating inclusions and sale horizon.", "Period alignment, taxes and terminal liabilities must be reviewed.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**80 — Retirement Corpus Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Finite dated-cashflow present-value component as a separately labeled proposal inside the full corpus product; all intended retirement features remain required. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Approve full retirement-income contract: dated spending/benefit/tax flows, inflation basis, finite horizon, terminal requirement and longevity/sequence-risk treatment.", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**81 — Retirement Savings Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Constant-contribution accumulation component inside the complete retirement-savings contract; account features remain open rather than excluded. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Is savings projection sufficient as a component, and which intended retirement-account, tax, eligibility and contribution features must the complete product support?", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**82 — Retirement Age Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Bounded first-crossing search over separately approved full projection and target contracts. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Which complete accumulation and retirement-target models determine retirement age, what horizon and age/period conversion apply, and what constitutes no solution?", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**84 — Inflation-Adjusted Retirement Need Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Inflation projection component plus independently selected full corpus contract; do not deliver spending-only in place of full retirement need. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Which spending base year, inflation convention, retirement horizon and complete downstream corpus/withdrawal model apply?", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**85 — Retirement Withdrawal Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Dated withdrawal recurrence component within the complete withdrawal product including all intended flows and risk claims. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Select beginning/end withdrawals, indexing, taxes/benefits, scheduled versus paid amounts, partial-payment and depletion behavior for complete product.", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**86 — Retirement Longevity Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Report both exact-zero period and first-shortfall period as distinct candidate outputs in full longevity product. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Does longevity mean exact zero, first payment shortfall, or both; which timing, partial-payment and initial-zero rules apply?", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**88 — FIRE Calculator** (QUALIFIED_REVIEW_REQUIRED)

Proposed first contract: Supplied-input target arithmetic and first crossing are components; retain full FIRE adequacy and sustainability requirements pending source selection and quantitative review. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Select target/withdrawal-rule authority, full spending/tax/benefit/inflation basis, accumulation model, horizon and intended sustainability claims.", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**89 — Coast FIRE Calculator** (QUALIFIED_REVIEW_REQUIRED)

Proposed first contract: Discounting a separately approved target is a component of full Coast FIRE product; no scope waiver for target/sustainability. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Select full future target authority, inflation basis, coast date and treatment of subsequent contributions; which adequacy or safety claims are intended?", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**90 — Lean FIRE Calculator** (QUALIFIED_REVIEW_REQUIRED)

Proposed first contract: Owner-profile target arithmetic plus full shared FIRE contract; retain intended adequacy/risk functionality. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["What owner-defined Lean spending profile, location/base year, full FIRE policy and sustainability claim should apply?", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**91 — Fat FIRE Calculator** (QUALIFIED_REVIEW_REQUIRED)

Proposed first contract: Owner-profile target arithmetic plus full shared FIRE contract; retain intended adequacy/risk functionality. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["What owner-defined Fat spending profile, location/base year, full FIRE policy and sustainability claim should apply?", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**95 — Required Minimum Distribution Calculator** (SOURCE_GAP)

Proposed first contract: Prior-year December 31 balance divided by applicable official denominator is source-supported only in appropriate IRA context; full RMD product must retain all intended branches. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Select distribution year, account/owner/beneficiary/spouse facts, applicable table/row and all intended exception, aggregation/deadline and rounding branches.", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**96 — 401(k) Calculator** (SOURCE_GAP)

Proposed first contract: Separate employee-owned and employer-origin asset buckets with tranche vesting are components; full 401(k) plan/year product remains required. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Which plan/year/cohort, compensation definition, employee limits, match/true-up, tranche vesting, forfeiture and tax/distribution rules apply?", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**97 — Roth IRA Calculator** (SOURCE_GAP)

Proposed first contract: Account accumulation plus separately sourced eligibility/distribution branches within complete Roth IRA contract. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Select tax year and full compensation/MAGI/filing-status eligibility, combined IRA limits and distribution qualification/ordering/holding-period exceptions.", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**98 — Traditional IRA Calculator** (SOURCE_GAP)

Proposed first contract: Accumulation and distinct contribution-permission/deduction/basis components within complete Traditional IRA contract. No feature exclusions, renaming or silent product narrowing is authorized.

Questions: ["Select tax year, compensation/filing status, plan coverage and MAGI, deductible versus permitted contributions, basis and all intended distribution branches.", "Approve currency, units, precision/tie policy, all intended product branches, and applicable jurisdiction/effective period?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**120 — Income Tax Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: England/Wales/Northern Ireland 2026/27 annual non-savings employment-income illustration, supplied adjusted net income and reliefs; no Scotland/savings/dividends. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Country/subnational residence, tax year, filing status, taxable base, income classes, allowances, deductions, credits and brackets; UK illustration does not select England or Scotland", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**121 — Take-Home Pay Calculator** (SOURCE_GAP)

Proposed first contract: 2026 US federal periodic employee take-home illustration with one explicitly selected W-4 vintage/pay frequency; state/local and benefits only by explicit separate scope decision. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Country/state/local payroll jurisdiction, payroll year, currency/pay frequency, employee declarations, benefits and employee deductions; withholding output versus final liability", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**122 — Gross-to-Net Salary Calculator** (SOURCE_GAP)

Proposed first contract: 2026 US federal forward gross-to-net periodic wages, one W-4 profile and documented pre/post-tax deductions. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Country/state/local payroll jurisdiction, payroll year, pay frequency, gross-pay inclusions, declarations and pre/post-tax deduction ordering", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**123 — Net-to-Gross Salary Calculator** (SOURCE_GAP)

Proposed first contract: Inverse of the same approved 2026 US federal forward periodic payroll profile within a finite owner-selected gross interval. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["The complete selected forward payroll pack, jurisdiction/year, bounded gross interval, tolerance, solver termination and no-root/multiple-root policy", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**124 — Payroll Tax Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: 2026 US federal employee and employer Social Security/Medicare on supplied covered current and cumulative wages, with separate outputs. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Country/state/local employment jurisdiction/year, employee versus employer output, eligible contribution bases, thresholds, caps and cumulative prior pay", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**125 — Sales Tax Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: New York single delivery-locality taxable-receipt illustration with externally supplied dated combined rate and already-classified taxable sale. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Country/state/local destination or origin jurisdiction, transaction date, product taxability, exemptions, discounts, shipping, inclusive/exclusive price and local rates", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**126 — GST Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: New Zealand single ordinary 15% taxable supply GST addition/extraction; no return or input-credit computation in this proposed first bounded profile. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["GST jurisdiction and filing period, registration, classified supplies, accounting basis, inclusive/exclusive input, credit eligibility and adjustments; NZ illustration is unselected", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**127 — VAT Calculator** (SOURCE_GAP)

Proposed first contract: UK single explicitly classified standard-rated supply illustration with supplied exclusive price; no VAT return or credit entitlement in this proposed first profile. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["VAT jurisdiction and filing period, registration, place/class of supply, zero-rate versus exemption, input-credit entitlement and refund treatment", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**128 — Capital Gains Tax Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: UK resident individual 2026/27 ordinary disposal gains with supplied allowable gains/losses and taxable other income; exclude trusts/carried interest/special relief claims from this proposed profile. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Residence/jurisdiction and disposal tax year, asset class, basis method, acquisition/disposal dates, costs, allowances, losses and other-income interactions", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**129 — Dividend Tax Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: UK resident individual 2026/27 ordinary non-ISA dividends and supplied other taxable income; no foreign-credit/treaty computation in this proposed first profile. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Residence/jurisdiction and tax year, dividend classification, other income, allowances, withholding/imputation/foreign credits and treaty applicability", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**130 — Self-Employment Tax Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: UK 2026/27 ordinary self-employed Class 4 contribution illustration on supplied eligible annual profit; Class 2 status shown separately. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Jurisdiction/tax year, self-employment status, net earnings definition, other employment, contribution class, thresholds, caps and deductible treatment", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**131 — Freelancer Tax Reserve Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: 2026/27 ordinary UK freelancer planning reserve from separately approved income-tax/Class 4 estimates and supplied payments, with explicit remaining periods. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Jurisdiction/tax year, profit/other-income scope, estimated liability pack, payment deadlines, prior withholding/payments and remaining reserve periods", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**132 — Corporate Tax Estimate Calculator** (SOURCE_GAP)

Proposed first contract: UK non-ring-fence company, full 12-month period with no associated companies, supplied taxable profit wholly in the small-profits band; period must be explicitly selected and sourced. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Entity residence/type, corporate jurisdiction, accounting-period dates, taxable adjustments, associated entities, thresholds/apportionment, reliefs and losses", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**133 — Property Tax Estimate Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: New York single selected authority/year assessed-value estimate with supplied approved exemptions and rate per $1,000; resolve identity versus #34. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Exact taxing authorities and assessment year/date, canonical distinction from #34, taxable versus market assessment, exemptions, caps, levy units, fixed assessments and credits", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**134 — Tax Effective Rate Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Supplied-tax effective-rate ratio, positive owner-defined same-period income denominator; no embedded tax-liability engine. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: [["Gross versus taxable income denominator, liability scope and zero/negative-income handling.", "Jurisdiction/effective rule pack and qualified reviewer approval remain unselected."], "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**135 — Tax Marginal Rate Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: 2026/27 England/Wales/Northern Ireland ordinary non-savings statutory band illustration first; finite-difference output only after owner selects it and a complete T function. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Jurisdiction/year and complete T function, statutory bracket versus finite difference output, delta/direction, benefit/credit phase-outs and cliff treatment", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**136 — Salary Sacrifice Calculator** (QUALIFIED_REVIEW_REQUIRED)

Proposed first contract: UK registered-pension salary-sacrifice comparison for a selected period with supplied eligible employer pension contribution and separately approved PAYE/NI forward calculations. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Jurisdiction/year, arrangement eligibility, benefit type/value, employee/employer treatment, minimum-pay constraints, contribution limits and before/after payroll pack", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**137 — Bonus Tax Calculator** (SOURCE_GAP)

Proposed first contract: 2026 US federal separately identified bonus withholding illustration using one owner-selected supplemental/aggregate method, distinct from annual final liability. This is a proposal for owner selection, not an approved exclusion or the full catalog scope.

Questions: ["Jurisdiction/year, bonus payment/pay frequency, aggregate or supplemental withholding method, declarations and separate annual liability computation", "Approve or revise the proposed bounded first profile, required inputs, excluded cases and output meaning?", "Which rounding stages, precision, refund/negative-base treatment and effective-date change policy should govern, after source review?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**198 — Marketplace Fee Calculator** (SOURCE_GAP)

Proposed first contract: Explicit marketplace fee/cost reconciliation with user-supplied assessed gross fees and eligible credits; no automatic provider fee derivation until each provider rule pack is selected. A bounded first contract is not completion of all marketplace coverage.

Questions: ["Select the first marketplace/country/account tier and effective schedule; accept supplied-fee mode as an explicit mode while derived-fee coverage remains pending?", "Approve gross components, refunds/credit funding and display-only rounding; preserve full portfolio scope?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**199 — Etsy Profit Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Explicit US-bank/USD Etsy scenario profile using separately itemized fee bases, account/ad/refund conditions and selected policy revision; all other countries and fees remain explicit open rule-pack work, not excluded product scope.

Questions: ["Approve US-bank/USD initial profile or specify another bank country/currency?", "Select effective policy period, account/ad eligibility and refund funding; approve gross-versus-net inputs?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**468 — Car Affordability Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: User-supplied transport budget and running costs with a selected fixed-rate amortizing-loan scenario.

Questions: ["Budget constraint, income/debt basis, insurance/maintenance/tax costs and financing terms.", "No universal affordability percentage, lender approval or insurance estimate selected.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**469 — Auto Lease Calculator** (SOURCE_GAP)

Proposed first contract: Supplied disclosed lease cap cost, residual, total rent charge, payments, taxes and fees; no inferred money factor.

Questions: ["Money-factor convention, timing, cap-cost reductions, tax/fee treatment and rounding.", "Money factor formula must come from selected lease; cannot universally convert APR/2400.", "Base244.6875 rounds244.69 before adding12.25; totals over48 payments require residual/contract rounding policy, not blind multiplication of rounded payment.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**470 — Lease vs Buy Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Supplied matched-horizon dated lease/buy cash flows including terminal liabilities, value and end charges.

Questions: ["Lease contract, financing, mileage/penalties, terminal value and discounting.", "Matched horizon, mileage, taxes, buyout, residual ownership and fees unselected.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**472 — Loan vs Cash Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Supplied dated cash/loan cash flows at an explicitly selected scenario discount rate.

Questions: ["Cash-flow dates, investment/discount convention, taxes, fees and horizon.", "Opportunity-return scenario not guaranteed; financing cash inflow/down payment and fees must reconcile.", "Adopt the proposed bounded contract, or retain full scope and supply the missing submodel specifications?", "Which jurisdiction, currency, effective period, inclusions, timing and rounding policy should govern?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**488 — Heat Pump Savings Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: Annual operational-energy cost comparison for a conventional non-heat-pump baseline and explicitly supplied useful heat, matching seasonal system efficiency/SCOP and tariffs. Label as scenario estimate; retain capital/payback, delivered-heat and broader system work as unresolved full-scope requirements.

Questions: ["Approve annual operating-cost scenario contract and explicit baseline type/system boundary?", "Select treatment of standing charges, auxiliary, heat demand provenance, capital costs and output precision without treating omissions as full-product completion?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

**516 — GPA Calculator** (OWNER_SELECTION_REQUIRED)

Proposed first contract: An explicitly labeled Stanford general-scale policy snapshot, with user-supplied eligible course units and grades. Repeated/transfer/withdrawn/program-special cases require explicit policies before automated eligibility; retain all intended institution coverage as open work.

Questions: ["Approve first named institutional profile and scope, or select another official institution/year?", "Approve3-decimal illustrative display; obtain official repeat/transfer/withdrawal rules before automated classification?"]

Status: PENDING. Defaults and consequences are in the machine-readable register.

