"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { canTransition, lifecycleStates, qaCheckTypes, requiredQaChecks, roleCanTransition, type AdminRole, type LifecycleState } from "@/lib/admin/publishing";
import { buildVerifiedCatalogRegulatoryMetadata } from "@/calculators/regulatory-metadata";

async function requirePlatformAdmin() {
  const supabase = await createSupabaseServerClient();
  if (!supabase) throw new Error("Supabase is not configured");
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: admin, error: adminError } = await supabase.from("platform_admins").select("role,active").eq("user_id", user.id).maybeSingle();
  if (adminError) throw new Error("Platform admin authorization lookup failed");
  if (!admin?.active) throw new Error("Platform admin access required");
  return { supabase, user, role: String(admin.role) as AdminRole };
}

const createSchema = z.object({
  calculatorKey: z.string().min(2).max(160),
  slug: z.string().regex(/^[a-z0-9-]+$/).max(160),
  title: z.string().min(2).max(160),
  category: z.string().min(2).max(100),
  riskClass: z.enum(["standard", "financial", "health", "tax"]),
  rulePackRequired: z.boolean().default(false)
});

export async function createCatalogCalculator(formData: FormData) {
  const { supabase, user } = await requirePlatformAdmin();
  const input = createSchema.parse({
    calculatorKey: formData.get("calculatorKey"),
    slug: formData.get("slug"),
    title: formData.get("title"),
    category: formData.get("category"),
    riskClass: formData.get("riskClass"),
    rulePackRequired: formData.get("rulePackRequired") === "true"
  });
  const registryRegulatory = buildVerifiedCatalogRegulatoryMetadata({ id: input.calculatorKey, slug: input.slug });
  if (!registryRegulatory.matched) throw new Error("Catalog identity must exactly match a registered calculator id and slug");
  const effectiveRulePackRequired = input.rulePackRequired || registryRegulatory.rulePackRequired;
  const regulatoryMetadata = registryRegulatory.rulePackRequired ? { rulePackRequired: true, ruleMetadata: registryRegulatory.ruleMetadata } : { rulePackRequired: effectiveRulePackRequired };
  const { error } = await supabase.rpc("create_catalog_calculator_with_audit", {
    p_calculator_key: input.calculatorKey,
    p_slug: input.slug,
    p_title: input.title,
    p_category: input.category,
    p_risk_class: input.riskClass,
    p_metadata: regulatoryMetadata
  });
  if (error) throw new Error(error.message);
  revalidatePath("/admin");
  revalidatePath("/admin/calculators");
}


export async function addCalculatorSourceEvidence(formData: FormData) {
  const { supabase, user, role } = await requirePlatformAdmin();
  if (!(["owner", "admin", "reviewer"] as AdminRole[]).includes(role)) throw new Error("Reviewer permission required");
  const calculatorId = z.string().uuid().parse(formData.get("calculatorId"));
  const label = z.string().min(2).max(300).parse(formData.get("label"));
  const url = z.string().url().max(2000).parse(formData.get("url"));
  const sourceKind = z.enum(["reference", "official", "methodology"]).parse(formData.get("sourceKind") ?? "reference");
  const { data: calculator, error: calculatorError } = await supabase.from("calculator_catalog_admin").select("id").eq("id", calculatorId).maybeSingle();
  if (calculatorError || !calculator) throw new Error("Calculator lookup failed");
  const { error } = await supabase.from("calculator_source_evidence").insert({
    calculator_id: calculatorId, label, url, source_kind: sourceKind, reviewed_by: user.id
  });
  if (error) throw new Error(error.message);
  revalidatePath(`/admin/calculators/${calculatorId}`);
}

export async function updateQaCheck(formData: FormData) {
  const { supabase, user, role } = await requirePlatformAdmin();
  if (!(["owner", "admin", "reviewer"] as AdminRole[]).includes(role)) throw new Error("Reviewer permission required");
  const calculatorId = z.string().uuid().parse(formData.get("calculatorId"));
  const checkType = z.enum(qaCheckTypes).parse(formData.get("checkType"));
  const status = z.enum(["pending", "passed", "failed", "waived"]).parse(formData.get("status"));
  if (status === "waived" && !(["owner", "admin"] as AdminRole[]).includes(role)) throw new Error("Owner or admin permission required to waive QA evidence");
  const { data: calculator, error: calculatorError } = await supabase.from("calculator_catalog_admin").select("risk_class,metadata").eq("id", calculatorId).maybeSingle();
  if (calculatorError || !calculator) throw new Error("Calculator lookup failed");
  const riskClass = z.enum(["standard", "financial", "health", "tax"]).parse(calculator.risk_class);
  if (!requiredQaChecks(riskClass, calculator.metadata?.rulePackRequired === true).includes(checkType)) throw new Error("QA check is not applicable to this calculator");
  const details = String(formData.get("details") ?? "").slice(0, 2000);
  const { error } = await supabase.rpc("record_calculator_qa_decision", {
    p_calculator_id: calculatorId, p_check_type: checkType, p_status: status, p_details: details
  });
  if (error) throw new Error(error.message);
  revalidatePath(`/admin/calculators/${calculatorId}`);
  revalidatePath("/admin");
}

export async function transitionCalculator(formData: FormData) {
  const { supabase, user, role } = await requirePlatformAdmin();
  const calculatorId = z.string().uuid().parse(formData.get("calculatorId"));
  const target = z.enum(lifecycleStates).parse(formData.get("target")) as LifecycleState;
  const { data: calculator, error: calculatorError } = await supabase.from("calculator_catalog_admin").select("lifecycle").eq("id", calculatorId).maybeSingle();
  if (calculatorError || !calculator) throw new Error("Calculator lifecycle lookup failed");
  const current = String(calculator.lifecycle) as LifecycleState;
  if (!canTransition(current, target)) throw new Error(`Invalid lifecycle transition: ${current} → ${target}`);
  if (!roleCanTransition(role, target)) throw new Error("Your role cannot perform this transition");
  if (target === "certified" || target === "published") {
    const { data: gate, error: gateError } = await supabase.rpc("validate_calculator_publish_gate", { p_calculator_id: calculatorId });
    if (gateError) throw new Error(gateError.message);
    const result = Array.isArray(gate) ? gate[0] : gate;
    if (!result?.ok) throw new Error(`Publishing gate failed: ${(result?.failures ?? []).join("; ")}`);
  }
  const { error } = await supabase.rpc("transition_calculator_with_audit", {
    p_calculator_id: calculatorId, p_expected_lifecycle: current, p_target_lifecycle: target
  });
  if (error) throw new Error(error.message);
  revalidatePath(`/admin/calculators/${calculatorId}`);
  revalidatePath("/admin");
}

export async function assignReviewer(formData: FormData) {
  const { supabase, user, role } = await requirePlatformAdmin();
  if (!(["owner", "admin"] as AdminRole[]).includes(role)) throw new Error("Admin permission required");
  const calculatorId = z.string().uuid().parse(formData.get("calculatorId"));
  const reviewerId = z.string().uuid().parse(formData.get("reviewerId"));
  const { error } = await supabase.rpc("assign_calculator_reviewer", {
    p_calculator_id: calculatorId, p_reviewer_id: reviewerId
  });
  if (error) throw new Error(error.message);
  revalidatePath(`/admin/calculators/${calculatorId}`);
}

const bulkItemSchema = z.object({
  calculatorKey: z.string().min(2).max(160), slug: z.string().regex(/^[a-z0-9-]+$/).max(160), title: z.string().min(2).max(160),
  category: z.string().min(2).max(100), riskClass: z.enum(["standard", "financial", "health", "tax"]).default("standard"), rulePackRequired: z.boolean().default(false)
});

export async function importCalculatorInventory(formData: FormData) {
  const { supabase, user, role } = await requirePlatformAdmin();
  if (!(["owner", "admin"] as AdminRole[]).includes(role)) throw new Error("Admin permission required");
  const raw = String(formData.get("inventory") ?? "");
  const parsed = z.array(bulkItemSchema).min(1).max(250).parse(JSON.parse(raw));
  // Resolve and validate deterministic registry identities before creating a processing job.
  // A conflicting id/slug must fail without leaving an orphaned job row behind.
  const rows = parsed.map((item) => {
    const registryRegulatory = buildVerifiedCatalogRegulatoryMetadata({ id: item.calculatorKey, slug: item.slug });
    if (!registryRegulatory.matched) throw new Error(`Catalog identity must exactly match the registry: ${item.calculatorKey} / ${item.slug}`);
    const effectiveRulePackRequired = item.rulePackRequired || registryRegulatory.rulePackRequired;
    return { calculator_key: item.calculatorKey, slug: item.slug, title: item.title, category: item.category, risk_class: item.riskClass, metadata: registryRegulatory.rulePackRequired ? { rulePackRequired: true, ruleMetadata: registryRegulatory.ruleMetadata } : { rulePackRequired: effectiveRulePackRequired }, created_by: user.id };
  });
  const { data: job, error: jobError } = await supabase.from("calculator_bulk_jobs").insert({ job_type: "inventory-import", requested_by: user.id, status: "processing", payload: { count: parsed.length } }).select("id").single();
  if (jobError) throw new Error(jobError.message);
  const { data: inserted, error } = await supabase.from("calculator_catalog_admin").upsert(rows, { onConflict: "calculator_key", ignoreDuplicates: true }).select("id,risk_class,metadata");
  if (error) {
    await supabase.from("calculator_bulk_jobs").update({ status: "failed", error_message: error.message, completed_at: new Date().toISOString() }).eq("id", job.id);
    throw new Error(error.message);
  }
  const checkRows = (inserted ?? []).flatMap((item) => requiredQaChecks(String(item.risk_class) as "standard" | "financial" | "health" | "tax", item.metadata?.rulePackRequired === true).map((checkType) => ({ calculator_id: item.id, check_type: checkType })));
  if (checkRows.length) await supabase.from("calculator_qa_checks").upsert(checkRows, { onConflict: "calculator_id,check_type", ignoreDuplicates: true });
  await supabase.from("calculator_bulk_jobs").update({ status: "completed", result: { received: parsed.length, inserted: inserted?.length ?? 0 }, completed_at: new Date().toISOString() }).eq("id", job.id);
  revalidatePath("/admin");
  revalidatePath("/admin/calculators");
}
