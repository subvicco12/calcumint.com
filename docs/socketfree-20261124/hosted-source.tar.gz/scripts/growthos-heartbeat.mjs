import crypto from 'node:crypto';

const control = (process.env.GROWTHOS_CONTROL_PLANE_URL || 'https://growthos.converentis.com').replace(/\/$/, '');
const secret = process.env.GROWTHOS_CONNECTOR_SECRET;
const siteId = process.env.GROWTHOS_SITE_ID;
const kind = process.env.GROWTHOS_CONNECTOR_KIND || 'webapp';

if (!siteId || !/^\d+$/.test(siteId)) throw new Error('GROWTHOS_SITE_ID missing or invalid');
if (!secret || secret.length < 32) throw new Error('GROWTHOS_CONNECTOR_SECRET missing or too short');

const timestamp = new Date().toISOString();
const nonce = crypto.randomBytes(24).toString('hex');
const requestId = crypto.randomUUID();
const snapshot = { plugins: [], routes: [], features: ['server-heartbeat'], capturedAt: timestamp };
const body = JSON.stringify(snapshot);
const canonicalPayload = [siteId, timestamp, nonce, requestId, body].join('\n');
const signature = crypto.createHmac('sha256', secret).update(canonicalPayload).digest('hex');

const url = new URL('/wp-json/growthos/v1/connectors/heartbeat', control);
url.searchParams.set('site_id', siteId);
url.searchParams.set('kind', kind);
const signal = AbortSignal.timeout(15000);
const res = await fetch(url, { method: 'POST', signal, headers: { 'content-type': 'application/json', 'x-growthos-timestamp': timestamp, 'x-growthos-nonce': nonce, 'x-growthos-request-id': requestId, 'x-growthos-signature': signature }, body });
const responseText = await res.text();
if (!res.ok) throw new Error('GrowthOS heartbeat failed ' + res.status + ': ' + responseText);
console.log(responseText);
