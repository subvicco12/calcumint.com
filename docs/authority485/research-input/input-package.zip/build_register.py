import json,pathlib,csv,hashlib,collections
p=pathlib.Path(__file__).parent;b=p.parent
def read(path):return json.loads(path.read_text())
def write(n,d):(p/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
base=read(p/'blocked-cases-43.json');byid={r['masterId']:r for r in base};rows=[]
for lane in ['finance','uk','us','clinical','technical','business']:
 d=read(p/f'{lane}-resolution.json');a=d.get('rows',d) if isinstance(d,dict) else d
 for old in a:
  r=dict(old);i=r['masterId'];r['title']=byid[i]['title'];r['researchLane']=lane
  r['authorityDisposition']=r['status'];r['baselineSHA']='f7912be103b596b5b8bf4a325667fd2e5a2cb30d'
  r['baselineManifestImplementationClass']='CONTRACT_BLOCKED';r['baselineContractRequirement']=byid[i]['contractDecision'];r['baselineEngineeringEvidence']=byid[i]['engineeringEvidence']
  r['sourceAuthorityMeaning']='Research overlay only. SOURCE_RESOLVED means expressly bounded profile source support, not whole-calculator canonical acceptance. Secondary policy, applicability, original-data binding and engine gates remain.'
  r['preciseRemainingRequirement']=r.get('preciseBlocker',r.get('preciseMissing',r.get('remainingQualifiedDecisions')))
  r['remainingDecisions']=r.get('remainingDecisions',r.get('ownerChoices',r.get('remainingQualifiedDecisions',[])))
  r['exactCodexTasks']=r.get('exactCodexTasks',r.get('codexPreparationTasks',[]))
  r['numericalEvidence']=r.get('independentExamples',r.get('independentReferenceCalculations',r.get('independentNumericalExamples')))
  r['ownerAdopted']=False;r['canonicalScopeAdopted']=False;r['actualEngineAcceptance']=False;r['canonicalAccepted']=False;r['certificationAuthorized']=False;r['publicationAuthorized']=False;r['releaseHold']=True
  r['engineeringContractAvailability']='BOUNDED_SOURCE_SUPPORTED_SPECIFICATION_PENDING_ADOPTION_AND_BINDING' if r['status']=='SOURCE_RESOLVED' else 'CONDITIONAL_PROPOSAL_ONLY_NOT_IMPLEMENTATION_AUTHORITY'
  rows.append(r)
rows.sort(key=lambda r:r['masterId']);assert len(rows)==43 and {r['masterId'] for r in rows}==set(byid)
counts=dict(collections.Counter(r['status'] for r in rows));assert counts=={'SOURCE_PARTIAL':16,'POLICY_DECISION_REQUIRED':13,'QUALIFIED_APPLICABILITY_REQUIRED':13,'SOURCE_RESOLVED':1},counts
summary={'cases':43,'dispositions':counts,'boundedSourceSupportedProfiles':1,'wholeCanonicalCalculatorsAccepted':0,'engineAcceptancesThisTask':0,'certificationsGranted':0,'publicationsGranted':0,'retainedOriginalQualifiedRequirements':11,'additionalQualifiedApplicabilityRecommendations':[136,522],'originalImplementationManifestChanged':False,'acceptanceLedgerChanged':False}
write('resolution-register-43.json',{'schemaVersion':1,'date':'2026-10-30','candidate':{'repository':'subvicco12/calcumint.com','pr':1492,'headSHA':'f7912be103b596b5b8bf4a325667fd2e5a2cb30d','observedState':'open,draft,unmerged','manifestCSVGitBlob':'90940e4f79fd1b862cfdb8440f96a0484b02d923'},'summary':summary,'releaseHold':True,'rows':rows})
with (p/'resolution-register-43.csv').open('w') as f:
 cols=['masterId','title','status','researchLane','preciseRemainingRequirement','supportedContract','remainingDecisions','engineeringContractAvailability','canonicalAccepted','actualEngineAcceptance'];w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
 for r in rows:w.writerow({k:json.dumps(r[k],ensure_ascii=False) if isinstance(r[k],(list,dict)) else r[k] for k in cols})
source=[]
for lane in ['finance','uk','us','clinical','technical','business']:
 d=read(p/f'{lane}-provenance.json');a=d.get('sources',d.get('newSources',[]))
 for n,s in enumerate(a):source.append({'sourceKey':f'{lane}:{n+1}','provenanceFile':f'{lane}-provenance.json','originalSourceRecord':s,'recordSHA256':hashlib.sha256(json.dumps(s,ensure_ascii=False,sort_keys=True).encode()).hexdigest()})
write('source-provenance-index.json',{'meaning':'Original publisher-byte hashes only where expressly obtained. Other hashes cover normalized text or retrieval observations; they are not substituted for raw publisher bodies. Some full copyrighted captures retained internally only, with provenance/hash retained here.','sourceRecords':len(source),'rows':source})
write('owner-decisions.json',{'status':'PENDING_NO_ADOPTION','meaning':'Owner may choose profile exposure/output policies; user-selectable methods are proposed where appropriate. Owner choice cannot replace missing facts, qualified competence, authoritative rules or identity acceptance.','rows':[{'masterId':r['masterId'],'title':r['title'],'primaryDisposition':r['status'],'choices':r['remainingDecisions'],'profiles':r.get('proposedProfiles',r.get('selectableProfiles',r.get('selectableProfile'))),'approval':'PENDING','profileMayBeUserSelectable':True,'unsupportedProfiles':'Unavailable with explicit reason; full product backlog preserved.'} for r in rows]})
write('retained-qualified-requirements-11.json',read(b/'methodology-50-20261026/retained-qualified-cases-11.json'))
write('readiness-summary.json',{'summary':summary,'releaseDecision':'NO_GO','releaseHold':True,'note':'Research dispositions do not change PR1492 implementation classes or424ledger statuses. One electricity component is source-supported, not a completed whole Carbon Footprint calculator.'})
write('codex-handoff-43.json',{'candidateSHA':'f7912be103b596b5b8bf4a325667fd2e5a2cb30d','prohibited':'No production access/writes, merge, deployment, certification or publication. This research package does not approve pending policies or overwrite frozen engines.','rows':[{'masterId':r['masterId'],'status':r['status'],'contractAvailability':r['engineeringContractAvailability'],'bindingCandidateSources':byid[r['masterId']]['contractDecision'].get('sourcePaths',[]),'specification':r['supportedContract'],'remainingDependencies':r['remainingDecisions'],'nextTasks':r['exactCodexTasks'],'actualEngineExecuted':False} for r in rows]})
print(json.dumps(summary,indent=2))
