# Independent review and validation

Exact43 blocked IDs match the pinned540-row CSV. CSV and three smaller JSON source-input bytes match their Gitblob identities. This is selection/identity verification, not a repeated540-row engineering acceptance audit. Candidate PR1492 observed open/draft/unmerged atf7912be103b596b5b8bf4a325667fd2e5a2cb30d.

Final dispositions:1 SOURCE_RESOLVED bounded electricity component;16 SOURCE_PARTIAL;13 POLICY_DECISION_REQUIRED;13 QUALIFIED_APPLICABILITY_REQUIRED. All43 remain unadopted, canonicalAccepted=false, actualEngineAcceptance=false, certification/publication=false and releaseHold=true. Original11 retained qualified IDs are unchanged;136/522 are separate recommendations. Contract485 content hash was recomputed; two IRS publisher HTML hashes match captured files.

Targeted independent reviewer inspected source-resolved claims112/485 and root199 example. Arithmetic matched: hourly950; salary427.50; electricity100kWh ->13.096kgCO2e; US-case seller receipts110 and processing base118 produce52.86profit before other explicitly absent charges. One medium finding:112 sourceResolved overstates unknown fractional-cent rounding. Corrected toSOURCE_PARTIAL; no unresolved review finding for that claim. Review is targeted research-boundary/math checking, not clinical/accounting approval or independent execution of43 application engines.

Root independently reproduced six ID-level exact reference calculations using Fraction/Decimal; lane numerical witnesses preserved. No actual CalcuMint engine executed in this research task. Numeric source examples, supplied-input synthetic witnesses and empirical validation remain explicitly distinct.

Old IRS590-A malformed Roth upper threshold retained; two focused official sources corroborate intended252000. No invented erratum. No mathematical implementation defect was established from that source typo. Missing dates, tables, round stages and qualified applicability are preserved. Original source/ledger/engine files were not modified.

No production access, SQL, migration, merge, deployment, live payment, certification, publication, external outreach or network-configuration change occurred. Public-research retrieval only. Original evidence ZIP is included under prior-inputs; this does not adopt its pending proposals. Some raw third-party retrieval captures are omitted from delivery; source-capture-index.json preserves authentic local capture hashes and clearly indicates non-inclusion. No hash is silently relabeled as original publisher bytes.
