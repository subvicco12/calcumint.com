# CalcuMint — remaining43 calculator authority blockers

Research date:30 October2026. Exact engineering candidate PR1492: `f7912be103b596b5b8bf4a325667fd2e5a2cb30d`, observed open/draft/unmerged. RELEASE HOLD.

## Actual outcome

| Primary research disposition | Count |
|---|---:|
| SOURCE_RESOLVED — bounded component source authority only |1|
| SOURCE_PARTIAL — additional governing evidence needed |16|
| POLICY_DECISION_REQUIRED |13|
| QUALIFIED_APPLICABILITY_REQUIRED |13|
| Whole canonical calculators accepted or newly certified/published |0|

These are research dispositions, not edits to the implementation manifest. All43 remain subject to exact canonical scope/mapping, actual-engine acceptance and applicable lifecycle gates. The one resolved source profile is a UK2026 purchased-electricity Scope2 component of #485; it is not completion of the full Carbon Footprint calculator. Its native workbook-byte/cell binding and adopted engine/display contract remain pending. Zero source-complete whole canonical calculators are claimed.

All11 original retained qualified requirements remain unchanged. IDs136 and522 add recommendations for qualified applicability review in this research overlay only; they do not amend governance classifications or establish a statutory signature mandate. The primary qualified cohort is87,136,404,405,406,407,408,409,410,502,522,526,530.

## Exact43-case disposition

| ID | Calculator | Disposition |
|---:|---|---|
|9|APR Calculator|SOURCE_PARTIAL|
|19|Credit Card Minimum Payment Calculator|SOURCE_PARTIAL|
|20|Balance Transfer Calculator|SOURCE_PARTIAL|
|23|HELOC Calculator|SOURCE_PARTIAL|
|34|Property Tax Calculator|POLICY_DECISION_REQUIRED|
|48|Investment Property Affordability Calculator|POLICY_DECISION_REQUIRED|
|87|Safe Withdrawal Rate Calculator|QUALIFIED_APPLICABILITY_REQUIRED|
|92|Pension Calculator|POLICY_DECISION_REQUIRED|
|95|Required Minimum Distribution Calculator|SOURCE_PARTIAL|
|97|Roth IRA Calculator|SOURCE_PARTIAL|
|98|Traditional IRA Calculator|SOURCE_PARTIAL|
|112|Overtime Pay Calculator|SOURCE_PARTIAL|
|120|Income Tax Calculator|SOURCE_PARTIAL|
|121|Take-Home Pay Calculator|POLICY_DECISION_REQUIRED|
|122|Gross-to-Net Salary Calculator|POLICY_DECISION_REQUIRED|
|123|Net-to-Gross Salary Calculator|POLICY_DECISION_REQUIRED|
|124|Payroll Tax Calculator|POLICY_DECISION_REQUIRED|
|128|Capital Gains Tax Calculator|SOURCE_PARTIAL|
|129|Dividend Tax Calculator|SOURCE_PARTIAL|
|130|Self-Employment Tax Calculator|SOURCE_PARTIAL|
|131|Freelancer Tax Reserve Calculator|POLICY_DECISION_REQUIRED|
|132|Corporate Tax Estimate Calculator|SOURCE_PARTIAL|
|135|Tax Marginal Rate Calculator|POLICY_DECISION_REQUIRED|
|136|Salary Sacrifice Calculator|QUALIFIED_APPLICABILITY_REQUIRED|
|137|Bonus Tax Calculator|POLICY_DECISION_REQUIRED|
|173|Customer Lifetime Value Calculator|POLICY_DECISION_REQUIRED|
|198|Marketplace Fee Calculator|POLICY_DECISION_REQUIRED|
|199|Etsy Profit Calculator|SOURCE_PARTIAL|
|204|Return Rate Impact Calculator|SOURCE_PARTIAL|
|404|Target Heart Rate Calculator|QUALIFIED_APPLICABILITY_REQUIRED|
|405|Pregnancy Due Date Calculator|QUALIFIED_APPLICABILITY_REQUIRED|
|406|Pregnancy Weight Gain Calculator|QUALIFIED_APPLICABILITY_REQUIRED|
|407|Ovulation Calculator|QUALIFIED_APPLICABILITY_REQUIRED|
|408|Conception Calculator|QUALIFIED_APPLICABILITY_REQUIRED|
|409|GFR Calculator|QUALIFIED_APPLICABILITY_REQUIRED|
|410|Sleep Calculator|QUALIFIED_APPLICABILITY_REQUIRED|
|442|Currency Converter|POLICY_DECISION_REQUIRED|
|485|Carbon Footprint Calculator|SOURCE_RESOLVED|
|502|Cooking Time Adjustment Calculator|QUALIFIED_APPLICABILITY_REQUIRED|
|522|Race Time Predictor|QUALIFIED_APPLICABILITY_REQUIRED|
|526|Training Heart Rate Calculator|QUALIFIED_APPLICABILITY_REQUIRED|
|527|Golf Handicap Calculator|SOURCE_PARTIAL|
|530|VO2 Max Estimate Calculator|QUALIFIED_APPLICABILITY_REQUIRED|

## Genuine source progress

- IRS2026 Publications15/15-T: selected Worksheet1A/annual percentage table, cumulative FICA, supplemental wage eligibility/methods and fractions-of-cents clauses captured. Five payroll contracts now have substantive source formulas/tables, but profile, output, permitted FIT rounding and FICA cent-tie policies remain pending. #123 depends on the exact accepted forward engine; inverse semantics are product choices.
- Full CLV primary note retrieved, replacing first-page-only evidence. It distinguishes initial-payment inclusion, cashflow timing and contractual retention from repeat buying. Selecting which model a product should expose remains a policy decision, not missing elementary math.
- Full2026 emissions methodology and full/revised-flat datasets parsed and cross-checked for one published UK electricity row. Original XLSX bytes/native cell coordinates were not obtained, and no workbook binary hash is invented. Riegel primary paper now readable, but historical record regressions are not individual-performance validation.
- Issuer sample terms, HELOC disclosures, APR regulatory text and DOL overtime text retrieved. Samples are not proof that the same offer/agreement governs a user's account. Some APR equations remain images; full irregular APR is not resolved.
- HMRC/legal material adds marginal-relief structure and worked examples; historical Tax Logic and FY tables are not silently treated as2026/27 authority. Wage, pension, clinical and accounting applicability cannot be inferred from a generic source page.
- Clinical sources improve population/protocol evidence, but all10 clinical/food cases retain qualified applicability decisions. Complete ACOG redating authority remains inaccessible; food roasting tables do not establish an arbitrary cooking-time transformation. Golf formula/selection tables and current national adoption remain incomplete.

## Corrected findings and source anomalies

Independent targeted review found no arithmetic error in #112 hourly example, #485 factor/units/date, or #199 seller-receipts versus processing-base example. It found one medium classification overstatement: #112 had been called source-resolved despite unresolved fractional-cent rounding. That row is now SOURCE_PARTIAL. Its arithmetic evidence is retained without claiming full payable-wage policy.

The retrieved IRS590-A text contains malformed2026 Roth MFJ upper bound `$252,0000`. Focused official COLA Notice2025-67 and IRS IR-2025-111 corroborate `$252,000`; the discrepancy is preserved with proposed clause-specific source priority. No erratum or silent correction is asserted. #97 remains partial for other contract branches.

AASB15 December2022 compilation expressly applies to annual periods starting2023-01-01 but before2026-07-01; the index separately lists amendments effectiveJuly2026. The older compilation's current-page label is insufficient for later periods. Earlier future-dated appendix evidence is not automatically current. Etsy last-update dates remain distinct from effective periods; provider fee rounding/eligibility and general/specific refund wording remain unresolved where material.

## Exact engineering contracts and handoff

`source-supported-contract-485.json` is a content-hashed proposed specification bound to this exact engineering baseline, published factor identifier/version, units, boundaries, rejection cases and exact-decimal outputs. It does not mint a runtime version or approve catalog mapping. Expose only the explicit component after adoption and native-data binding; keep all other footprint profiles unavailable and tracked until supported.

`codex-handoff-43.json` preserves supported mathematics, original candidate file references, all remaining dependencies and per-ID tasks. All other cases have conditional proposals only. Do not use a supplied percentage/cost vector to claim completion of a regulated, account-specific or empirical model. Provider/jurisdiction/year/method choices may be user-selectable only after the available profile set and input semantics are governed. Unsupported choices must produce an explicit unavailable/unsupported result, never guessed rates or silent zeroes.

No formula implementation changes are made or required by this report. An existing engine/helper is only a candidate until inspected at the pinned SHA and mapped to the approved immutable contract. A different future engineering head must rebind the affected source/implementation identity; it cannot inherit an exact-SHA claim by name alone.

## Smallest dependency-ordered next path

1. Adopt explicit profile/output policies for13 policy-primary cases, or expose governed user-selectable modes with no inferred defaults. Preserve full canonical requirements; initial bounded components are not feature exclusions. Resolve independent source-primary cases in parallel.
2. For #485, freeze native workbook bytes/cells and source attribution, adopt the explicit component contract, bind a candidate engine/version/SHA and run the provided independent exact-decimal vectors. This progresses one component only.
3. Complete the16 source-partial packs: governing issuer/offer/HELOC terms and timing, APR image equations, current tax/IRA exception/rounding rules, provider dated-fee/credit rules, accounting amendments, and complete applicable golf rules. A missing policy cannot be fixed by a generic arithmetic helper.
4. Obtain version-bound qualified applicability decisions for the13 primary cases. Keep original11 requirements distinct from additional136/522 recommendations. No owner-only or AI signature substitutes for qualified acceptance.
5. Implement only adopted/sufficient contracts through the authorized engineering workflow, then run actual-engine golden/boundary/rounding/error cases and exact ID/version/dependency/source-hash checks. No mass canonical mapping approval. Existing publication, security, specialist, operational and release gates remain separately mandatory.

## Provenance and scope limits

The pinned540-row CSV was filtered to43 blocked identities; the completed general reconciliation was not repeated. Its Gitblob and the three smaller source inputs match exact Gitblobs. The5,045,939-byte JSON implementation manifest could not be retrieved by the GitHub connector size path; no full JSON-body review is claimed. Exact identities and current blocker requirements are sourced from the pinned companion CSV, reconciliation inputs, engineering register and generator logic. Original inputs are included.

Existing50-case methodology,42-source observations and risk decisions were reused. New retrieval focused on missing clauses/protocols/versions rather than rerunning the earlier42-URL campaign. Source provenance separates original IRS HTML-byte hashes, extracted/parsed text hashes, source-record hashes and unknown publisher-byte hashes. Some copyrighted source captures are retained internally only; source links, paraphrased findings and authentic capture hashes remain in the dossier. Their absence from the delivery archive is explicitly indexed. Full newly retrieved source bodies are not redistributed in this dossier; selected facts, contract extracts, source links and capture hashes are included. Extraction fidelity is not certification of tables/images or licences.

Research arithmetic checks are not application-engine execution. Six independent ID-level reference checks were reproduced at root and lane-specific witnesses retained. No production access, SQL, migrations, merges, deployments, payments, certification or publication occurred. No repository source branch was changed. All540 identities,424ledger records, historical versions and original14privateDRAFTs are preserved by no writes; this is not a new production-state audit.

## Files to use

- `resolution-register-43.json` / `.csv`: complete exact-ID resolution overlay.
- `codex-handoff-43.json` / `CODEX-HANDOFF.md`: conditional implementation and validation tasks.
- `source-supported-contract-485.json`: the one source-supported component specification.
- `owner-decisions.json`: explicit remaining profile/output choices, all pending.
- Six lane resolution/provenance files plus `source-provenance-index.json`: clauses, versions, limitations, hashes and examples.
- `retained-qualified-requirements-11.json`: unchanged mandatory cohort.
- `independent-arithmetic-checks.json`, `REVIEW-AND-VALIDATION.md`, `MANIFEST-SHA256.json`.

**Production NO-GO. RELEASE HOLD remains active.**
