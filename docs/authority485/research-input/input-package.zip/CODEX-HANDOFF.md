# Codex — authority resolution handoff at PR1492

Exact baseline `f7912be103b596b5b8bf4a325667fd2e5a2cb30d`. Research does not change existing43 CONTRACT_BLOCKED classifications or authorize publication. Do not repeat540 reconciliation or prior42-source browsing.

One source-supported bounded specification: #485 UK2026 Scope2 purchased-electricity component. Review `source-supported-contract-485.json`, adopt only approved profile/mapping, freeze native source data and run exact-decimal vectors. Other footprint functionality remains unresolved.

All other rows are conditional; source detail and explicit dependencies are in `resolution-register-43.json` and `codex-handoff-43.json`.

## 9 — APR Calculator (SOURCE_PARTIAL)

Remaining dependency: "US closed-end regular single-advance actuarial APR from already legally determined amount financed and positive scheduled equal monthly payments; full irregular/image equations and finance-charge classification unresolved"

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/finance/rate-conversion.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 19 — Credit Card Minimum Payment Calculator (SOURCE_PARTIAL)

Remaining dependency: "Single statement sample Chase COL00040 minimum, no pastdue or special financing; statement-supplied interest and latefees. Actual chosen card and rounding missing"

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/finance/credit-card-payoff.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 20 — Balance Transfer Calculator (SOURCE_PARTIAL)

Remaining dependency: "Named sample offer supplies promotional fees/rates; sample agreement compatibility not established. No complete approved allocation/capitalization/calendar contract"

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/finance/credit-card-payoff.ts", "src/calculators/finance/loan-analysis.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 23 — HELOC Calculator (SOURCE_PARTIAL)

Remaining dependency: "BofA/Merrill disclosure supports phase/options; not complete signed HELOC contract"

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/finance/credit-card-payoff.ts", "src/calculators/finance/loan-analysis.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 34 — Property Tax Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "No taxing authority/class/year selected; prior NYC example cannot govern global property tax"

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/finance/mortgage.ts", "src/calculators/finance/roi.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 48 — Investment Property Affordability Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "Investment-property affordability definition and financing/tax/cost inclusions unselected"

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/finance/mortgage.ts", "src/calculators/finance/roi.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 87 — Safe Withdrawal Rate Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: "Empirical safe-withdrawal methodology/population/asset paths/success criterion unselected; compound interest is not empirical safety evidence"

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/finance/investment-math.ts", "src/calculators/finance/savings-goal.ts", "src/calculators/finance/swp.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 92 — Pension Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "Named pension plan/formula/service/earnings/vesting/survivor/early-retirement contract absent; IRS RMD is not pension-benefit formula"

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/finance/investment-math.ts", "src/calculators/finance/savings-goal.ts", "src/calculators/finance/swp.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 95 — Required Minimum Distribution Calculator (SOURCE_PARTIAL)

Remaining dependency: "Bounded 2026 original-owner traditional IRA TableIII profile supported; no complete inherited/spouse/plan/deadline/rounding contract selected"

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/finance/investment-math.ts", "src/calculators/finance/savings-goal.ts", "src/calculators/finance/swp.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 97 — Roth IRA Calculator (SOURCE_PARTIAL)

Remaining dependency: "2025 US original-owner Roth contribution and qualification branches now fully retrievable; full intended conversions/inherited/excess branches unselected;2026 typo unresolved"

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/finance/investment-math.ts", "src/calculators/finance/savings-goal.ts", "src/calculators/finance/swp.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 98 — Traditional IRA Calculator (SOURCE_PARTIAL)

Remaining dependency: "2025 contribution permission distinct from deduction; full rules captured but complete product branches and year unselected"

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/finance/investment-math.ts", "src/calculators/finance/savings-goal.ts", "src/calculators/finance/swp.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 112 — Overtime Pay Calculator (SOURCE_PARTIAL)

Remaining dependency: "Bounded FLSA covered nonexempt single straight-time hourly rate, one workweek, no other remuneration or exclusions; jurisdiction/exemption applicability remains separate Fact23 does not settle fractional-cent rounding precision/tie/stage; required owner payroll policy remains UNKNOWN."

Tasks: {"condition": "After explicit profile selection and unresolved contract/applicability decisions; no implementation now", "sourceFileCandidates": ["src/calculators/core/percentage.ts", "src/calculators/launch-portfolio.ts", "src/calculators/registry.ts"], "tasks": ["Inspect source candidates at PR1492 SHA f7912be103b596b5b8bf4a325667fd2e5a2cb30d; candidates are not approved identity binding.", "Encode selected clauses, units, dates and rejection behavior; preserve all intended branches or explicitly obtain scope decision.", "Run actual selected engine against independent exact examples and threshold/date/rounding branches; record expected/actual and version hashes.", "Retain RELEASE HOLD; no certification, publication or production writes."]}

## 120 — Income Tax Calculator (SOURCE_PARTIAL)

Remaining dependency: "2026/27 liability rounding/stages and approved allowance/base treatment remain missing; 2024/25 guide cannot fill them."

Tasks: ["For #120, close the preciseBlocker using the stated missing authoritative clauses before implementing a tax evaluator.", "After explicit profile/source/applicability decisions, specify #120 inputs, unsupported-scope validation and exact rounding stages; preserve all other catalog scope as unavailable.", "Only after authorization, bind #120 to reviewed implementation/full SHA and run independent boundary, exception and rounding cases; retain failures."]

## 121 — Take-Home Pay Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "Missing Worksheet1A/table/supplemental source content is now captured for the proposed bounded profile. Owner has not selected federal-only profile/output, consistent optional FIT rounding, FICA cent-tie policy or validated wage-base/deduction scope; qualified applicability and actual engine acceptance remain separate."

Tasks: ["After explicit contract adoption implement versioned forward withholding pack for 2026 profile, preserving decimal/rational intermediates; reject unsupported scope", "Run independent table-boundary, W4-credit floor, annualization, SS-cap crossing, Medicare threshold crossing and rounding cases against actual mapped full-SHA engine; retain results", "Keep RELEASE HOLD; no code changes, production access, merge, publication or certification authorized"]

## 122 — Gross-to-Net Salary Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "Missing Worksheet1A/table/supplemental source content is now captured for the proposed bounded profile. Owner has not selected federal-only profile/output, consistent optional FIT rounding, FICA cent-tie policy or validated wage-base/deduction scope; qualified applicability and actual engine acceptance remain separate."

Tasks: ["After explicit contract adoption implement versioned forward withholding pack for 2026 profile, preserving decimal/rational intermediates; reject unsupported scope", "Run independent table-boundary, W4-credit floor, annualization, SS-cap crossing, Medicare threshold crossing and rounding cases against actual mapped full-SHA engine; retain results", "Keep RELEASE HOLD; no code changes, production access, merge, publication or certification authorized"]

## 123 — Net-to-Gross Salary Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "Inverse salary is a product solver contract, not an IRS prescribed method. Depends on adopted and verified #121/#122 forward pack; bounded gross domain, target tolerance, least-gross/nearest tie/no-solution policy remain undecided."

Tasks: ["Only after #121/#122 forward approval: specify bounded integer-cent solver with all solutions/no-root detection; demonstrate handling FIT rounding jumps and reconcile every returned gross through exact approved forward pack", "After explicit contract adoption implement versioned forward withholding pack for 2026 profile, preserving decimal/rational intermediates; reject unsupported scope", "Run independent table-boundary, W4-credit floor, annualization, SS-cap crossing, Medicare threshold crossing and rounding cases against actual mapped full-SHA engine; retain results", "Keep RELEASE HOLD; no code changes, production access, merge, publication or certification authorized"]

## 124 — Payroll Tax Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "2026 cumulative employee/employer FICA source formulas are supplied, but full payroll-tax scope (FUTA/state/local/credits) is unselected and unsupported; cent-tie policy and covered-wage applicability remain undecided."

Tasks: ["After explicit contract adoption implement versioned forward withholding pack for 2026 profile, preserving decimal/rational intermediates; reject unsupported scope", "Run independent table-boundary, W4-credit floor, annualization, SS-cap crossing, Medicare threshold crossing and rounding cases against actual mapped full-SHA engine; retain results", "Keep RELEASE HOLD; no code changes, production access, merge, publication or certification authorized"]

## 128 — Capital Gains Tax Calculator (SOURCE_PARTIAL)

Remaining dependency: "Current disposal-class/claim applicability and exact CGT input/component rounding contract not fully sourced; historical Tax Logic does not close 2026/27 stages."

Tasks: ["For #128, close the preciseBlocker using the stated missing authoritative clauses before implementing a tax evaluator.", "After explicit profile/source/applicability decisions, specify #128 inputs, unsupported-scope validation and exact rounding stages; preserve all other catalog scope as unavailable.", "Only after authorization, bind #128 to reviewed implementation/full SHA and run independent boundary, exception and rounding cases; retain failures."]

## 129 — Dividend Tax Calculator (SOURCE_PARTIAL)

Remaining dependency: "Band ordering is supported, but complete current nil-rate allowance allocation and round-stage binding not established; do not subtract dividend allowance from band consumption."

Tasks: ["For #129, close the preciseBlocker using the stated missing authoritative clauses before implementing a tax evaluator.", "After explicit profile/source/applicability decisions, specify #129 inputs, unsupported-scope validation and exact rounding stages; preserve all other catalog scope as unavailable.", "Only after authorization, bind #129 to reviewed implementation/full SHA and run independent boundary, exception and rounding cases; retain failures."]

## 130 — Self-Employment Tax Calculator (SOURCE_PARTIAL)

Remaining dependency: "Need current Class4 stage/rounding and exemption/aggregation/other-contribution interaction pack. Class1 nearest-penny rule cannot be transplanted to Class4."

Tasks: ["For #130, close the preciseBlocker using the stated missing authoritative clauses before implementing a tax evaluator.", "After explicit profile/source/applicability decisions, specify #130 inputs, unsupported-scope validation and exact rounding stages; preserve all other catalog scope as unavailable.", "Only after authorization, bind #130 to reviewed implementation/full SHA and run independent boundary, exception and rounding cases; retain failures."]

## 131 — Freelancer Tax Reserve Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "No statutory freelancer reserve percentage exists in these sources. Owner/user must select whether supplied-liability planning or estimated liability; liability estimator remains source-partial."

Tasks: ["For #131, close the preciseBlocker using the stated missing authoritative clauses before implementing a tax evaluator.", "After explicit profile/source/applicability decisions, specify #131 inputs, unsupported-scope validation and exact rounding stages; preserve all other catalog scope as unavailable.", "Only after authorization, bind #131 to reviewed implementation/full SHA and run independent boundary, exception and rounding cases; retain failures."]

## 132 — Corporate Tax Estimate Calculator (SOURCE_PARTIAL)

Remaining dependency: "Missing adopted monetary rounding/return entry stages; current FY2026 explicit fraction/table binding and precise short-period day convention remain unverified. Control/augmented-profit factual applicability needs review."

Tasks: ["For #132, close the preciseBlocker using the stated missing authoritative clauses before implementing a tax evaluator.", "After explicit profile/source/applicability decisions, specify #132 inputs, unsupported-scope validation and exact rounding stages; preserve all other catalog scope as unavailable.", "Only after authorization, bind #132 to reviewed implementation/full SHA and run independent boundary, exception and rounding cases; retain failures."]

## 135 — Tax Marginal Rate Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "Output meaning unselected: statutory next-slice band versus effective incremental liability including allowance taper; rounded liability also creates discontinuities. Underlying current annual rounding pack is source-partial."

Tasks: ["For #135, close the preciseBlocker using the stated missing authoritative clauses before implementing a tax evaluator.", "After explicit profile/source/applicability decisions, specify #135 inputs, unsupported-scope validation and exact rounding stages; preserve all other catalog scope as unavailable.", "Only after authorization, bind #135 to reviewed implementation/full SHA and run independent boundary, exception and rounding cases; retain failures."]

## 136 — Salary Sacrifice Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: "Arrangement legality/eligibility, NMW cash floor, contractual timing, pension limits and payroll consequences require qualified applicability determination; PAYE forward rules and pension-charge pack missing."

Tasks: ["For #136, close the preciseBlocker using the stated missing authoritative clauses before implementing a tax evaluator.", "After explicit profile/source/applicability decisions, specify #136 inputs, unsupported-scope validation and exact rounding stages; preserve all other catalog scope as unavailable.", "Only after authorization, bind #136 to reviewed implementation/full SHA and run independent boundary, exception and rounding cases; retain failures."]

## 137 — Bonus Tax Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "Source eligibility, 22%, 37%, aggregate and same-period prior-bonus rules captured. Owner must select flat-eligible versus aggregate output and rounding, collect common-control supplemental YTD and regular FIT history; final annual bonus liability is outside supplied contract, unresolved rather than assumed."

Tasks: ["After explicit contract adoption implement versioned forward withholding pack for 2026 profile, preserving decimal/rational intermediates; reject unsupported scope", "Run independent table-boundary, W4-credit floor, annualization, SS-cap crossing, Medicare threshold crossing and rounding cases against actual mapped full-SHA engine; retain results", "Keep RELEASE HOLD; no code changes, production access, merge, publication or certification authorized"]

## 173 — Customer Lifetime Value Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "Full/residual CLV, cashflow timing, contractual versus noncontractual setting and supplied/calibrated retention must be selected. Full primary paper now read, resolving the previous first-page-only gap."

Tasks: ["Prepare version-bound profile schema with required timingMode,period,currency and explicit probability/discount units.", "After approved selection, verify geometric convergence, zero-retention, near-boundary denominator, full-versus-residual difference exactlym and acquisition cost counted once if separately approved.", "Bind existing candidate source files at PR1492 before implementing; earlier bounded static absence is not current proof."]

## 198 — Marketplace Fee Calculator (POLICY_DECISION_REQUIRED)

Remaining dependency: "No selected marketplace/provider universe, bank country, account/currency/tier and effective schedule. Etsy policy is authority for Etsy only."

Tasks: ["Do not implement current fees as universal constants. Define provider/date/profile key and fail-closed unsupported profiles.", "After policy adoption/source completion, test listing/order/account-period charges separately, credits once and refund funding; add official expected provider cases."]

## 199 — Etsy Profit Calculator (SOURCE_PARTIAL)

Remaining dependency: "Country-specific rates and refund-credit branch now substantive; historical effective intervals, provider rounding and complete selected account/attribution/tax applicability remain unsupported. General nonrefundable-service-fee wording and specific refund clauses must be reconciled, not blindly generalized."

Tasks: ["Model transaction and processing bases separately; sales tax affects processing base even when outside US transaction base.", "Retain persistent12% offsite qualification state; do not recalculate lifetime qualification from only current365-day revenue.", "Do not combine account/deposit/FX charges with order fee without explicit allocation policy. Source official bill examples and then run actual mapped engine tests."]

## 204 — Return Rate Impact Calculator (SOURCE_PARTIAL)

Remaining dependency: "Relevant AASB return-recognition clauses now revision/period-bound, but the previously cited future compilation cannot be treated as current. Post-July2026 amendment effects and selected operational versus accounting contract remain open."

Tasks: ["Keep cash refund, refund liability, revenue reduction and recovery asset separate outputs under governed accounting model; avoid double-counted retained fees and inventory recovery.", "Implement selected operational formula only as explicit bounded mode after owner contract selection; preserve full canonical accounting requirements.", "Bind selected standard compilation/amendments and underlying implementation SHA; test genuine returns versus same-item exchanges/warranty branches."]

## 404 — Target Heart Rate Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: ["Select age-based versus measured maximum/HRR method; approve population/screening and medication/heart-condition handling.", "Select 50–70% moderate and70–85% vigorous endpoint overlap policy, bpm display rounding, input bounds; no five-zone mapping established.", "Age-based target-heart-rate estimates and training intensity need population applicability, screening, measured-HR/HRR alternatives and limitations. Current source/arithmetic does not settle those safety judgments; retain qualified clinical/exercise review."]

Tasks: ["Prepare version-bound input/output/schema and boundary fixtures only after explicit profile selection.", "Capture accepted primary source revision and byte evidence where available; preserve inaccessible/unknown fields.", "Bind catalog ID and dependency/full SHA, then independently test actual implementation when authorized; existing arithmetic does not approve mapping."]

## 405 — Pregnancy Due Date Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: ["Obstetric reviewer must choose governing revision and hierarchy, reliable LMP/regular-cycle eligibility, ultrasound/redating thresholds and ART embryo-age/date rules.", "Retrieve full accepted redating table and latest reaffirmation; record discrepancy strictness, gestational-bin boundaries, dating uncertainty and calendar conventions.", "Pregnancy due-date interpretation needs qualified obstetric applicability/redating review. Complete dating guidance is unavailable and LMP+280 alone cannot establish ultrasound, irregular-cycle or assisted-reproduction policy."]

Tasks: ["Prepare version-bound input/output/schema and boundary fixtures only after explicit profile selection.", "Capture accepted primary source revision and byte evidence where available; preserve inaccessible/unknown fields.", "Bind catalog ID and dependency/full SHA, then independently test actual implementation when authorized; existing arithmetic does not approve mapping."]

## 406 — Pregnancy Weight Gain Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: ["Approve US singleton applicability, plurality-specific alternatives, adolescent/special populations and obesity inclusion.", "Choose continuous BMI boundaries without preclassification rounding; weekly trajectory requires gestational anchor, first-trimester range and interpolation policy; table rates do not establish individual growth curve.", "Pregnancy weight guidance needs qualified obstetric/nutrition applicability review of BMI cutpoints, plurality, gestational trajectory and special populations. Consumer chart versus underlying guideline scope remains unresolved."]

Tasks: ["Prepare version-bound input/output/schema and boundary fixtures only after explicit profile selection.", "Capture accepted primary source revision and byte evidence where available; preserve inaccessible/unknown fields.", "Bind catalog ID and dependency/full SHA, then independently test actual implementation when authorized; existing arithmetic does not approve mapping."]

## 407 — Ovulation Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: ["Approve regular-cycle eligibility, measured cycle variability, fixed14-day assumption versus12–14-day interval and uncertainty display.", "Choose elapsed-day versus cycle-day indexing, fertile-window endpoints and limitations; do not imply contraceptive effectiveness or individual confirmation.", "Ovulation/fertile-window interpretation needs qualified reproductive-health review. A fixed14-day assumption and calendar witness do not establish individual timing, irregular-cycle applicability or validated uncertainty."]

Tasks: ["Prepare version-bound input/output/schema and boundary fixtures only after explicit profile selection.", "Capture accepted primary source revision and byte evidence where available; preserve inaccessible/unknown fields.", "Bind catalog ID and dependency/full SHA, then independently test actual implementation when authorized; existing arithmetic does not approve mapping."]

## 408 — Conception Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: ["Approve dating input basis inherited from405 and independently supported uncertainty; exact conception/fertilization/intercourse/paternity cannot be inferred.", "Define estimate interval only with evidence; ART requires recorded transfer/embryo information; no manufactured confidence range.", "Conception dating needs qualified reproductive-health review and independently established uncertainty. Inverse calendar arithmetic cannot establish fertilization/intercourse date or paternity, and the approved dating basis is absent."]

Tasks: ["Prepare version-bound input/output/schema and boundary fixtures only after explicit profile selection.", "Capture accepted primary source revision and byte evidence where available; preserve inaccessible/unknown fields.", "Bind catalog ID and dependency/full SHA, then independently test actual implementation when authorized; existing arithmetic does not approve mapping."]

## 409 — GFR Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: ["Clinician selects creatinine-only versus combined equation, coefficient-profile applicability, adult population and exclusions/nonsteady-state handling.", "Approve assay/units provenance, normalized versus absolute-GFR distinction, input plausibility, rounding and interpretation/critical-result policy; no arbitrary output clamp.", "The candidate adult2021CKD-EPI arithmetic is supported, but renal applicability, coefficient profile, input assays/units, exclusions and result interpretation remain clinical judgments. Retain qualified clinician review; no arbitrary output clamp."]

Tasks: ["Prepare version-bound input/output/schema and boundary fixtures only after explicit profile selection.", "Capture accepted primary source revision and byte evidence where available; preserve inaccessible/unknown fields.", "Bind catalog ID and dependency/full SHA, then independently test actual implementation when authorized; existing arithmetic does not approve mapping."]

## 410 — Sleep Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: ["Approve age/population guidance and distinction between sleep obtained and sleep opportunity; no universal90minute cycle or15minute latency.", "Choose actual date/timezone/DST ambiguity behavior, overnight inversion, user-entered latency and output precision; other ages require separate guidance.", "Sleep guidance and inverse scheduling need population/age applicability and the distinction between actual sleep and opportunity. A duration subtraction does not establish a universal latency/cycle or clinical recommendation; retain qualified sleep/health review under current evidence."]

Tasks: ["Prepare version-bound input/output/schema and boundary fixtures only after explicit profile selection.", "Capture accepted primary source revision and byte evidence where available; preserve inaccessible/unknown fields.", "Bind catalog ID and dependency/full SHA, then independently test actual implementation when authorized; existing arithmetic does not approve mapping."]

## 442 — Currency Converter (POLICY_DECISION_REQUIRED)

Remaining dependency: ["Owner must select informational ECB profile and date fallback/staleness; currency minor-unit source and rounding stage/mode absent; no data API observation response frozen"]

Tasks: ["After profile choice fetch EXR series for both currencies with identical startPeriod/endPeriod, capture response/observation date/status and exact source bytes hash", "Implement provider-independent decimal cross arithmetic and explicit missing-date/suspended-currency errors; bind to approved mapping and test actual engine"]

## 485 — Carbon Footprint Calculator (SOURCE_RESOLVED)

Remaining dependency: ["Broad Carbon Footprint identity remains unselected; full household/company/lifecycle scope, inventory boundary, extra activities and display precision need owner choice", "Original binary workbook hash and exact native cell-coordinate verification not obtained; parsed capture hashes genuine", "Qualified applicability/obligation/license attribution review not granted; OGLv3 observed except third-party exclusions"]

Tasks: ["Freeze original two XLSX bytes and selected factor row/native cells against captured parsedv1.0/v1.2; ensure blanks stay missing", "After scope approval implement strict activity-unit/year/region/boundary matching and no GWP double conversion; compare actual engine with decimal vectors"]

## 502 — Cooking Time Adjustment Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: ["Food-safety reviewer selects food/cut, geometry, weight interval, appliance, starting state and validated calibration; no arbitrary temperature/mass scaling.", "Approve thermometer endpoints/rest handling and approximate chart scope; obtain thermal model/validation for full requested adjustment or leave unsupported.", "No validated food/geometry/appliance time-adjustment thermal model exists in the packet. Qualified food-safety applicability review and calibration are mandatory for the intended safe-cooking interpretation; endpoint temperatures are not a time predictor."]

Tasks: ["Prepare version-bound input/output/schema and boundary fixtures only after explicit profile selection.", "Capture accepted primary source revision and byte evidence where available; preserve inaccessible/unknown fields.", "Bind catalog ID and dependency/full SHA, then independently test actual implementation when authorized; existing arithmetic does not approve mapping."]

## 522 — Race Time Predictor (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: ["Individual calibration/population, prediction uncertainty and performance validity absent; universal1.06 not established", "Figures reconstructed by parser are not reliable numeric dataset; no calibrated confidence intervals"]

Tasks: ["Verify Table1 visually against original reprint bytes before coefficient fixture adoption", "Obtain independent sports performance applicability review and calibration validation; only then bind model/range/exponent and actual-engine vectors"]

## 526 — Training Heart Rate Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: ["Qualified exercise reviewer resolves identity with404 and selects age-estimated/measured maximum or HRR, resting-HR protocol and exercise screening.", "Adopt exact governing thresholds/version before any zones; ACSM indexed infographic not full verified source and cannot silently replace AHA bands.", "Training-heart-rate zone selection depends on#404, resting/max-HR methodology, population screening and reviewed thresholds. Current evidence does not establish safe training prescription; retain qualified clinical/exercise applicability review."]

Tasks: ["Prepare version-bound input/output/schema and boundary fixtures only after explicit profile selection.", "Capture accepted primary source revision and byte evidence where available; preserve inaccessible/unknown fields.", "Bind catalog ID and dependency/full SHA, then independently test actual implementation when authorized; existing arithmetic does not approve mapping."]

## 527 — Golf Handicap Calculator (SOURCE_PARTIAL)

Remaining dependency: ["USGA2024 complete PDF403 persists; no PDF body reviewed", "5.1 formula and9hole/expected-score details absent from retrieved R&A body; fewer20 and exceptional-score tables images not read", "National2026 authorized association adoption/amendments, eligibility Rules2-4, committee Rule7, PCC/expected data rights and rounding tie rules missing"]

Tasks: ["Retrieve full authorized national2026 rules including5.1 image/formula and all tables; visually verify and capture revision", "After source closure implement stateful score ordering,9holes,365day Low Index, exceptional reductions, caps and committee adjustments; test actual engine at thresholds"]

## 530 — VO2 Max Estimate Calculator (QUALIFIED_APPLICABILITY_REQUIRED)

Remaining dependency: ["Approve original repeated-mile protocol, healthy30–69 population, fourth-quarter HR timing/measurement and screening/exclusions.", "Keep absolute regression conversion distinct from independently fitted relative regression; select uncertainty/output rounding and obtain external validation for any protocol/population extension.", "The Kline absolute regression/conversion arithmetic is supported, but protocol, healthy30–69 applicability, screening, fourth-quarter HR and uncertainty require qualified exercise/clinical review. Do not substitute a generic postwalk HR or separately fitted relative regression."]

Tasks: ["Prepare version-bound input/output/schema and boundary fixtures only after explicit profile selection.", "Capture accepted primary source revision and byte evidence where available; preserve inaccessible/unknown fields.", "Bind catalog ID and dependency/full SHA, then independently test actual implementation when authorized; existing arithmetic does not approve mapping."]

Do not invent a runtime technical version from a research specification revision. Bind current actual engine/dependency/fullSHA and canonical ID before acceptance. Historical engines and source evidence are immutable; new approved methods require controlled revisions. Preserve540identities,424ledger,14originalDRAFTs and SIP/Slope histories. No production SQL, merges, deployments, live payments, certification or publication. RELEASE HOLD.
