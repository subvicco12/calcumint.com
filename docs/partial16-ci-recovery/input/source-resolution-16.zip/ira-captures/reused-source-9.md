# 2026 Amounts Relating to Retirement Plans and IRAs, as Adjusted for Changes in Cost-of-Living

## Notice 2025-67

Section 415 of the Internal Revenue Code (“Code”) provides for limitations on benefits and contributions under qualified retirement plans. Section 415(d) requires that the Secretary of the Treasury annually adjust these limitations for cost-of-living increases. Under section 415(d), the adjustments are to be made under adjustment procedures similar to those used to adjust benefit amounts under section 215(i)(2)(A) of the Social Security Act. Other amounts applicable to deferred compensation plans are also adjusted for cost-of-living increases using a variation of the methodology used for the adjustments under section 415(d).

# Cost-of-Living Adjusted Limitations for 2026

Effective January 1, 2026, the limitation on the annual benefit under a defined benefit plan under section 415(b)(1)(A) of the Code is increased from $280,000 to $290,000.

For a participant who separated from service before January 1, 2026, the participant’s limitation under a defined benefit plan under section 415(b)(1)(B) is computed by multiplying the participant’s compensation limitation, as adjusted through 2025, by 1.0288.

The limitation for defined contribution plans under section 415(c)(1)(A) is increased in 2026 from $70,000 to $72,000.

The Code provides that various other amounts are to be adjusted at the same time and in the same manner as the limitation of section 415(b)(1)(A). After taking into account the applicable rounding rules, the amounts for 2026 are as follows:

The limitation under section 402(g)(1) on the exclusion for elective deferrals described in section 402(g)(3), which includes elective deferrals made to the Thrift Savings Plan, is increased from $23,500 to $24,500.

The limitation on deferrals under section 457(e)(15) concerning deferred compensation plans of state and local governments and tax-exempt organizations is increased from $23,500 to $24,500.

The limitation under section 414(v)(2)(B)(i) for catch-up contributions to an applicable employer plan other than a plan described in section 401(k)(11) or section 408(p) that generally applies for individuals aged 50 or over is increased from $7,500 to $8,000. The limitation under section 414(v)(2)(E)(i) for catch-up contributions to an applicable employer plan other than a plan described in section 401(k)(11) or section 408(p) that applies for individuals who attain

age 60, 61, 62, or 63 in 2026 remains $11,250. The Roth catch-up wage threshold for 2025, which under section 414(v)(7)(A) is used to determine whether an individual’s catch-up contributions to an applicable employer plan (other than a plan described in section 408(k) or (p)) for 2026 must be designated as Roth contributions, is increased from $145,000 to $150,000.

The limitation under section 408(p)(2)(E)(i)(III) that generally applies to salary reduction contributions under a SIMPLE retirement account or elective contributions under a SIMPLE 401(k) plan is increased from $16,500 to $17,000. The limitation for certain of those accounts or plans under section 408(p)(2)(E)(i)(I) or (II) is increased from $17,600 to $18,100.

The limitation under section 414(v)(2)(B)(ii) for catch-up contributions to an applicable employer plan described in section 401(k)(11) or section 408(p) that generally applies for individuals aged 50 or over is increased from $3,500 to $4,000. The limitation under section 414(v)(2)(E)(ii) for catch-up contributions to an applicable employer plan described in section 401(k)(11) or section 408(p) that applies for individuals who attain age 60, 61, 62, or 63 in 2026 remains $5,250. The limitation under section 414(v)(2)(B)(iii) for catch-up contributions to certain accounts or plans described in section 401(k)(11) or section 408(p) that generally applies for individuals aged 50 or over remains $3,850.

The limitation under section 401(k)(16)(D)(i)(II) and 403(b)(16)(D)(i)(II) that generally applies for elective contributions made to a starter 401(k) deferral-only arrangement described in section 401(k)(16)(B) or a safe harbor deferral-only plan described in section 403(b)(16)(B), respectively, remains $6,000. This limitation is increased for individuals who attain age 50 before the end of the taxable year by $1,100.

The threshold used in the definition of “highly compensated employee” under section 414(q)(1)(B) remains $160,000.

The threshold under section 416(i)(1)(A)(i) concerning the definition of “key employee” for top-heavy plan purposes is increased from $230,000 to $235,000.

The annual compensation limitation under sections 401(a)(17), 404(l), 408(k)(3)(C), and 408(k)(6)(D)(ii) is increased from $350,000 to $360,000. The annual compensation limitation under section 401(a)(17) for eligible participants in certain governmental plans that, under the plan as in effect on July 1, 1993, allowed cost-of-living adjustments to the compensation limitation under the plan under section 401(a)(17) to be taken into account, is increased from $520,000 to $535,000.

The limitation under section 402A(e)(3)(A)(i) concerning pension-linked emergency savings accounts that may be included in certain types of defined contribution plans is increased from $2,500 to $2,600.

The compensation threshold under section 408(k)(2)(C) regarding simplified employee pensions is increased from $750 to $800.

The amount under section 409(o)(1)(C)(ii) for determining the maximum account balance in an employee stock ownership plan subject to a 5-year distribution period is increased from $1,415,000 to $1,455,000, while the dollar amount used to determine the lengthening of the 5-year distribution period is increased from $280,000 to $290,000.

The limitation on the aggregate amount of length of service awards accruing with respect to any year of service for any bona fide volunteer under section 457(e)(11)(B)(ii) concerning deferred compensation plans of state and local governments and tax-exempt organizations is increased from $7,500 to $8,000.

The limitation under section 664(g)(7) concerning the qualified gratuitous transfer of qualified employer securities to an employee stock ownership plan is increased from $60,000 to $65,000.

The compensation amount under § 1.61-21(f)(5)(i) of the Income Tax Regulations concerning the definition of “control employee” for fringe benefit valuation purposes is increased from $140,000 to $145,000. The compensation amount under § 1.61-21(f)(5)(iii) is increased from $285,000 to $290,000.

The limitation on premiums paid for a qualifying longevity annuity contract under § 1.401(a)(9)-6(q)(2)(ii) remains $210,000.

The $1,000,000,000 threshold used to determine whether a multiemployer plan is a systemically important plan under section 432(e)(9)(H)(v)(III)(aa) is adjusted using the cost-of-living adjustment provided under section 432(e)(9)(H)(v)(III)(bb). After taking the applicable rounding rule into account, the threshold used to determine whether a multiemployer plan is a systemically important plan under section 432(e)(9)(H)(v)(III)(aa) is increased from $1,441,000,000 to $1,505,000,000.

The Code also provides that several retirement-related amounts are to be adjusted using a variation of the methodology used for the cost-of-living adjustments under section 1(f)(3). After taking the applicable rounding rules into account, the amounts for 2026 are as follows:

The adjusted gross income limitation under section 25B(b)(1)(A) for determining the retirement savings contributions credit for married taxpayers filing a joint return is increased from $47,500 to $48,500; the limitation under section 25B(b)(1)(B) is increased from $51,000 to $52,500; and the limitation under sections 25B(b)(1)(C) and 25B(b)(1)(D) is increased from $79,000 to $80,500.

The adjusted gross income limitation under section 25B(b)(1)(A) for determining the retirement savings contributions credit for taxpayers filing as head of

household is increased from $35,625 to $36,375; the limitation under section 25B(b)(1)(B) is increased from $38,250 to $39,375; and the limitation under sections 25B(b)(1)(C) and 25B(b)(1)(D) is increased from $59,250 to $60,375.

The adjusted gross income limitation under section 25B(b)(1)(A) for determining the retirement savings contributions credit for all other taxpayers is increased from $23,750 to $24,250; the limitation under section 25B(b)(1)(B) is increased from $25,500 to $26,250; and the limitation under sections 25B(b)(1)(C) and 25B(b)(1)(D) is increased from $39,500 to $40,250.

The deductible amount under section 219(b)(5)(A), which limits the amount of an individual’s deductible qualified retirement contributions for a taxable year is increased from $7,000 to $7,500. The deductible amount pursuant to section 219(b)(5)(B)(ii) for individuals who have attained age 50 before the close of the taxable year is increased from $1,000 to $1,100.

The applicable amount under section 219(g)(3)(B)(i) for determining the deductible amount of an IRA contribution for taxpayers who are active participants filing a joint return or as a qualifying widow(er) is increased from $126,000 to $129,000. The applicable amount under section 219(g)(3)(B)(ii) for all other taxpayers who are active participants (other than married taxpayers filing separate returns) is increased from $79,000 to $81,000. If an individual or the individual’s spouse is an active participant, the applicable amount under section 219(g)(3)(B)(iii) for a married individual filing a separate return is not subject to an annual cost-of-living adjustment and remains $0. The applicable amount under section 219(g)(7)(A) for a taxpayer who is not an active participant but whose spouse is an active participant is increased from $236,000 to $242,000.

In light of the changes to the applicable amounts, under section 219(g)(2)(A), the deduction for taxpayers making contributions to a traditional IRA is phased out for single individuals and heads of household who are active participants in a qualified plan (or another retirement plan specified in section 219(g)(5)) and have adjusted gross incomes (as defined in section 219(g)(3)(A)) between $81,000 and $91,000, increased from between $79,000 and $89,000. For married couples filing jointly, if the spouse who makes the IRA contribution is an active participant, the income phase-out range is between $129,000 and $149,000, increased from between $126,000 and $146,000. For an IRA contributor who is not an active participant and is married to someone who is an active participant, the deduction is phased out if the couple’s income is between $242,000 and $252,000, increased from between $236,000 and $246,000. For a married individual filing a separate return who is an active participant, the phase-out range is not subject to an annual cost-of-living adjustment and remains $0 to $10,000.

The adjusted gross income limitation under section 408A(c)(3)(B)(ii)(I) for determining the maximum Roth IRA contribution for married taxpayers filing a

joint return or for taxpayers filing as a qualifying widow(er) is increased from $236,000 to $242,000. The adjusted gross income limitation under section 408A(c)(3)(B)(ii)(II) for all other taxpayers (other than married taxpayers filing separate returns) is increased from $150,000 to $153,000. The applicable amount under section 408A(c)(3)(B)(ii)(III) for a married individual filing a separate return is not subject to an annual cost-of-living adjustment and remains $0.

In light of the changes to the adjusted gross income limitations, under section 408A(c)(3)(A), the adjusted gross income phase-out range for taxpayers making contributions to a Roth IRA is between $242,000 and $252,000 for married couples filing jointly, increased from between $236,000 and $246,000. For singles and heads of household, the income phase-out range is between $153,000 and $168,000, increased from between $150,000 and $165,000. For a married individual filing a separate return, the phase-out range is not subject to an annual cost-of-living adjustment and remains between $0 and $10,000.

The aggregate amount of qualified charitable distributions that are not includible in gross income under section 408(d)(8)(A) is increased from $108,000 to $111,000. The amount of qualified charitable distributions made directly to a split-interest entity that are not includible in gross income under section 408(d)(8)(F)(i)(II) pursuant to a one-time election is increased from $54,000 to $55,000.

The annual compensation limitation under section 45E(f)(2)(C) for employees excluded from the calculation of the additional small employer pension plan startup cost credit for certain employer contributions is increased from $105,000 to $110,000.¹

The limitation under section 72(t)(2)(K)(ii)(I) for eligible distributions to victims of domestic abuse from applicable eligible retirement plans is increased from $10,300 to $10,500.

The limitation under section 401(a)(39)(B)(i)(III) on a qualified long-term care distribution from a qualified defined contribution plan with respect to certified long-term care insurance remains $2,600.

1 Pursuant to section 45E(f)(2)(C)(iii), for a taxable year beginning in a calendar year after 2023, this limitation is equal to the initial limitation of $100,000, multiplied by the cost-of-living adjustment determined under section 1(f)(3) for the calendar year in which the taxable year begins, determined by substituting “calendar year 2007” for “calendar year 2016” in section 1(f)(3)(A)(ii). Because the specification of a 2007 base period to be used for computing an adjustment that is first made for 2024 appears to be an error that has been identified as the subject of future legislative correction, the IRS will calculate and apply the limitation in section 45E(f)(2)(C) by substituting “calendar year 2022” for “calendar year 2007” in section 45E(f)(2)(C)(iii).

The limitation under section 408(p)(2)(A)(iv) for additional nonelective contributions for an employee to a SIMPLE retirement account or a SIMPLE 401(k) plan is increased from $5,100 to $5,300.

# Drafting Information

The principal author of this notice is Tom Morgan of the Office of Associate Chief Counsel (Employee Benefits, Exempt Organizations, and Employment Taxes). However, other personnel from the IRS participated in the development of this guidance. For further information regarding this notice, contact Mr. Morgan at (202) 317-6700 (not a toll-free call).
