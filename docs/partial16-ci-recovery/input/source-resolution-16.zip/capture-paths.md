# Capture path convention

Lane records retain exact original research-workspace capture paths. SOURCE-CAPTURE-HASHES.json records their real hashes and sizes. Not every full-text capture is distributed in this handoff; follow its exact publisher URL for independent full-document access. Supplied summaries are not mislabeled as original source bodies. IRS/UK government extracts and original user-provided package are included; full copyrighted rulebook/policy extracts remain unrepublished.
