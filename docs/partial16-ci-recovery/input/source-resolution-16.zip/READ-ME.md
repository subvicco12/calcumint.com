# CalcuMint — 16 partial-source authority cases

Research overlay dated30 October2026. Candidate PR1493: `9edc90078d6b356c5c2e5702daa4da68974a062d`, verified open/draft/unmerged. Exact-head CI run **41076164193** remained **in_progress**, conclusion null, in both bounded observations. No watch loop or successful-CI claim.

**Result:11 explicitly bounded methods/components now have sufficient source evidence for the stated numeric bound;5 remain SOURCE_PARTIAL. No complete canonical calculator is accepted. RELEASE HOLD.**

| ID | Bounded evidence disposition | Supported bound or exact blocker |
|---:|---|---|
|9|SOURCE_RESOLVED_BOUNDED|Regular single-advance equal-monthly-payment actuarial APR; amount financed already legally classified; precise iteration and two-decimal result with ambiguous ties rejected. Irregular dates/general fee classification remain outside bound|
|19|SOURCE_PARTIAL|Chase sample clause arithmetic established, but final issuer minimum-payment quantization remains unknown. Exact-cent intermediates do not establish issuer rounding|
|20|SOURCE_RESOLVED_BOUNDED|Named sample transfer-fee component only, whole-dollar transfer input and externally established eligibility/timing. Not a complete balance-transfer payoff calculator|
|23|SOURCE_RESOLVED_BOUNDED|Named Interest Only Option during Draw Period: sum lender-supplied accrued interest and unpaid fees. Not a full HELOC accrual/projection calculator|
|95|SOURCE_RESOLVED_BOUNDED|2026 original-owner age75 traditional IRA TableIII exact quotient; payment quantization/instructions and other branches remain unapproved|
|97|SOURCE_RESOLVED_BOUNDED|Unphased2025 single under50 Roth contribution and explicitly qualified distribution profile. Phased/conversion/inherited/excess branches remain open; source inconsistencies retained|
|98|SOURCE_RESOLVED_BOUNDED|Selected2025 single under50 covered traditional IRA deduction worksheet, excluding relevant Social Security cases; explicit next-$10/$200-floor rules|
|112|SOURCE_RESOLVED_BOUNDED|Covered nonexempt single hourly-rate workweek, exact rational wage estimator; employment applicability and actual payroll disbursement rounding remain separate|
|120|SOURCE_PARTIAL|2026/27 annual Income Tax calculation-stage/rounding and allowance treatment authority still missing|
|128|SOURCE_PARTIAL|Current CGT disposal/claim applicability and calculation/input/component rounding remain incomplete|
|129|SOURCE_PARTIAL|Nil-rate allowance consumes band space; complete2026/27 allocation/stage/rounding binding still incomplete|
|130|SOURCE_PARTIAL|Current Class4 stage/rounding, exemptions, aggregation and concurrent contribution interactions incomplete. Class1 rounding cannot substitute|
|132|SOURCE_RESOLVED_BOUNDED|FY2026 fixed12-month ordinary company computational estimate, no associates, N=A, exact arithmetic. CT600/final collection amount and short periods not supplied|
|199|SOURCE_RESOLVED_BOUNDED|Current-observation unrounded Etsy US/USD scenario or exact reconciliation of supplied assessed fees/credits. Not historical or billed-exact fee prediction|
|204|SOURCE_RESOLVED_BOUNDED|Ordinary non-insurance returns operational component and constrained accounting illustration. AASB2022-9 changes insurance scope; applicable returns clauses remain. No full accounting-compliance acceptance|
|527|SOURCE_RESOLVED_BOUNDED|2024-rule18hole differential numeric component including negative ties; missing tables now retrieved. Rights/authorization and current national profile still block immediate implementation|

## What these counts mean

Source sufficiency is assessed for each **explicitly stated bound**, not the full catalog identity. In particular20 and23 are component-only;95 is an exact numeric minimum rather than a rounded payment instruction;199 is an estimate/reconciliation rather than a provider-bill predictor. These distinctions are machine-readable. No narrow component substitutes for the full Final Product scope. The original43-case register and implementation manifest are unchanged.

Ten IDs can enter conditional private engineering once CI and all specified source/profile/mapping/applicability decisions are satisfied: **9,20,23,95,97,98,112,132,199,204**. There are **zero** cases ready from CI success alone: no pending owner scope is automatically adopted. #527 additionally requires authorization/permitted-use and national-profile resolution. The five remaining partial cases require source work before an authoritative implementation can be admitted.

## New evidence and reused evidence

- Reused complete IRS captures rather than refetching them.2026 RMD denominators and2025 IRA worksheet/qualification rules support tightly selected methods. The2026 Roth MFJ upper limit typo was already corroborated by Notice2025-67 and IR-2025-111; that corroboration is reused, not counted as new retrieval. A further prose-versus-illustrated2025 Roth worksheet discrepancy is retained outside the unphased bound, not silently repaired.
- Added missing CFPB amount-financed/finance-charge clauses and the textual actuarial recurrence basis. Raster equations were not claimed verified. Sample issuer/offer/HELOC terms do not prove applicability to a real account.
- Retrieved explicit FY2026 corporation-rate/fraction table, short-period days guidance and CT computation no-rounding guidance. Four other UK profiles remain partial; unsuccessful2027 specification-URL lookups are not proof that the authority is unavailable everywhere.
- Retrieved the specific Etsy refund-help clauses and AASB2022-9 amendment. General/specific Etsy refund interpretation is labeled an inference; billed-exact reconciliation uses supplied assessed credits rather than invented entitlements. Provider fee rounding and historical effective intervals remain missing outside the bound.
- Retrieved a complete normalized2024 rulebook from a national association and corroborating official18hole explanation. Rule5 tables/negative rounding are now readable. Rule1.2 contains an authorization restriction; no permission or national2026 adoption is inferred.

Every source record preserves exact URL, clause, revision/effective-period scope, retrieval date and capture/hash meaning. Most hashes identify normalized markdown or structured tool responses, **not publisher original binaries**. The handoff provides source summaries/indexes and links; full copyrighted rulebook text is not redistributed. Government-source captures and preserved user-supplied prior package are retained for provenance.

## Independent examples and review

Source examples and synthetic controls are separate in each case. A further17 exact-rational arithmetic checks were reproduced centrally across all16 IDs. They are **not application-engine tests**; examples in partial UK cases remain diagnostic candidate arithmetic, not official expected liabilities. Actual-engine acceptance count is0.

Targeted independent review found and corrected:

1. Traditional IRA98 omitted the Social Security-benefit branch. The bound now requires no relevant2025 Social Security benefits; true or unknown rejects ordinary Table1-2/Worksheet1-2 and requires AppendixB review. A rejection fixture and reproducible guard are recorded.
2. Chase19 exact-cent input restrictions did not prove final issuer quantization. The case was conservatively retained SOURCE_PARTIAL, with unquantized70.01 counterexample and billed result UNKNOWN.
3. AASB204 accounting illustration now explicitly assumes supported variable consideration/reversal constraints and period-end remeasurement of refund/recovery amounts. It is not generic arbitrary-q statutory accounting.

No demonstrated application implementation defect is asserted; these findings concern proposed research contracts. No source code, actual calculator formula or historical version was changed.

## #485 preservation and separate cohorts

Read-only retrieval of PR1493 component-manifest.json and native-source-binding.json matched their exact Gitblob hashes. The private UK2026 purchased-grid Scope2/location-based component remains bounded at0.13096kgCO2e/kWh, exact decimal output, no registry/publication, no broad footprint completion. Native workbook SHA/cell bindings are reused from the exact candidate evidence; native extraction and runtime tests were not rerun. Full inventory activities, canonical mapping, reporting/applicability and permitted-use gates remain open.

The original **13 POLICY_DECISION_REQUIRED** and **13 QUALIFIED_APPLICABILITY_REQUIRED** cohorts are copied unchanged into separate files. The11 original qualified requirements remain preserved within the latter; no new specialist approval or signature is asserted.

## Conditional Codex handoff

conditional-codex-tasks-16.json contains per-ID contracts, examples and gates. In dependency order:

1. Confirm exact-head CI success; saved evidence is in_progress, not green.
2. Adopt only explicit bounded contracts and immutable ID/component/version/fullSHA/dependency bindings. Preserve full canonical requirements as open work; do not silently narrow product scope.
3. For the10 conditional candidates, use the exact source-backed bound and reject unsupported scope. For19/120/128/129/130, obtain remaining governing quantization/stage/applicability documents first. For527, resolve rights and selected national profile first.
4. Execute actual mapped engines against source and independent synthetic goldens, boundary/rounding/domain tests and negative applicability fixtures. Record expected/actual, source revision, source/implementation hashes and independent reviewer conclusions.
5. Retain release hold and all remaining external/lifecycle gates. No CI or component test grants certification/publication.

## Files

- source-resolution-register-16.json / .csv: exact16 research dispositions and full original records.
- conditional-codex-tasks-16.json: conditional implementation/actual-engine validation tasks.
- remaining-publisher-documents.json: per-ID missing rules/documents and policy choices, including broader branches.
- unchanged-policy-cohort-13.json / unchanged-qualified-cohort-13.json: separate untouched cohorts.
- candidate-evidence/: frozen candidate identity, CI observations, #485 exact manifests and Gitblob hashes.
- independent-example-recheck.json:17 centrally reproduced arithmetic checks.
- provenance-and-integrity.json / SOURCE-CAPTURE-HASHES.json / MANIFEST-SHA256.json: exact provenance and artifact hashes.
- input-authority43/: unchanged original package and register.

**Full-product readiness remains PARTIAL / production NO-GO.** No production access, SQL, source-repository mutation, merge, deployment, payment, certification or publication occurred. All540 identities,424records, immutable histories and14original privateDRAFTs were preserved by no writes; this is not a fresh production-state audit.
