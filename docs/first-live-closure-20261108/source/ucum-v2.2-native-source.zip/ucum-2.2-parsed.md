[Download or clone repository on GitHub](https://github.com/ucum-org/ucum)

The Unified Code for Units of Measure

# The Unified Code for Units of Measure

|     |
| --- |
| Gunther Schadow<br>Pragmatic Data LLC |
| Clement J. McDonald<br>National Library of Medicine, Lister Hill |

Version: 2.2

Revision: N/A

Date: 2024-06-17


Copyright © 1998-2024, Regenstrief Institute, Inc. and the UCUM Organization. All rights
reserved.



* * *

## Table of contents

1 [Introduction](https://ucum.org/ucum#section-introduction)

2 [Grammar of Units and Unit Terms](https://ucum.org/ucum#section-Grammar-of-Units-and-Unit-Terms)

    2.1
 [Character Set and Lexical Rules](https://ucum.org/ucum#section-Character-Set-and-Lexical-Rules)

    2.2
 [Syntax Rules](https://ucum.org/ucum#section-Syntax-Rules)

    2.3 [The Predicate “Metric”](https://ucum.org/ucum#section-The-Predicate-%E2%80%9CMetric%E2%80%9D)

    2.4
 [Style](https://ucum.org/ucum#section-Style)

3 [Semantics](https://ucum.org/ucum#section-Semantics)

    3.1 [Special Units on non-ratio\\
 Scales](https://ucum.org/ucum#section-Special-Units-on-non-ratio-Scales)

    3.2 [Arbitrary Units](https://ucum.org/ucum#section-Arbitrary-Units)

4 [Tables of Terminal Symbols](https://ucum.org/ucum#section-Tables-of-Terminal-Symbols)

    4.1 [Prefixes](https://ucum.org/ucum#section-Prefixes)

    4.2 [Base\\
 Units](https://ucum.org/ucum#section-Base-Units)

    4.3 [Derived Unit\\
 Atoms](https://ucum.org/ucum#section-Derived-Unit-Atoms)

    4.4 [Customary Unit\\
 Atoms](https://ucum.org/ucum#section-Customary-Unit-Atoms)

    4.5 [Other Legacy\\
 Units](https://ucum.org/ucum#section-Other-Legacy-Units)

    4.6 [Prefixes and Units Used in Information\\
 Technology](https://ucum.org/ucum#section-Prefixes-and-Units-Used-in-Information-Technology)

### Appendices

A [Examples for some Non-Units.](https://ucum.org/ucum#section-Examples-for-some-Non-Units.)

B [Summary of Conflicts](https://ucum.org/ucum#section-Summary-of-Conflicts)

C [Alphabetic\\
 Index](https://ucum.org/ucum#section-Alphabetic-Index)

    C.1 [Alphabetic Index By\\
 Name](https://ucum.org/ucum#section-Alphabetic-Index-By-Name)

    C.2 [Alphabetic Index By\\
 Symbol](https://ucum.org/ucum#section-Alphabetic-Index-By-Symbol)

    C.3 [Alphabetic Index\\
 By Kind Of Quantity](https://ucum.org/ucum#section-Alphabetic-Index-By-Kind-Of-Quantity)

D [Example Unit Terms](https://ucum.org/ucum#datyp2apdxatblxmp)

E [Copyright\\
 and License Terms of Use](https://ucum.org/ucum#license)

* * *

_The Unified Code for Units of Measure_ is a code system intended to include _all_ units of
measures being contemporarily used in international science,
engineering, and business. The purpose is to facilitate unambiguous
electronic communication of quantities together with their units. The
focus is on electronic communication, as opposed to communication
between humans. A typical application of _The Unified Code for Units of Measure_ are electronic data
interchange (EDI) protocols, but there is nothing that prevents it
from being used in other types of machine communication.



_The Unified Code for Units of Measure_ is inspired by and heavily based on ISO 2955-1983, ANSI
X3.50-1986, and HL7's extensions called “ISO+”. The
respective ISO and ANSI standards are both entitled
“Representation of \[...\] units in systems with limited
character sets” where ISO 2955 refers to SI and other units
provided by ISO 1000-1981, while ANSI X3.50 extends ISO 2955 to
include U.S. customary units. Because these standards carry the
restriction of “limited character sets” in their names
they seem to be of less value today, when graphical user interfaces and
laser printers are in wide-spread use. For this reason, the European
standard ENV 12435 in its clause 7.3 declares ISO 2955 obsolete.



ENV 12435 is dedicated exclusively to the communication of
measurements between humans in display and print, and does not provide
codes that can be used in communication between systems. It does not
even provide a specification that would allow communication of units
from one system to the screen or printer of another system. The issue
about displaying units in the common style defined by the 9th
_Conférence Générale des Poids et Mesures_
(CGPM) in 1947 is not just the character set. Although the
_Unicode_ standard and its predecessor ISO/IEC 10646 is
the richest character set ever, it is still not enough to specify the
presentation of units, because there are important typographical
details such as superscripts, subscripts, roman and
italics. [1](https://ucum.org/ucum#fn1)

The real value of the restriction on the character set and
typographical details, however, is not to cope with legacy systems and
less powerful technology, but to facilitate unambiguous communication
and interpretation of the meaning of units from one computer system to
another. In this respect, ISO 2955 and ANSI X3.50 are not
obsolete because there is no other standard that would fill in for
inter-systems communication of units. However, ISO 2599 and ANSI
X3.50 currently have severe defects:



1. ISO 2955 and ANSI X3.50 contain numerous name conflicts,
    both direct conflicts (e.g., “`a`” being used
    for both “year” and “are”) and conflicts
    that are generated through combination of unit symbols with prefixes
    (e.g., “`cd`” means candela and centi-day and
    “`PEV`” means peta-volt and pico-electronvolt.)



4. Neither ISO 2955 nor ANSI X3.50 cover all units that are
    currently used in practice. There are many more units in use than what
    is allowed by the _Système International_
   _d'Unités_ (SI) and accompanying standards. For example,
    the older CGM-units dyne and erg are still used in the science of
    physiology. Although ANSI X3.50 extends ISO 2955 with some
    U.S. customary units, it is still not complete in this respect. For
    example it does not define the degree Fahrenheit.



7. ANSI X3.50 is semantically ambiguous with respect to customary
    units, even if we do not consider the history and international
    aspects of customary units. Three systems of mass units are used in
    the U.S., avoirdupois used generally, apothecaries' used by
    pharmacists, and troy used in trade with Gold and other precious
    metals. ANSI X3.50 has no way to select any one of those
    specifically, which is bad in medicine, where both apothecaries' and
    avoirdupois weights are being used frequently.



ISO 2955 and all standards that do only look for the resolutions
and recommendations of the CGPM and the _Comité_
_International des Poids et Mesures_ (CIPM) as published by the
_Bureau International des Poids et Mesures_ (BIPM) and various
ISO standards (ISO 1000 and ISO 31) fail to recognize that
the needs in practice are often different from the ideal propositions
of the CGPM. Although not allowed by the CGPM and related ISO
standards, many other units are used in international sciences,
healthcare, engineering, and business, both meaningfully and some
units of questionable meaning. A coding system that is to be useful in
practice must cover the requirements and habits of the
practice—even some of the bad habits.



None of the current standards attempt to specify a semantics of units
that can be deployed in information systems with moderate
requirements. Metrological standards such as those published by the
BIPM are dedicated to maximal scientific correctness of reproducible
definitions of units. These definitions make sense only to human
specialists and can hardly be deployed to their full extent by any
information system that is not dedicated to metrology. On the other
hand, ISO 2955 and ANSI X3.50 provide no semantics at all for the
codes they define.



_The Unified Code for Units of Measure_ provides a single coding system for units that is complete,
free of all ambiguities, and that assigns to each defined unit a
concise semantics. In communication it is not only important that all
communicating parties have the same repertoire of symbols, but also that
all attach the same meaning to the symbols they exchange. The common
meaning must be computationally verifiable. _The Unified Code for Units of Measure_ assumes a
semantics for units based on dimensional analysis. [2](https://ucum.org/ucum#fn2)

In short, each unit is defined relative to a system of base units by a
numeric factor and a vector of exponents by which the base units
contribute to the unit to be defined. Although we can reflect all the
meaning of units covered by dimensional analysis with this vector
notation, the following tables do not show these vectors. One reason
is that the vectors depend on the base system chosen and even on the
ordering of the base units. The other reason is that these vectors are
hard to understand to human readers while they can be easily derived
computationally. Therefore we define new unit symbols using algebraic
terms of other units. Those algebraic terms are also valid codes of
_The Unified Code for Units of Measure_.



**§1 preliminaries** **■1** _The Unified Code for Units of Measure_ consists of a basic set
of terminal symbols for units, called
_atomic unit symbols_ or _unit atoms_, and multiplier
prefixes. It also consists of an expression syntax by which these
symbols can be combined to yield valid units.
**■2**
The tables of terminal symbols are fixed as of every revision of
_The Unified Code for Units of Measure_, additions, deletions or changes are _not_ allowed.
**■3**
All expression that can be derived from these terminal symbols and the
expression syntax are valid codes. Any expression of _The Unified Code for Units of Measure_ has a
precisely defined semantics.



The expression syntax of _The Unified Code for Units of Measure_ generates an infinite number of codes
with the consequence that it is impossible to compile a table of all
valid units.



That the tables of terminal symbols may not be extended does not mean
that missing symbols will never be available in _The Unified Code for Units of Measure_. Suggestions
for additions of new symbols are welcome and revisions of
_The Unified Code for Units of Measure_ will be released as soon as a change request has been approved.



**§2 full and limited conformance** **■1**
The semantics of _The Unified Code for Units of Measure_ implies equivalence classes such that
different expressions may have the same meaning.
**■2**
Programs that declare _full conformance_ with _The Unified Code for Units of Measure_ must
compare unit expressions by their semantics, i.e. they must detect
equivalence for different expressions with the same meaning.
**■3**
Programs with _limited conformance_ may compare unit expressions
literally and thus may not detect equivalence of unit expressions.



The option for “limited conformance” allows _The Unified Code for Units of Measure_ to be adopted
even by less powerful systems that can not or do not want to deal with
the full semantics of units. Those systems typically have a table of
fixed unit expression literals that may be related to other literals
with fixed conversion factors. Although these systems will have
difficulties to receive unit expressions from various sources, they
will at least send out valid expressions of _The Unified Code for Units of Measure_, which is an
important step towards a commonly used coding scheme for units.



**§3 character set** **■1** All expressions of _The Unified Code for Units of Measure_ shall
be built from characters of
the 7-bit US-ASCII character set exclusively.
**■2** Terminal unit symbols can consist of all ASCII characters in
the range of 33–126 (0x21–0x7E) excluding

double quotes (‘`"`’),
parentheses (‘`(`’ and ‘`)`’),
plus sign (‘`+`’'),
minus sign (‘`-`’'),
period (‘`.`’'),
solidus (‘`/`’'),
equal sign (‘`=`’'),
square brackets (‘`[`’\
and ‘`]`’), and
curly braces (‘`{`’ and ‘`}`’),

which have special meaning.
**■3** A terminal unit symbol can not consist of only digits
(‘`0`’–‘`9`’) because
those digit strings are interpreted as positive integer
numbers. However, a symbol “`10*`” is allowed
because it ends with a non-digit allowed to be part of a symbol.
**■4** For every terminal symbol there is a case insensitive variant
defined, to be used when there is a risk of upper and lower case to be
confused. Although upper and lower case can be mixed in case
insensitive symbols there is no meaning to the case. Case insensitive
symbols are incompatible to the case sensitive symbols.



The 7-bit US-ASCII character code is the greatest common denominator
that can be expected to be available in any communication environment.
Only very few units normally require symbols from the Greek alphabet
and thus the cost of requiring Unicode does not outweigh the benefit.
As explained above, the real issue about writing unit terms naturally
is not the character set but the ability to write subscripts and
superscripts and distinguish roman letters from italics.



Some computer systems or programming languages still have the
requirement of case insensitivity and some humans who are not familiar
with SI units tend to confuse upper and lower case or can not
interpret the difference in upper and lower case correctly. For this
reason the case insensitive symbols are defined. Although _The Unified Code for Units of Measure_
does not encourage use of case insensitive symbols where not
absolutely necessary, in some circumstances the case insensitive
representation may be the greatest common denominator. Thus some
systems that can handle case sensitivity may end up using case
insensitive symbols in order to communicate with less powerful
systems.



ISO 2955 and ANSI X3.50 call case sensitive symbols “mixed
case” and case insensitive symbols “single case” and
list two columns for “single case” symbols, one for upper
case and one for lower case. In _The Unified Code for Units of Measure_ all units can be written in
mixed upper and lower case, but in the case insensitive variant the
mixing of case does not matter.



White space is not recognized in a a unit term and should generally
not occur. UCUM implementations may flag whitespace as an error
rather than ignore it. Whitespace is not used as a separator of
otherwise ambiguous parts of a unit term.



**§4 prefixes** **■1** Metric units (cf. [§11](https://ucum.org/ucum#para-11)) may be
combinations of a unit symbol with a prefix symbol.
**■2** The unit symbol to be combined with the prefix must not itself
contain a prefix. Such a prefix-less unit symbol is called _unit_
_atom_.
**■3** Prefix and atom are connected immediately without any
delimiter. Separation of an optional prefix from the atom occurs on
the lexical level by finding a matching combination of an optional
prefix and a unit atom.
**■4** The prefix is the longest leading substring that matches a
valid prefix where the remainder is a valid metric unit atom. If no
such prefix can be matched, the unit atom is without prefix and may be
both metric or non-metric.\[1–3: ISO 1000, 3; ISO 2955-1983, 3.7;\
ANSI X3.50-1986, 3.7 (Rule No. 6).\]

**§5 square brackets** **■1** Square brackets (‘`[`’ and\
‘`]`’) may be part of a
unit atom at any place but only as matched pairs. Square brackets are
lexical elements and not separate syntactical tokens.  **■2** Within a matching
pair of square brackets the full range of
characters 33–126 can be used. [3](https://ucum.org/ucum#fn3) **■3** Square brackets do
_not_ determine the boundary between
prefix and unit atom, but they never span the boundary of unit atoms.
**■4**
Square brackets must not be nested.



For example
%
“`[abc+ef]`”,
“`ab[c+ef]`”,
“`[abc+]ef`”, and
“`ab[c+ef]`”
%
could all be valid symbols if defined in the tables.
In “`ab[c+ef]`” either
“`a`” or “`ab`”
could be defined as a prefix, but not “`ab[c`”.\
\
\
\
Square brackets take on one task of round parentheses in HL7's\
“ISO+” code, where one use of parentheses is to augment\
unit symbols with suffixes, as in “`mm(Hg)`”.\
Another use is to enclose one full unit symbol into parentheses, as\
“`(ka_u)`” (for the King-Armstrong unit of\
catalytic amount of phosphatase). Apparently, in a unit symbol such\
enclosed one is supposed not to expect a prefix. Thus, even if\
“`a_u`” would have been defined,\
“`(ka_u)`” should not be matched against\
kilo-`a_u`.\
\
\
\
Parentheses, however, were also used for the nesting of terms since\
HL7 version 2.3. At this point it became ambiguous whether parentheses\
are part of the unit symbol or whether they are syntactic tokens. For\
instance, “`(ka_u)`” could mean a nested\
“`ka_u`” (where “`k`”\
could possibly be a prefix), but also the proper symbol\
“`(ka_u)`” that happens to have parentheses as\
part of the symbol. _The Unified Code for Units of Measure_ uses parentheses for the usual meaning of\
term nesting and uses square brackets where HL7's “ISO+”\
assumes parentheses to be part of the unit symbol.\
\
\
\
**§6 curly braces** **■1** The full range of characters 33–126 can be used within a\
pair of curly braces (‘`{`’ and\
‘`}`’). The material enclosed in curly braces is\
called _annotation_.\
**■2**\
Annotations do not contribute to the semantics of the unit but are\
meaningless by definition. Therefore, any fully conformant parser must\
discard all annotations. Parsers of limited conformance _should_\
not value annotations in comparison of units.\
**■3**\
Annotations do, however, signify the end of a unit symbol.\
**■4** An annotation without a leading symbol implies the default\
unit 1 (the unity).\
**■5**\
Curly braces must not be nested.\
\
\
\
Curly braces are here because people want annotations and deeply\
believe that they need annotations. Especially in chemistry and\
biomedical sciences, there are traditional habits to write annotations\
at units or instead of units, such as “%vol.”,\
“RBC”, “CFU”, “kg(wet tis.)”, or\
“mL(total)”. These habits are hard to overcome. Any\
attempt of a coding scheme to restrict this perceived expressiveness\
will ultimately result in the coding scheme not being adopted, or just\
“half-way” adopted (which is as bad as not adopted).\
\
\
\
Two alternative responses to this reality exist: either give in to the\
bad habits and blow up of the code with dimension- and meaningless\
unit atoms, or canalize this habit so that it does no harm. _The Unified Code for Units of Measure_\
canalizes this habit using curly braces. Nevertheless we do continuing\
efforts to upgrade doubtful units to genuine units of _The Unified Code for Units of Measure_ by\
defining and linking them to the other units as good as\
possible. Thus, “`g%`” is a valid metric unit\
atom (so that “`mg%`” is a valid unit too.)\
A _drops_, although quite imprecise, is a valid unit of volume\
“`[drp]`”. Even HPF and LPF (the so called\
“high-” and “low power field” in the\
microscope) have been defined so that at least they relate to each\
other.\
\
\
\
**§7 algebraic unit terms** **■1** All units can be combined in an algebraic term using the\
operators for multiplication (period ‘`.`‘) and\
division (solidus ‘`/`’).  **■2** The multiplication operator is\
mandatory it must not be\
omitted or replaced by a space. The multiplication operator is a\
strict binary operator that may occur only _between two_ unit\
terms.  **■3** The division operator can be used as a binary and unary\
operator, i.e. a leading solidus will invert the unit that directly\
follows it.  **■4** Terms are evaluated from left to right with the period and\
the\
solidus having the same operator precedence. Multiple division\
operators are allowed within one term. \[ISO 1000, 4.5.2; ISO 2955-1983, 3.3f;\
ANSI X3.50-1986, 3.3f\
(Rule No. 2f).\]\
\
The use of the period instead of the asterisk\
(‘`*`’) as a multiplication operator continues a\
tradition codified in ISO 1000 and maintained in ISO 2955. Because\
floating point numbers may not occur in unit terms the period is not\
ambiguous. A period in a unit term has no other meaning than to be the\
multiplication operator.\
\
\
\
Since Resolution 7 of the 9th CGPM in 1948 the myth of ambiguity being\
introduced by more than one solidus lives on and is quoted in all\
standards concerning the writing of SI units. However, when the strict\
left to right rule is followed there is no ambiguity, neither with one\
solidus nor with more than one solidus. However, in human practice we\
find the tendency to assign a lower precedence to the solidus which\
misleads people to write _a_/ _b_· _c_ when they\
really mean _a_/( _b_· _c_). When this is\
rewritten as _a_/ _b_/ _c_ there is actually less\
ambiguity that in _a_/ _b_· _c_. So the real\
source of ambiguity is when a multiplication operator follows a\
solidus, not when there is more than one solidus in a term. Hence, we\
remove the restriction for only one solidus and introduce parentheses\
which may be used to remove any perceived ambiguity.\
\
\
\
**§8 integer numbers** **■1** A positive integer number may appear in place of a simple unit\
symbol.  **■2** Only a pure string of decimal digits\
(‘`0`’–‘`9`’)\
is interpreted as a number. If after one or more digits there is any\
non-digit character found that is valid for unit atoms, all the\
characters (including the digits) will be interpreted as a simple unit\
symbol.\
\
\
\
For example, the string “`123`” is a positive\
integer number while “`12a`” is a symbol.\
\
\
\
Note that the period is only used as a multiplication operator, thus\
“`2.5`” means 2 × 5 and is not equal to 5/2.\
\
\
\
**§9 exponents** **■1** Simple units may be raised to a power. The exponent is an\
integer number and is written immediately behind the unit\
term. Negative exponents must be preceded by a minus sign\
(‘`-`’ positive exponents may be preceded by an\
optional plus sign (‘`+`’).  **■2** If the simple unit raised to a\
power is a combination of a\
prefix and a unit atom, both are raised to the power, e.g. “1\
`cm3`” equals “10-6`m3`” not “10-2`m3`”.\
\[ISO 2955-1983, 3.5f; ANSI X3.50-1986, 3.5f (Rule\
No. 4f).\]\
\
ISO 2955 and ANSI X3.50 actually do not allow a plus sign leading a\
positive exponent. However, if there can be any perceived ambiguities,\
an explicit leading plus sign may be of help sometimes. _The_\
_Unified Code for Units of Measures_ therefore allows such plus signs\
at exponents. The plus sign on positive exponents can be used to\
delimit exponents from integer numbers used as simple units. Thus,\
`2+10` means 210 = 1024.\
\
\
\
**§10 nested terms** **■1** Unit terms with operators may be enclosed in parentheses\
(‘`(`’ and ‘`)`’) and used\
in place of simple units. Normal left-to-right evaluation can be\
overridden with parentheses.  **■2** Parenthesized terms are _not_\
considered unit atoms\
and hence must not be preceded by a prefix.\
\
\
Up until revision 1.9 there was a third clause\
“Since a unit term in parenthesis can be used in place of\
a simple unit, an exponent may follow on a closing parenthesis which\
raises the whole term within the parentheses to the power.”\
However this feature was inconsistent with any BNF or other syntax\
description ever provided, was never used and seems to have no\
relevant use case. For this reason this clause has been stricken.\
This is a _tentative_ change. Users who have used this\
feature in the past, should please comment on this deprecation.\
If we receive indication that this feature was used by anyone, we\
would undo the deprecation. If no comments are received, the\
deprecation continues to take effect.\
\
\
\
|     |     |     |\
| --- | --- | --- |\
| |     |     |     |\
| --- | --- | --- |\
| < _sign_ > | ::= | “`+`” \| “`-`” |\
| < _digit_ > | ::= | “`0`” \| “`1`” \| “`2`” \|<br> “`3`” \| “`4`” \| “`5`” \|<br> “`6`” \| “`7`” \| “`8`” \|<br> “`9`” |\
| < _digits_ > | ::= | < _digit_ >< _digits_ ><br> \| < _digit_ > |\
| < _factor_ > | ::= | < _digits_ > |\
| < _exponent_ > | ::= | < _sign_ >< _digits_ ><br> \| < _digits_ > |\
| < _simple-unit_ > | ::= | < _ATOM-SYMBOL_ ><br> \| < _PREFIX-SYMBOL_ >< _ATOM-SYMBOL\[metric\]_ > |\
| < _annotatable_ > | ::= | < _simple-unit_ >< _exponent_ ><br> \| < _simple-unit_ > |\
| < _component_ > | ::= | < _annotatable_ >< _annotation_ ><br> \| < _annotatable_ ><br> \| < _annotation_ ><br> \| < _factor_ ><br> \| “`(`”< _term_ >“`)`” |\
| < _term_ > | ::= | < _term_ >“`.`”< _component_ ><br> \| < _term_ >“`/`”< _component_ ><br> \| < _component_ > |\
| < _main-term_ > | ::= | “`/`”< _term_ ><br> \| < _term_ > |\
| < _annotation_ > | ::= | “`{`”< _ANNOTATION-STRING_ >“`}`” | |\
\
Exhibit 1:\
 The complete syntax in the Backus-Naur Form.\
\
\
\
![Pushdown-state automaton describing the syntax.](https://raw.githubusercontent.com/ucum-org/ucum/main/assets/images/ucum-state-automaton.gif)\
\
Figure\
1: Pushdown-state automaton describing the syntax.\
\
\
**§11 metric and non-metric**\
**unit atoms** **■1** Only metric unit atoms may be combined with a prefix.\
**■2** To be metric or not to be metric is a predicate assigned to\
each unit atom where that unit atom is defined.\
**■3** All base units are metric. No non-metric unit can be part of\
the basis.\
**■4** A unit must be a quantity on a ratio scale in order to be\
metric.\
\
\
\
The metric predicate accounts for the fact that there are units that\
are prefixed and others that are not. This helps to disambiguate the\
parsing of simple units into prefix and atom.\
\
\
\
To determine whether a given unit atom is metric or not is not\
trivial. It is a cultural phenomenon, subject to change, just like\
language, the meaning of words and how words can be used. At one time\
we can clearly tell right or wrong usage of words, but these\
decisions may need to be revised with the passage of time.\
\
\
\
Generally, metric units are those defined “in the spirit”\
of the metric system, that emerged in France of the 18th century and\
was rapidly adopted by scientists. Metric units are usually based on\
reproducible natural phenomena and are usually not part of a system of\
comparable units with different magintudes, especially not if the\
ratios of these units are not powers of 10. Instead, metric units use\
multiplier prefixes that magnify or diminish the value of the unit\
by powers of ten.\
\
\
\
Conversely, customary units are in the spirit of the middle age as\
most of them can be traced back into a time around the 10th century,\
some are even older from the Roman and Babylonian empires. Most\
customary units are based on the average size of human anatomical or\
botanic structures (e.g., foot, ell, fathom, grain, rod) and come in\
series of comparable units with ratios 1/2, 1/4, 1/12, 1/16, and\
others. Thus all customary units are non-metric\
\
\
\
Not all units from ISO 1000 are metric as degree, minute and second of\
plane angle are non-metric as well as minute, hour, day, month, and\
year. The second is a metric unit because it is a part of the SI\
basis, although it used to be part of a series of customary units\
(originating in the Babylonian era).\
\
\
\
Furthermore, for a unit to be metric it must be a quantity on a ratio\
scale where multiplication and division with scalars are defined. The\
_Comité Consultatif d'Unités_ (CCU) decided\
in February 1995 that SI prefixes may be used with the degree\
Celsius. This statement has not been made explicitly before. This is\
an unfortunate decision because difference-scale units like the degree\
Celsius have no multiplication operation, so that the prefix value\
could be multiplied with the unit. Instead the prefix at non-ratio\
units scales the measurement value. One dekameter is 10 times of a\
meter, but there is no meaning to 10 times of 1 °C in the\
same way as 30 °C are not 3 times as much as\
10 °C. See [§§21ff](https://ucum.org/ucum#para-21) on how _The Unified Code for Units of_\
_Measure_ finds a\
way to accommodate this different use of prefixes at units such as the\
degree Celsius, bel or neper.\
\
\
\
Except for the rule on curly braces ( [§12](https://ucum.org/ucum#para-12)), the\
rules on style govern the creation of the tables of unit atoms not\
their individual use. Users of _The Unified Code for Units of Measure_ need not care about style rules\
( [§§13–15](https://ucum.org/ucum#para-13)) because users\
just use the symbols defined in the tables. Hence, style rules do not\
affect conformance to _The Unified Code for Units of Measure_. New submissions of unit atoms, however,\
must conform to the style rules.\
\
\
\
**§12 curly braces** **■1**\
Curly braces may be used to enclose annotations that are often written\
in place of units or behind units but that do not have a proper\
meaning of a unit and do not change the meaning of a unit.\
**■2**\
Annotations have no semantic value.\
\
\
\
For example one can write “`%{vol}`”,\
“`kg{total}`”, or “`{RBC}`”\
(for “red blood cells”) as pseudo-units. However, these\
annotations do not have any effect on the semantics, which is why\
these example expressions are equivalent to\
“`%`”, “`kg`”, and\
“`1`” respectively.\
\
\
\
**§13 underscore** **■1** When in print a unit would have a subscript, an underscore\
(‘`_`’) is used to separate the subscript from\
the stem of the unit symbol.  **■2**\
The subscript is part of the unit atom.\
**■3** subscripts are used to disambiguate the two units with the\
same name but different meanings.\
\
\
For example when distinguishing the International Table calorie from\
the thermochemical calorie, we would use 1 calIT or\
1 calth in print. _The Unified Code for Units of Measure_ defines the symbols\
“`cal_IT`” and\
“`cal_th`” with the underscore signifying that\
“IT” and “th” are subscripts. Other examples\
are the distinctions between the Julian and Gregorian calendar year\
from the tropical year or the British imperial gallon from the U.S.\
gallon (see [§31](https://ucum.org/ucum#para-31) and [§§37ff](https://ucum.org/ucum#para-37)).\
\
\
\
**§14 square brackets** **■1** Square brackets enclose suffixes of unit symbols that change\
the meaning of a unit stem.\
**■2** All customary units shall be enclosed completely by square\
brackets.\
**■3**\
Other unit atoms shall be enclosed in square brackets if they are very\
rare, if they will conflict with other units, or if they are normally\
not used as a unit symbol but do have a proper meaning as a unit in\
_The Unified Code for Units of Measure_.\
**■4**\
Square brackets are part of the unit atom.\
\
\
\
For example 1 m H2O is written as\
“`m[H2O]`” in _The Unified Code for Units of Measure_ because the suffix\
H2O changes the meaning of the unit atom for meter (length)\
to a unit of pressure.\
\
\
\
Customary units are defined in _The Unified Code for Units of Measure_ in order to accommodate\
practical needs. However metric units are still preferred and the\
customary symbols should not interfere with metric symbols in any\
way. Thus, customary units are “stigmatized” by enclosing\
them into square brackets.\
\
\
\
If unit symbols for the purpose of display and print are derived from\
_The Unified Code for Units of Measure_ units, the square brackets can be removed. However, display\
units are out of scope of _The Unified Code for Units of Measure_.\
\
\
\
**§15 apostrophe** **■1**\
The apostrophe (‘`'`’) is used to separate words\
or abbreviated words in a multi-word unit symbol.\
**■2**\
Since units are mathematically defined symbols and not abbreviations\
of words, multi-word unit symbols should be defined only to reflect\
existing habits, not in order to create new ones.\
**■3**\
Multi-word units should always be enclosed in square brackets.\
\
\
\
For example, such legacy units called “Bodansky unit” or\
“Todd unit” have the unit symbols\
“`[bdsk'U]`”, and\
“`[todd'U]`” respectively.\
\
\
\
**§16 preliminaries** **■1** The semantics of _The Unified Code for Units of Measure_ is\
defined by the algebraic\
operations of multiplication, division and exponentiation between\
units, by the equivalence relations of equality and commensurability\
of units, and by the multiplication of a unit with a scalar.\
**■2** Every expression in _The Unified Code for Units of Measure_ is\
mapped to one and only one\
semantic element. But every semantic element may have more than one\
valid representant in _The Unified Code for Units of Measure_.\
**■3**\
The set of expressions in _The Unified Code for Units of Measure_ is infinite.\
\
\
\
**§17 equality and commensurability** **■1** The set of expressions in _The Unified Code for Units of_\
_Measure_ has two binary, symmetric,\
reflexive, and transitive relations (equivalence relations)\
“equals” = and “is commensurable with”\
~. All expressions that are equal are also commensurable but not\
all commensurable expressions are equal.\
\
\
**§18 algebra of units** **■1** The equivalence classes generated by the equality relation =\
are called _units_.\
**■2** The set of units _U_ has a binary multiplication operator\
· that is associative and commutative and has the neutral\
element **1** (so called _the unity_). For each unit\
**u** ∈ _U_ there is an inverse unit\
**u**-1 such that **u** ·\
**u**-1 = **1**. Thus, ( _U_, ·) is\
an Abelian group.\
**■3** The division operation **u** / **v** is\
defined as\
**u** · **v**-1.  **■4** The\
exponentiation operation with integer exponents _n_\
is defined as **u** _n_ =\
**Π** 1n **u**.\
**■5**\
The product **u**' = _r_ **u** of a real number scalar\
with the unit **u** is also a\
unit, where **u**' ~ **u**.\
\
\
\
**§19 dimension and**\
**magnitude** **■1** The equivalence classes generated by the commensurability\
relation ~ are called _dimensions_. The set _D_\
of dimensions is infinite in principle, but only a finite subset of\
dimensions are used in practice. Thus, implementations of _The Unified Code for Units of Measure_ need\
not be able to represent the infinite set of dimensions.\
**■2**\
Two commensurable units that are not equal differ only by their\
magnitude.\
**■3** The quotient **u** / **v** of any two\
commensurable\
units **u** ~ **v** is of the same dimension as the\
unity ( **u** / **v** ~ **1**). This quotient is\
also equal to the unity multiplied with a scalar _r_: **u** / **v** =\
_r_ **1**,\
where _r_ is called the _relative magnitude_ of\
**u** regarding **v**.\
\
\
**§20 base units** **■1**\
Any system of units is constructed from a finite set **B** of\
mutually independent base units **B** = {\
**b** 1, **b** 2, ...,\
**b** _n_ }, on which any other unit **u**\
∈ _U_ is defined as **u** =\
_r_ 1 **b** 1_u_ 1 ·\
_r_ 2 **b** 2_u_ 2 ·\
... ·\
_r_ _n_ **b** _n__u_ _n_,\
where _r_ = _r_ 1 · _r_ 2\
·· · _r_ _n_ is called the\
_magnitude_ of the unit **u** regarding **B**.\
**■2**\
With respect to a basis **B** every unit can thus be\
represented as a pair ( _r_, _û_) of magnitude _r_ and dimension _û_ =\
( _u_ 1, _u_ 2, ...,\
_u_ _n_).\
**■3**\
Two sets of base units are equivalent if there is an isomorphism\
between the sets of units that they generate.\
\
\
\
[§19](https://ucum.org/ucum#para-19).1 allows to limit the set of\
supported dimensions. Most practically used units contain exponents of\
 -4 to +4. Thus if memory is\
limited, 4 bit per component of the dimension vector could be\
sufficient.\
\
\
\
**§21 special units** **■1**\
Those symbols that are used as units that imply a measurement on a\
scale other than a ratio scale (e.g., interval scale, logarithmic\
scale) are defined differently. These do not represent proper units as\
elements of the group ( _U_,·). Therefore those special\
semantic entities are called _special units_, as opposed to\
_proper units_. The set of special units is denoted\
_S_, where _S_ ∩ _U_ = {}.\
**■2**\
A special unit **s** ∈ _S_ is defined as\
the triple ( **u**, _f_ **s**,\
_f_ **s**-1) where **u**\
∈ _U_ is the “corresponding” proper unit of\
**s** and where _f_ **s** and\
_f_ **s**-1 are mutually inverse\
real functions converting the measurement value to and from the\
special unit.\
**■3**\
Although not elements of _U_, special units are said to be\
“of the same dimension” or “commensurable\
with” their corresponding proper unit **u** and the class\
of units commensurable with **u**. This can be expressed by means\
of a binary, symmetric, transitive and reflexive relation ≈\
on _U_ ∪ _S_.\
\
\
\
The functions _f_ **s** and\
_f_ **s**-1 are applied as follows: let\
_r_ **s** be the numeric measurement value\
expressed in the special unit **s** and let _m_ be the\
corresponding dimensioned quantity, i.e., the measurement with proper\
unit **u**. Now, _r_ **s** =\
_f_ **s**( _m_/ **u**) converts the proper\
measurement to the special unit and _m_ =\
_f_ **s**-1( _r_ **s**)\
× **u** does the inverse.\
\
\
\
**§22 operations on special units** **■1**\
In theory, special units cannot take part in any algebraic operations,\
neither involving other units, nor themselves (exponentiation) nor\
involving scalars.\
**■2**\
Special units are therefore non-metric units.\
**■3**\
However, due to the requirement of the SI that does allow prefixes on\
the degree Celsius, special units may be _scaled_ trough a prefix\
or an arbitrary numeric factor.\
**■4** The scale factor _α_ is an\
additional component of the special unit, which in turn is defined by\
a quadruple **s** = ( **u**, _f_ **s**,\
_f_ **s**-1, _α_). When the\
functions _f_ **s** and\
_f_ **s**-1 are applied to a measurement value\
_x_ to convert to and from the special unit the scale factor is\
applied as follows: _x_' = _f_ **s**( _x_) /\
_α_ converts from _x_ expressed in the corresponding\
proper unit to _x_' in terms of the special unit and _x_ =\
_f_ **s**-1( _α_ _x_') does\
the reverse.\
**■5**\
Multiplication of a special unit **s** = ( **u**,\
_f_ **s**,\
_f_ **s**-1, _α_) with a\
scalar _β_ is defined as\
_β_ **s** = ( **u**, _f_ **s**,\
_f_ **s**-1, _β_ _α_). Multiplication of a special unit\
**s** with a\
dimensionless unit _r_ **1** is defined as _r_ **s**.\
\
\
\
Since prefixes have a scalar value that multiplies the unit atom, a\
unit must at least have a defined multiplication operation with a\
scalar in order to be a candidate for the metric predicate. All proper\
units are candidates for the metric property, special units are no\
such candidates.\
\
\
\
The _Comité Consultatif d'Unités_ (CCU)\
decided in February 1995 that any SI prefix may be used with degree\
Celsius. This statement has not been made explicitly before. This is\
an unfortunate decision because difference-scale units like the degree\
Celsius have no multiplication operation, so that the prefix value\
could be multiplied with the unit. Instead the prefix at non-ratio\
units scales the measurement value. One wonders why the CGPM keeps the\
Celsius temperature in the SI as it is superfluous and in a unique way\
incoherent with the SI.\
\
\
\
The scale factor _α_ is applied with the functions\
_f_ **s** and _f_ **s**-1\
as follows: let _r_ **s** be the numeric measurement\
value expressed in the special unit **s** and let _m_ be the\
corresponding dimensioned quantity, i.e., the measurement with proper\
unit **u**. Now, _r_ **s** =\
_f_ **s**( _m_/ **u**) / _α_\
converts the proper measurement to the special unit and _m_ =\
_f_ **s**-1( _α_ _r_ **s**) ×\
**u** does the reverse.\
\
\
\
**§23 definition of special units** **■1**\
Special units are marked in the definition tables for unit atoms by a\
bullet (‘•’) in the column titled “value”\
and a special expression in the column titled\
“definition”. The BNF for the special expression is < _special-unit_ \> ::=\
< _function-symbol_ >“`(`”< _floating-point-number_ >“``”< _term_ >“`)`”\
The function symbols are defined as\
needed.\
**■2**\
Special expressions are _not_ valid expressions in _The Unified Code for Units of Measure_,\
they are _only_ used for defining special units.\
\
\
\
**§24 arbitrary units** **■1**\
Arbitrary or procedure defined units are units whose meaning entirely\
depends on the measurement procedure (assay). These units have no\
general meaning in relation with any other unit in the SI. Therefore those arbitrary\
semantic entities are called _arbitrary units_, as opposed to\
_proper units_. The set of arbitrary units is denoted\
_A_, where _A_ ∩ _U_ = {}.\
**■2**\
An arbitrary unit has no further definition in the semantic framework of _The Unified Code for Units of_\
_Measure_ **■3**\
Arbitrary units are not “of any specific dimension” and are\
not “commensurable with” any other unit.\
\
\
\
Until version 1.6 _The Unified Code for Units of Measure_ has dealt with arbitrary units as dimensionless,\
but as an effect the semantics of _The Unified Code for Units of Measure_ made all arbitrary units\
commensurable. Since version 1.7 of _The Unified Code for Units of Measure_ it is no longer possible to\
convert or compare arbitrary units with any other arbitrary unit.\
\
\
\
**§25 operations on arbitrary units** **■1**\
Any term involving arbitrary units, is itself an arbitrary unit and is not\
comparable with any other arbitrary unit or term.\
\
\
\
**§26 definition of arbitrary units** **■1**\
Arbitrary units are marked in the definition tables for unit atoms by a\
bullet (‘•’) in the column titled “value”\
and a bullet in the column titled “definition”.\
\
\
\
**§27 prefixes** **■1**\
Prefix symbols are those defined in [Table\\
1](https://ucum.org/ucum#prefixes).\
**■2** There are five columns titled “name,”\
“print,” “c/s,” “c/i,” and\
“value” The name is the full (official) name of the\
unit. The official symbol used in print this is listed in the column\
“print” “C/s,” and “c/i” list the\
symbol in the case sensitive and the case insensitive variants\
respectively. “Value” is the scalar value by which the\
unit atom is multiplied if combined with the prefix.\
**■3**\
Only the columns titled “c/s,” “c/i,” and\
“value,” are normative. Full name and print symbol are\
defined by the CGPM and are out of scope of _The Unified Code for Units of Measure_.\
\
\
\
The case insensitive prefix symbols are slightly different from those\
defined by ISO 2955 and ANSI X3.50, where “giga-,”\
“tera-,” and “peta-” have been\
“`G`,” “`T`,” and\
“`PE`.” _The Unified Code for Units of Measure_ has a larger set of unit atoms\
and needs to prevent more name conflicts. Tera and giga have a second\
letter to be safe in the future. The change of\
“`PE`” to “`PT`” would\
be the way to go for ISO 2955 which currently has a name conflict\
(among others) with peta-volt and pico-electronvolt.\
\
\
\
The new prefixes “yotta-,” “zetta-,”\
“yocto-,” and “zepto-” that were adopted by\
the 19th CGPM (1990) have a second letter ‘A’ and\
‘O’ resp. to avoid current and future conflicts and to\
disambiguate among themselves. The other submultiples\
“micro-” to “atto-” are represented by a\
single letter to keep with the tradition.\
\
\
\
| name | print | c/s | c/i | value |\
| yotta | Y | `Y` | `YA` | 1 × 1024 |\
| zetta | Z | `Z` | `ZA` | 1 × 1021 |\
| exa | E | `E` | `EX` | 1 × 1018 |\
| peta | P | `P` | `PT` | 1 × 1015 |\
| tera | T | `T` | `TR` | 1 × 1012 |\
| giga | G | `G` | `GA` | 1 × 109 |\
| mega | M | `M` | `MA` | 1 × 106 |\
| kilo | k | `k` | `K` | 1 × 103 |\
| hecto | h | `h` | `H` | 1 × 102 |\
| deka | da | `da` | `DA` | 1 × 101 |\
| deci | d | `d` | `D` | 1 × 10-1 |\
| centi | c | `c` | `C` | 1 × 10-2 |\
| milli | m | `m` | `M` | 1 × 10-3 |\
| micro | μ | `u` | `U` | 1 × 10-6 |\
| nano | n | `n` | `N` | 1 × 10-9 |\
| pico | p | `p` | `P` | 1 × 10-12 |\
| femto | f | `f` | `F` | 1 × 10-15 |\
| atto | a | `a` | `A` | 1 × 10-18 |\
| zepto | z | `z` | `ZO` | 1 × 10-21 |\
| yocto | y | `y` | `YO` | 1 × 10-24 |\
\
 Table\
 1: The prefix symbols\
\
\
**§28 base units** **■1** The base units shown in [Table\\
2](https://ucum.org/ucum#baseunits) are used to\
define all the unit atoms of _The Unified Code for Units of Measure_ according to its grammar and\
semantics.\
**■2** There are five columns titled “name,” “kind\
of quantity,” “print,” “c/s,” and\
“c/i.” The name is the full (official) name of the\
unit. The official symbol used in print this is listed in the column\
“print” “C/s,” and “c/i” list the\
symbol in the case sensitive and the case insensitive variants\
respectively.\
**■3**\
Only the columns titled “c/s,” and “c/i,” are\
normative. Full name and print symbol are defined by other bodies and\
are out of scope of _The Unified Code for Units of Measure_.\
**■4** The selection of base units and the particular order are not\
normative. Any other basis **B**' that generates an\
isomorphic group of units is conformant with _The Unified Code for Units of Measure_.\
**■5**\
If the other base **B**' generates a different system of units\
_U_' it conforms to _The Unified Code for Units of Measure_ only if there is an homomorphism that\
maps\
_U_' onto _U_.\
**■6**\
Base units must be metric units only. Special units can not be base\
units.\
\
\
\
As can be seen the base system used to define _The Unified Code for Units of Measure_ is different\
from the system used by the _Système International_\
_d'Unités_ (SI) The SI base unit kilogram has been\
replaced by gram and the mole has been replaced by the radian that is\
defined dimensionless in the SI. Because of the latter change _The Unified Code for Units of Measure_\
is not isomorphic with the SI.\
\
\
\
The replacement of the kilogram is trivial. In order to bring syntax\
and semantics in line we can not have a unit with prefix in the\
base. We need a valid unit of mass before we can combine it with the\
prefix “kilo-” This change does not have any effect on the\
semantics whatsoever. The base unit kilogram is one of the oddities\
of the SI: if the gram would have been chosen as a base units the CGPM\
could have saved the rather annoying exception of the prefixing rules\
with the kilogram. At times where we have to multiply the wavelength\
of excited krypton-86 atoms by 1650763.73 to yield one meter, it seems\
trivial to divide the prototype of the kilogram by thousand to yield a\
base unit gram.\
\
\
\
The rationale for removing the mole from the base is that the mole is\
essentially a count of particles expressed in a unit of very high\
magnitude (Avogadro's number). There is no fundamental difference\
between the count of particles and the count other things.\
\
\
\
The radian has been adopted as the base unit of plane angle\
_α_ to facilitate the distinction from the solid angle\
_Ω_ by the relation _Ω_ =\
_α_ 2 and to distinguish rotational frequency\
_f_ from angular velocity _ω_ = 2 _π_ ·\
rad · _f_.\
\
\
\
| name | kind of quantity | print | c/s | c/i |\
| meter | length | m | `m` | `M` |\
| second | time | s | `s` | `S` |\
| gram | mass | g | `g` | `G` |\
| radian | plane angle | rad | `rad` | `RAD` |\
| kelvin | temperature | K | `K` | `K` |\
| coulomb | electric charge | C | `C` | `C` |\
| candela | luminous intensity | cd | `cd` | `CD` |\
\
 Table\
 2: The base units upon which the semantics of all the unit\
 atoms in The Unified Code for Units of Measure are defined. The selection of the base and the order\
 of the units in the base are not normative. Any other base is\
 acceptable as long as there is an isomorphism between the group of\
 units generated by the other base system and this one. All base units\
 are metric.\
\
\
**§29 dimensionless units** **■1**\
Dimensionless unit atoms are defined in [Table\\
3](https://ucum.org/ucum#dimless).\
**■2** There are seven columns titled “name,”\
“print,” “c/s,” “c/i,”\
“M,” “value,” and “definition.”\
The name is the full (official) name of the unit. The symbol\
recommended for use in print is listed in the column\
“print.” “C/s,” and “c/i” list the\
symbol in the case sensitive and the case insensitive variants\
respectively.\
The column “M” specifies whether this is a\
metric unit.\
The definition is a valid case sensitive expression of\
_The Unified Code for Units of Measure_ that defines the unit atom.\
**■3**\
Only the columns titled “c/s,” “c/i,”\
“M,” “value,” and “definition” are\
normative. Full name and print symbol are out of scope of _The Unified Code for Units of Measure_.\
**■4**\
The units named “parts per _N_” are provided to be used\
where absolutely necessary but are not endorsed. Especially\
“ppb” and “pptr” are deprecated since\
“billion” and “trillion” are ambiguous names\
internationally. The explicit powers of ten should be given instead.\
\
\
\
| name | print | c/s | c/i | M | definition value | definition unit |\
| the number ten for arbitrary powers | 10n | `10*` | `10*` | no | 10 | `1` |\
| the number ten for arbitrary powers | 10n | `10^` | `10^` | no | 10 | `1` |\
| the number pi | π | `[pi]` | `[PI]` | no | π | `1` |\
| percent | % | `%` | `%` | no | 1 | `10*-2` |\
| parts per thousand | ppth | `[ppth]` | `[PPTH]` | no | 1 | `10*-3` |\
| parts per million | ppm | `[ppm]` | `[PPM]` | no | 1 | `10*-6` |\
| parts per billion | ppb | `[ppb]` | `[PPB]` | no | 1 | `10*-9` |\
| parts per trillion | pptr | `[pptr]` | `[PPTR]` | no | 1 | `10*-12` |\
\
 Table\
 3: Dimensionless units. The units ppb and ppt are deprecated\
 because the names “billion” and “trillion” are\
 ambiguous. The expression “10\*-9” or\
 “10\*-12” should be used instead. When the\
 units percent or “parts per N” are used for\
 concentrations specific units are preferred, e.g.,\
 “ug/l” for mass concentration. The expression\
 “ug/kg” for ppb is also valid.\
\
\
\
The notation “`10*`” for powers of ten\
originated in the HL7 “ISO+“ extension of ISO 2955.\
In HL7 the character carat (‘`^`’) was thought as\
reserved. Since most people would expect to see\
“`10^3`” for the “third power of\
ten” and might in fact confuse “`10*3`”\
to mean “ten times 3”, the symbol using the carat was\
later added to _The Unified Code for Units of Measure_.\
\
\
\
**§30 SI units** **■1**\
SI units are defined by the international _Conférence_\
_Générale des Poids et Mesures_ (CGPM). _The Unified Code for Units of Measure_ definitions\
for those units are given in [Table\\
4](https://ucum.org/ucum#si).\
**■2** There are seven columns titled “name,”\
“print,” “c/s,” “c/i,”\
“M,” “value,” and “definition.”\
The name is the full (official) name of the unit. The symbol\
recommended for use in print is listed in the column\
“print.” “C/s,” and “c/i” list the\
symbol in the case sensitive and the case insensitive variants\
respectively.\
The column “M” specifies whether this is a\
metric unit.\
The definition\
is a valid case sensitive expression of _The Unified Code for Units of Measure_ that defines the unit\
atom.\
**■3**\
Only the columns titled “c/s,” “c/i,”\
“M,” “value,” and “definition” are\
normative. Full name and print symbol are defined by the CGPM and are\
out of scope of _The Unified Code for Units of Measure_.\
**■4**\
The function pair denoted “`cel(1 K)`” is\
defined as _f_ C( _x_) = _x_ \- 273.15 to\
convert from kelvin to degree Celsius, and\
_f_ C-1( _x_) = _x_ \+ 273.15 to\
convert from degree Celsius back to kelvin.\
\
\
\
The case insensitive symbol for pascal is\
“`PAL`” which conforms to ISO 2955 and prevents\
the name conflict between pascal and pico-ampère.\
\
\
\
Without reference to history, it is difficult to explain that the\
degree Celsius is part of the SI, because the degree Celsius is in a\
unique way incoherent with the SI, and is even superfluous since the\
base unit kelvin measures the same kind of quantity.\
\
\
\
| name | kind of quantity | print | c/s | c/i | M | definition value | definition unit |\
| mole | amount of substance | mol | `mol` | `MOL` | yes | 6.02214076 | `10*23` |\
| steradian | solid angle | sr | `sr` | `SR` | yes | 1 | `rad2` |\
| hertz | frequency | Hz | `Hz` | `HZ` | yes | 1 | `s-1` |\
| newton | force | N | `N` | `N` | yes | 1 | `kg.m/s2` |\
| pascal | pressure | Pa | `Pa` | `PAL` | yes | 1 | `N/m2` |\
| joule | energy | J | `J` | `J` | yes | 1 | `N.m` |\
| watt | power | W | `W` | `W` | yes | 1 | `J/s` |\
| ampère | electric current | A | `A` | `A` | yes | 1 | `C/s` |\
| volt | electric potential | V | `V` | `V` | yes | 1 | `J/C` |\
| farad | electric capacitance | F | `F` | `F` | yes | 1 | `C/V` |\
| ohm | electric resistance | Ω | `Ohm` | `OHM` | yes | 1 | `V/A` |\
| siemens | electric conductance | S | `S` | `SIE` | yes | 1 | `Ohm-1` |\
| weber | magnetic flux | Wb | `Wb` | `WB` | yes | 1 | `V.s` |\
| degree Celsius | temperature | °C | `Cel` | `CEL` | yes | • | `cel(1 K)` |\
| tesla | magnetic flux density | T | `T` | `T` | yes | 1 | `Wb/m2` |\
| henry | inductance | H | `H` | `H` | yes | 1 | `Wb/A` |\
| lumen | luminous flux | lm | `lm` | `LM` | yes | 1 | `cd.sr` |\
| lux | illuminance | lx | `lx` | `LX` | yes | 1 | `lm/m2` |\
| becquerel | radioactivity | Bq | `Bq` | `BQ` | yes | 1 | `s-1` |\
| gray | energy dose | Gy | `Gy` | `GY` | yes | 1 | `J/kg` |\
| sievert | dose equivalent | Sv | `Sv` | `SV` | yes | 1 | `J/kg` |\
\
 Table\
 4: SI units\
\
\
**§31 other units from ISO 1000, ISO 2955 and ANSI X3.50** **■1**\
Those unit atoms listed by ISO 2955 under the heading “other\
units from ISO 1000” and some units from ANSI X3.50 are defined\
in [Table\\
5](https://ucum.org/ucum#iso1000).\
**■2**\
The meaning of the columns is declared in [§30](https://ucum.org/ucum#para-30).2.\
**■3**\
Only the columns titled “c/s,” “c/i,”\
“M,” “value,” and “definition” are\
normative. Full name and print symbol are defined by ISO 1000 and are\
out of scope of _The Unified Code for Units of Measure_.\
\
\
\
| name | kind of quantity | print | c/s | c/i | M | definition value | definition unit |\
| gon, grade | plane angle | g | `gon` | `GON` | no | 0.9 | `deg` |\
| degree | plane angle | ° | `deg` | `DEG` | no | 2 | `[pi].rad/360` |\
| minute | plane angle | ' | `'` | `'` | no | 1 | `deg/60` |\
| second | plane angle | '' | `''` | `''` | no | 1 | `'/60` |\
| liter | volume | l | `l` | `L` | yes | 1 | `dm3` |\
| liter | volume | L | `L` | `L` | yes | 1 | `l` |\
| are | area | a | `ar` | `AR` | yes | 100 | `m2` |\
| minute | time | min | `min` | `MIN` | no | 60 | `s` |\
| hour | time | h | `h` | `HR` | no | 60 | `min` |\
| day | time | d | `d` | `D` | no | 24 | `h` |\
| tropical year | time | at | `a_t` | `ANN_T` | no | 365.24219 | `d` |\
| mean Julian year | time | aj | `a_j` | `ANN_J` | no | 365.25 | `d` |\
| mean Gregorian year | time | ag | `a_g` | `ANN_G` | no | 365.2425 | `d` |\
| year | time | a | `a` | `ANN` | no | 1 | `a_j` |\
| week | time | wk | `wk` | `WK` | no | 7 | `d` |\
| synodal month | time | mos | `mo_s` | `MO_S` | no | 29.53059 | `d` |\
| mean Julian month | time | moj | `mo_j` | `MO_J` | no | 1 | `a_j/12` |\
| mean Gregorian month | time | mog | `mo_g` | `MO_G` | no | 1 | `a_g/12` |\
| month | time | mo | `mo` | `MO` | no | 1 | `mo_j` |\
| tonne | mass | t | `t` | `TNE` | yes | 1 × 103 | `kg` |\
| bar | pressure | bar | `bar` | `BAR` | yes | 1 × 105 | `Pa` |\
| unified atomic mass unit | mass | u | `u` | `AMU` | yes | 1.66053906660 × 10-24 | `g` |\
| electronvolt | energy | eV | `eV` | `EV` | yes | 1 | `[e].V` |\
| astronomic unit | length | AU | `AU` | `ASU` | no | 149597.870691 | `Mm` |\
| parsec | length | pc | `pc` | `PRS` | yes | 3.085678 × 1016 | `m` |\
\
 Table\
 5: Other units from ISO 1000, ISO 2955, and some from ANSI X3.50.\
\
\
In the case sensitive variant the liter is defined both with an upper\
case ‘`L`” and a lower case\
‘`l`’. NIST \[63 FR 40338\] declares the upper case\
‘L’ as the preferred symbol for the U.S., while in many other\
countries the lower case ‘l’ is used. In fact the lower case\
‘l’ was in effect since 1879. A hundred years later in 1979\
the 16th CGPM decided to adopt the upper case ‘L’ as a\
second symbol for the liter. In the case insensitive variant there is\
only one symbol defined since there is no difference between upper\
case ‘L’ and lower case ‘l’.\
\
\
\
The unit “are” competes with year for the symbol\
“a” not only in ISO 2955, and ANSI X3.50, but also in\
ISO 1000 as stating the official CGPM approved symbols. This is why\
the symbol for are is “`ar`” in\
_The Unified Code for Units of Measure_. ISO 2955 explicitly adds the unit atom\
“`ha`” for hectare, while “hectare”\
is just the correct spelling of the compositum of “hecto”\
and “are” and thus would not require a separate unit\
atom. Nevertheless, ISO 2955 in its case insensitive variant assigns\
“`ARE`” to the are and\
“`har`” to the hectare. This is obviously an\
anomaly which _The Unified Code for Units of Measure_ will not follow. As a metric unit,\
“`ar`” can be prefixed with\
“`h`” to yield “`har`”\
\
\
\
ANSI X3.50 had two different series of symbols for the units of time,\
the ones from ISO 2955 as adopted by _The Unified Code for Units of Measure_ and the symbols\
“`yr`” “`mo`”\
“`wk`” “`hr`” and\
“`sec`” while “`d`” and\
“`min`” were defined twice. _The Unified Code for Units of Measure_ does not\
define these synonyms of ISO 2955 symbols, but does adopt those units\
from ANSI X3.50 that are not part of ISO 2955, namely\
“`mo`” and “`wk`” Month\
and week are useful units mainly in business or clinical medicine.\
\
\
\
The semantics of the units of time is difficult to capture. The\
difficulties start with the day: There is the sidereal and the solar\
day that depend on the earth's rotation. The earth's rotation is\
variable during one day and is continually slowing down in the long\
run. The usual subdivisions of the day in 24 hours of 60 minutes and\
60 seconds originated in Babylonia. The earth's rotation was too\
inexact to measure time, which is why the 11th CGPM (1954) defined the\
second based on a standardized historical tropical year (see below)\
which was later (13th CGPM 1967-1968) replaced by frequency\
measurement. Thus the second came to be the base unit of time and the\
day is now 864000 s exactly with the _Universal Coordinated_\
_Time_ (UTC) adding leap seconds every now and then.\
\
\
\
For the year we have to distinguish the “tropical” (solar,\
sidereal) year from the calendar year. And both are difficult. The\
tropical year is the year defined by time the earth travels around the\
sun. This is difficult to measure and varies over time. Around 1900\
it was 365.242196 d, currently it is 365.242190 d and around\
2100 it will be 365.242184 d. In addition these durations are\
averages. The actual length of each year may vary by several minutes\
due to the gravitational influence of other planets. Thus there is\
quite a high uncertainty already in the fourth decimal digit.\
\
\
\
The calendar year is also difficult because there is the Julian\
calendar (Sosigenes of Alexandria and Julius Caesar, 45 BC) with a\
slightly too long year of 365.25 d that causes the calendar to be\
one day ahead of the tropical year in 128 years. The Gregorian\
calendar (Christopher Clavius 1537-1612 and Pope Gregory XIII\
1545-1563) leaves out three leap years in 400 years (let _n_ be the\
year number, the leap year is dropped if _n_ mod 100 = 0 but not _n_\
mod 400 = 0.) The Gregorian mean year is thus 365.2425 d.\
This leap year arithmetic seems to be too much even for astronomers,\
which is why the light year ends up being defined based on the Julian\
year \[NIST Sp. Pub. 811, 1995 Edition\]. For this reason _The Unified Code for Units of Measure_\
defines Tropical, Julian and Gregorian year by means of subscripts,\
but assigns the default year symbol to the Julian year.\
\
\
\
The week is 7 days, this is a biblic truth we can count on (it is\
actually quite plausible that the week of seven days originated in\
Babylonia and entered Jewish tradition during the Babylonian exile.)\
\
\
\
The difficulty continues with the month. The lunar (so called\
“synodal” month is variable. Around 1900 it was\
29.5305886 d currently it is 29.5305889 d and in 2100 it\
will be 29.5305891 d, which we fixate in the 5th decimal digit\
with a considerable uncertainty. The calendar month is difficult\
because of the uneven distribution of days in a month over the year,\
and because of the two different calendar years. But we will usually\
use the mean calendar month, which is the Julian calendar year divided\
by 12.\
\
\
\
As a conclusion, great care has to be taken when the “customary\
units” of time are used to measure time. The SI has fixated the\
second which should be used whenever accuracy is required. For\
business purposes the Julian calendar is sufficient especially since\
the notion of the Work-Day (vs. Holiday) is more important than the\
imprecision over 128 years.\
\
\[Sources: “Calendar” _Britannica_\
_Online._`http://www.eb.com:180/cgi-bin/g?DocF=macro/5000/98/toc.html`.\
Claus Tondering, _Frequently asked questions about_\
_calendars._\
Part 1. 1998. `http://www.pip.dknet.dk/~c-t/calendar.faq1.txt`\]\
\
\
\
**§32 natural units** **■1**\
Fundamental constants of nature and units derived from these constants\
are defined in [Table\\
6](https://ucum.org/ucum#const).\
**■2**\
The meaning of the columns is declared in [§30](https://ucum.org/ucum#para-30).2.\
**■3**\
Only the columns titled “c/s,” “c/i,”\
“M,” “value,” and “definition” are\
normative. Full name and print symbol are defined by ISO 1000 and are\
out of scope of _The Unified Code for Units of Measure_.\
\
\
\
| name | kind of quantity | print | c/s | c/i | M | definition value | definition unit |\
| velocity of light | velocity | _c_ | `[c]` | `[C]` | yes | 299792458 | `m/s` |\
| Planck constant | action | _h_ | `[h]` | `[H]` | yes | 6.62607015 × 10-34 | `J.s` |\
| Boltzmann constant | (unclassified) | _k_ | `[k]` | `[K]` | yes | 1.380649 × 10-23 | `J/K` |\
| permittivity of vacuum | electric permittivity | _ε0_ | `[eps_0]` | `[EPS_0]` | yes | 8.854187817 × 10-12 | `F/m` |\
| permeability of vacuum | magnetic permeability | _μ0_ | `[mu_0]` | `[MU_0]` | yes | 1 | `4.[pi].10*-7.N/A2` |\
| elementary charge | electric charge | _e_ | `[e]` | `[E]` | yes | 1.602176634 × 10-19 | `C` |\
| electron mass | mass | _me_ | `[m_e]` | `[M_E]` | yes | 9.1093837139 × 10-31 | `kg` |\
| proton mass | mass | _mp_ | `[m_p]` | `[M_P]` | yes | 1.67262192595 × 10-27 | `kg` |\
| Newtonian constant of gravitation | (unclassified) | _G_ | `[G]` | `[GC]` | yes | 6.67430 × 10-11 | `m3.kg-1.s-2` |\
| standard acceleration of free fall | acceleration | _gn_ | `[g]` | `[G]` | yes | 9.80665 | `m/s2` |\
| standard atmosphere | pressure | atm | `atm` | `ATM` | no | 101325 | `Pa` |\
| light-year | length | l.y. | `[ly]` | `[LY]` | yes | 1 | `[c].a_j` |\
| gram-force | force | gf | `gf` | `GF` | yes | 1 | `g.[g]` |\
| pound force | force | lbf | `[lbf_av]` | `[LBF_AV]` | no | 1 | `[lb_av].[g]` |\
\
 Table\
 6: Natural units.\
\
\
This list is not complete. It does not list all constants but only\
those that are fundamental and from which many other constants can be\
derived. The source of this table is _The NIST Reference on_\
_Constants, Units, and Uncertainty_ Version 2.1, 21 May 1998. NIST\
Physics\
Laboratory. `http://physics.nist.gov/cuu/Constants/index.html`\
\
In the base system of _The Unified Code for Units of Measure_, the general gas constant _R_ is\
identical to the Boltzmann constant _k_. In the SI both are related\
through _R_ = _k_ × _N_ A, where\
_N_ A = 6.02214076 × 1023 /mol is\
the Avogadro constant. Because _The Unified Code for Units of Measure_ defines the mole to be the\
dimensionless Avogadro number (number of particles in 1 g of\
12C itself, there is no difference anymore if the Boltzmann\
constant is given as _k_ = 1.380649 ×\
1023 J/K or _R_ =\
8.314511 J mol-1 K-1.\
\
\
\
**§33 CGS units** **■1**\
The units of the older Centimeter-Gram-Second (CGS) system are defined\
in [Table\\
7](https://ucum.org/ucum#cgs).\
**■2**\
The meaning of the columns is declared in [§30](https://ucum.org/ucum#para-30).2.\
**■3**\
Only the columns titled “c/s,” “c/i,”\
“M,” “value,” and “definition” are\
normative. Full name and print symbol are out of scope of _The Unified Code for Units of Measure_.\
\
\
\
| name | kind of quantity | print | c/s | c/i | M | definition value | definition unit |\
| Kayser | lineic number | K | `Ky` | `KY` | yes | 1 | `cm-1` |\
| Gal | acceleration | Gal | `Gal` | `GL` | yes | 1 | `cm/s2` |\
| dyne | force | dyn | `dyn` | `DYN` | yes | 1 | `g.cm/s2` |\
| erg | energy | erg | `erg` | `ERG` | yes | 1 | `dyn.cm` |\
| Poise | dynamic viscosity | P | `P` | `P` | yes | 1 | `dyn.s/cm2` |\
| Biot | electric current | Bi | `Bi` | `BI` | yes | 10 | `A` |\
| Stokes | kinematic viscosity | St | `St` | `ST` | yes | 1 | `cm2/s` |\
| Maxwell | flux of magnetic induction | Mx | `Mx` | `MX` | yes | 1 × 10-8 | `Wb` |\
| Gauss | magnetic flux density | Gs, G | `G` | `GS` | yes | 1 × 10-4 | `T` |\
| Oersted | magnetic field intensity | Oe | `Oe` | `OE` | yes | 250 | `/[pi].A/m` |\
| Gilbert | magnetic tension | Gb | `Gb` | `GB` | yes | 1 | `Oe.cm` |\
| stilb | lum. intensity density | sb | `sb` | `SB` | yes | 1 | `cd/cm2` |\
| Lambert | brightness | L | `Lmb` | `LMB` | yes | 1 | `cd/cm2/[pi]` |\
| phot | illuminance | ph | `ph` | `PHT` | yes | 1 × 10-4 | `lx` |\
| Curie | radioactivity | Ci | `Ci` | `CI` | yes | 3.7 × 1010 | `Bq` |\
| Roentgen | ion dose | R | `R` | `ROE` | yes | 2.58 × 10-4 | `C/kg` |\
| radiation absorbed dose | energy dose | RAD | `RAD` | `[RAD]` | yes | 100 | `erg/g` |\
| radiation equivalent man | dose equivalent | REM | `REM` | `[REM]` | yes | 1 | `RAD` |\
\
 Table\
 7: CGS units\
\
\
Although the CGPM “accepts” only very few CGS units “for use with\
the SI,” CGS units are proper metric units. CGS units are still used\
in many physiological laboratories and in clinical diagnostics (e.g.,\
cardiology). In addition CGS units acquired a special dignity as this\
was the system of units used by the great physicists of the early 20th\
century, Albert Einstein, Max Planck, and many others who worked on\
the scientific revolution that had quite a cultural impact.\
\
\
\
The CGS system defined electric and magnetic phenomena differently\
which is why the units named “oersted” and “maxwell” have no\
proper SI counterpart. This table was compiled from various sources\
and is not complete and not very systematic. We therefore welcome\
suggestions and advice as to how this table could be completed.\
\
\
\
Customary units have once been used all over Europe. Units were taken\
from nature: anatomical structures (e.g., arm, foot, finger),\
botanical objects (e.g., grains of various sorts, rod), or processes\
of everyday life (e.g., amount of land one could plow in a morning,\
the length of 1000 steps, an hour of walking, etc.).\
\
\
\
Many of these units can be traced back in history to the Romans\
(mile), Greeks (carat) and even more ancient times. It is thus no\
wonder that this heritage was in some way ordered. Indeed, one finds\
the same names for units used in different countries and most of these\
units where divided into smaller or multiplied to larger units in the\
same way.\
\
\
\
For example, there was the foot (de. “Fuß”\
fr. “pied” nl. “voet”) that was divided into\
12 inches (de. “Zoll” fr. “pouce”). An inch\
was divided into 12 lines (de. “Linie”\
fr. “ligne” ). Two feet was one ell\
(de. “Elle” da. “Alen”\
sv. “Aln”). The ell was, however, not very popular in\
England, as opposed to the rest of Europe. Conversely, the yard is\
hard to find elsewhere, aside from the Argentinian “vara.”\
But it is perhaps no accident that the meter ended up as the 40 ×\
10-6 of an earth's meridian, which is approximately one\
yard (43.7 × 10-6). The rod (de. “Rute”\
fr. “perche” nl. “roede”\
sv. “stång”) was very popular all over Europe and so\
was the fathom (de. “Klafter”).\
\
\
\
The square rod (de. “Quadratrute” fr. “perche-carrée”\
nl. “vierkante-roede” was mainly used to measure land. The acre as\
the legendary land to sow in one morning (or day) is also widespread\
(de. “Morgen, Tagwerk, Acker” fr. “arpent” sv. “tunnland” ,\
although the exact amount in square rod varies considerably from\
region to region. Interestingly, even the special purpose measures\
such as the “hand” for measuring horses have international equivalents\
(de. “faust”).\
\
\
\
One can indeed say that there was once a “ _système_\
_international d'unités coutumières_“ but the\
magnitudes of the units were not standardized internationally. Of\
course, Great Britain had the most impact in standardizing the\
customary system, because of its colonies, including its most\
important colony, America. However, after the customary units were\
established in the U.S. a major reform took place through the British\
Weights and Measures Act of 1824. For instance, Queen Anne's wine\
Gallon of 231 cubic inches, still used in the U.S., was discarded\
then, and the older bushel was standardized differently in Great\
Britain. Other deviations between the English and U.S. measures are\
due to various alignments with the metric system. Thus, in the U.S.,\
the yard was standardized as 3600/3937 m and the inch was\
2.540005 cm while in England the inch was still 2.539998 cm.\
\
\
\
In 1959 major parts of the U.S. and British system of customary units\
were standardized internationally, again aligned to the metric system\
which is why the international yard is 0.9144 m exactly and the\
nautical mile became 1852 m exactly. However, traditional\
subdivisions and multiples have not been abolished in favor of the\
international standard. Furthermore the old U.S. standard for the yard\
is still legally used for land surveying.\
\
\
\
Conclusively, there are different systems of customary units that are\
in use today. These systems use the same names for units that have\
different equivalents in the metric system, because the customary\
systems are based on different reference quantities but multiples and\
subdivisions of the reference quantities are very similar, though with\
notable exceptions.\
\
\
\
In the following tables we tried to give the original definitions to\
the customary units. This means in general that the references to the\
metric system are as few as possible, with most of the units of one\
system defined as multiples and subdivisions of one reference unit.\
\
\
\
We use the subscript notation to disambiguate units with same names in\
the different systems. Subscript notation means, for instance that if\
the print symbol for foot is “ft” we use subscripts to\
distinguish the international foot “fti” the\
U.S. survey foot “ftus” and the British\
Imperial foot “ftbr” We do not actually list\
print symbols for customary units, because there seems to be no\
standard for it, and because defining print symbols is out of scope of\
_The Unified Code for Units of Measure_. However, we presume that subscripts be used to disambiguate\
whatever print symbols are being used. According to [§§13ff](https://ucum.org/ucum#para-13), _The Unified_\
_Code for Units of Measure_ uses the underscore to denote those\
subscripts, and also encloses the entire unit atom into square\
brackets. Hence, the symbols for the international foot, the\
U.S. survey foot and the British Imperial foot are defined as\
“`[ft_i]`,” “`[ft_us]`,”\
and “`[ft_br]`” respectively.\
\
\
\
Prospective users of _The Unified Code for Units of Measure_ may be disappointed by the fact that\
there are many different symbols for foot and inch defined but all of\
them have a subscript and thus none of them are equal to the\
ANSI X3.50 symbols. We considered to define default symbols for\
customary units, where, e.g., the common units of length (foot, inch)\
would default to the international customary units, while mass units\
(pound, ounce) would default to the avoirdupois system. However,\
because the customary system is quite complex, and units by the same\
names can differ by more than 20%, defining defaults will probably\
cause even more confusion. There is no denial: a gallon is not just a\
gallon and a pound is not just a pound, this is the disadvantage of\
dealing with a unit system of medieval origin.\
\
\
\
**§34 international customary**\
**units** **■1**\
The unified U.S. and British Imperial customary units, so called\
“international” customary units are defined in [Table\\
8](https://ucum.org/ucum#intcust).\
**■2**\
The meaning of the columns is declared in [§30](https://ucum.org/ucum#para-30).2\. With the exception that\
the column named\
“print” is not available.\
**■3**\
Only the columns titled “c/s,” “c/i,”\
“M,” “value,” and “definition” are\
normative. The full name is out of scope of _The Unified Code for Units of Measure_.\
**■4**\
The special symbols for “square inch,” “cubic\
foot,” etc. are deprecated. The preferred expressions use the\
exponents 2 and 3 respectively as shown in the column\
“definition”\
\
\
\
| name | kind of quantity | c/s | c/i | M | definition value | definition unit |\
| inch | length | `[in_i]` | `[IN_I]` | no | 2.54 | `cm` |\
| foot | length | `[ft_i]` | `[FT_I]` | no | 12 | `[in_i]` |\
| yard | length | `[yd_i]` | `[YD_I]` | no | 3 | `[ft_i]` |\
| mile | length | `[mi_i]` | `[MI_I]` | no | 5280 | `[ft_i]` |\
| fathom | depth of water | `[fth_i]` | `[FTH_I]` | no | 6 | `[ft_i]` |\
| nautical mile | length | `[nmi_i]` | `[NMI_I]` | no | 1852 | `m` |\
| knot | velocity | `[kn_i]` | `[KN_I]` | no | 1 | `[nmi_i]/h` |\
| square inch | area | `[sin_i]` | `[SIN_I]` | no | 1 | `[in_i]2` |\
| square foot | area | `[sft_i]` | `[SFT_I]` | no | 1 | `[ft_i]2` |\
| square yard | area | `[syd_i]` | `[SYD_I]` | no | 1 | `[yd_i]2` |\
| cubic inch | volume | `[cin_i]` | `[CIN_I]` | no | 1 | `[in_i]3` |\
| cubic foot | volume | `[cft_i]` | `[CFT_I]` | no | 1 | `[ft_i]3` |\
| cubic yard | volume | `[cyd_i]` | `[CYD_I]` | no | 1 | `[yd_i]3` |\
| board foot | volume | `[bf_i]` | `[BF_I]` | no | 144 | `[in_i]3` |\
| cord | volume | `[cr_i]` | `[CR_I]` | no | 128 | `[ft_i]3` |\
| mil | length | `[mil_i]` | `[MIL_I]` | no | 1 × 10-3 | `[in_i]` |\
| circular mil | area | `[cml_i]` | `[CML_I]` | no | 1 | `[pi]/4.[mil_i]2` |\
| hand | height of horses | `[hd_i]` | `[HD_I]` | no | 4 | `[in_i]` |\
\
 Table\
 8: International customary units\
\
\
In general the international customary units are effective in the\
U.S. and in Great Britain since 1959. We are unsure, however, about\
this in countries that formerly or at present belong to the\
Commonwealth. We therefore appreciate advice and reference to original\
sources on this transition. Conceivably other countries may have made\
exceptions in the transition to the international definitions of\
customary units, such as the U.S. where the old definitions have been\
retained for the purpose of land surveying.\
\
\
\
It is not quite clear exactly what units the international customary\
system comprises. According to the Encyclopedia Britannica\
\[ _British Imperial System. Britannica Online_\], the rod was\
removed in Great Britain in 1963. Since the definition of the acre is\
based on the rod, we did not include rod and acre in the international\
customary system. In the U.S. the acre is still defined on the older\
U.S. customary system as of 1893.\
\
\
\
In general, we did not include special customary units of area and\
volume in [Table\\
8](https://ucum.org/ucum#intcust), since these are still used\
differently in the U.S. Special symbols such as square inch and cubic\
foot have been included according to ANSI X3.50. Generally the\
“square-” and “cubic-” prefixes are\
unnecessary in ISO 2955 and ANSI X3.50 and are deprecated by\
_The Unified Code for Units of Measure_. We placed the board foot, cord and circular mil into the\
international table because these units are suggested by\
ANSI X3.50 but we were not sure in what sense they are still\
used. We did, however, not include the square mile in the\
international table because in the U.S. measurements in square miles\
are most likely based on the survey mile that is part of the older\
system, see [§35](https://ucum.org/ucum#para-35).\
\
\
\
The circular mil is exactly the area of a circle with a diameter of\
one mil. One mil, in turn, equals 1/1000 inch (“mil” is the\
etymological equivalent of “milli-inch” ) The mil has been\
defined in [Table\\
8](https://ucum.org/ucum#intcust) to support the exact definition of\
the circular mil.\
\
\
\
ANSI X3.50 does not define a symbol for the “hand,” but this unit is\
mentioned in the table given by the Encyclopedia Britannica. The hand\
is used in measuring the height of horses from foot to shoulder. It\
was probably not subject to the internationalization of customary\
units. Any advice as whether the hand is used based on an older\
British or U.S. definition is appreciated.\
\
\
\
**§35 U.S. survey lengths** **■1**\
The older U.S. units according to the definition of the inch in the\
U.S. Metric Law of 1866 and the definition of foot and yard that was\
valid from 1893 until 1959.\
**■2**\
The meaning of the columns is declared in [§34](https://ucum.org/ucum#para-34).\
\
\[Barry N. Taylor, _Guide to the Use of the International System of_\
_Units (SI)_ \[NIST Special Publication 811\], National Institute for\
Standards and Technology (NIST), 1995. Available from: URL:\
`http://physics.nist.gov/Document/sp811.pdf`\]\
\
\
| name | kind of quantity | c/s | c/i | M | definition value | definition unit |\
| foot | length | `[ft_us]` | `[FT_US]` | no | 1200 | `m/3937` |\
| yard | length | `[yd_us]` | `[YD_US]` | no | 3 | `[ft_us]` |\
| inch | length | `[in_us]` | `[IN_US]` | no | 1 | `[ft_us]/12` |\
| rod | length | `[rd_us]` | `[RD_US]` | no | 16.5 | `[ft_us]` |\
| Gunter's chain, Surveyor's chain | length | `[ch_us]` | `[CH_US]` | no | 4 | `[rd_us]` |\
| link for Gunter's chain | length | `[lk_us]` | `[LK_US]` | no | 1 | `[ch_us]/100` |\
| Ramden's chain, Engineer's chain | length | `[rch_us]` | `[RCH_US]` | no | 100 | `[ft_us]` |\
| link for Ramden's chain | length | `[rlk_us]` | `[RLK_US]` | no | 1 | `[rch_us]/100` |\
| fathom | length | `[fth_us]` | `[FTH_US]` | no | 6 | `[ft_us]` |\
| furlong | length | `[fur_us]` | `[FUR_US]` | no | 40 | `[rd_us]` |\
| mile | length | `[mi_us]` | `[MI_US]` | no | 8 | `[fur_us]` |\
| acre | area | `[acr_us]` | `[ACR_US]` | no | 160 | `[rd_us]2` |\
| square rod | area | `[srd_us]` | `[SRD_US]` | no | 1 | `[rd_us]2` |\
| square mile | area | `[smi_us]` | `[SMI_US]` | no | 1 | `[mi_us]2` |\
| section | area | `[sct]` | `[SCT]` | no | 1 | `[mi_us]2` |\
| township | area | `[twp]` | `[TWP]` | no | 36 | `[sct]` |\
| mil | length | `[mil_us]` | `[MIL_US]` | no | 1 × 10-3 | `[in_us]` |\
\
 Table\
 9: Older U.S. “survey” lengths (also called "statute" lengths)\
\
\
After the 1959 international agreement changed the definition of the yard in the US to be 0.9144 m exactly,\
surveyors and\
civil engineers complained that voluminous legacy surveys and so forth used the previous definition of (1200/3937)\
m and that\
this change would be disruptive. So, by statute, Congress created a survey foot of (1200/3937) m (the old 1893\
Mendenhall\
Order definition). Thus, by statute, miles used in surveying are referred to as statute miles of 5280 survey feet\
each. The\
fathom, rod, and furlong are likewise based on the survey foot.\
\
\
\
According to NIST, the acre as normally used in the U.S. is defined\
in terms of U.S. survey lengths, and not in terms of the\
international customary system. This older U.S. customary system of\
survey lengths is still used for geodesic measurements.\
\
\
\
**§36 British Imperial lengths** **■1** [Table\\
10](https://ucum.org/ucum#brit-length) defines symbols for the older British Imperial lengths as of\
the British Weights and Measures Act of 1824.\
**■2**\
The meaning of the columns is declared in [§34](https://ucum.org/ucum#para-34).\
\
\
\
| name | kind of quantity | c/s | c/i | M | definition value | definition unit |\
| inch | length | `[in_br]` | `[IN_BR]` | no | 2.539998 | `cm` |\
| foot | length | `[ft_br]` | `[FT_BR]` | no | 12 | `[in_br]` |\
| rod | length | `[rd_br]` | `[RD_BR]` | no | 16.5 | `[ft_br]` |\
| Gunter's chain | length | `[ch_br]` | `[CH_BR]` | no | 4 | `[rd_br]` |\
| link for Gunter's chain | length | `[lk_br]` | `[LK_BR]` | no | 1 | `[ch_br]/100` |\
| fathom | length | `[fth_br]` | `[FTH_BR]` | no | 6 | `[ft_br]` |\
| pace | length | `[pc_br]` | `[PC_BR]` | no | 2.5 | `[ft_br]` |\
| yard | length | `[yd_br]` | `[YD_BR]` | no | 3 | `[ft_br]` |\
| mile | length | `[mi_br]` | `[MI_BR]` | no | 5280 | `[ft_br]` |\
| nautical mile | length | `[nmi_br]` | `[NMI_BR]` | no | 6080 | `[ft_br]` |\
| knot | velocity | `[kn_br]` | `[KN_BR]` | no | 1 | `[nmi_br]/h` |\
| acre | area | `[acr_br]` | `[ACR_BR]` | no | 4840 | `[yd_br]2` |\
\
 Table\
 10: British Imperial lengths\
\
\
The older British Imperial system is predominantly of historical\
interest. However, it may be that some former members of the\
Commonwealth have retained this system after 1959, when the unified\
international definitions where established, and after 1963, when the\
British system was revised in England.\
\
\
\
The chain was proposed by Edmund Gunter in England of the 17th\
century. It is possible that Gunter's chain and Ramden's chain are\
related to other European traditional units such as the English\
“rope” (measuring 20 feet) or the old German\
“Landseil” (measuring 52 ells or 104 feet) named after\
ropes or chains that could be spanned in order to measure land. The\
difference in the definitions of those units is no surprise as there\
is nothing that restricts a chain or rope to a particular\
length. However, these units are still similar in magnitude.\
\
\
\
**§37 U.S. volumes** **■1**\
The U.S. volumes, so called “capacity” measures, which\
are different for fluid goods (wine) and dry goods (grain), are\
defined in [Table\\
11](https://ucum.org/ucum#us-volumes).\
**■2**\
The meaning of the columns is declared in [§34](https://ucum.org/ucum#para-34).\
\
\
\
| name | kind of quantity | c/s | c/i | M | definition value | definition unit |\
| Queen Anne's wine gallon | fluid volume | `[gal_us]` | `[GAL_US]` | no | 231 | `[in_i]3` |\
| barrel | fluid volume | `[bbl_us]` | `[BBL_US]` | no | 42 | `[gal_us]` |\
| quart | fluid volume | `[qt_us]` | `[QT_US]` | no | 1 | `[gal_us]/4` |\
| pint | fluid volume | `[pt_us]` | `[PT_US]` | no | 1 | `[qt_us]/2` |\
| gill | fluid volume | `[gil_us]` | `[GIL_US]` | no | 1 | `[pt_us]/4` |\
| fluid ounce | fluid volume | `[foz_us]` | `[FOZ_US]` | no | 1 | `[gil_us]/4` |\
| fluid dram | fluid volume | `[fdr_us]` | `[FDR_US]` | no | 1 | `[foz_us]/8` |\
| minim | fluid volume | `[min_us]` | `[MIN_US]` | no | 1 | `[fdr_us]/60` |\
| cord | fluid volume | `[crd_us]` | `[CRD_US]` | no | 128 | `[ft_i]3` |\
| bushel | dry volume | `[bu_us]` | `[BU_US]` | no | 2150.42 | `[in_i]3` |\
| historical winchester gallon | dry volume | `[gal_wi]` | `[GAL_WI]` | no | 1 | `[bu_us]/8` |\
| peck | dry volume | `[pk_us]` | `[PK_US]` | no | 1 | `[bu_us]/4` |\
| dry quart | dry volume | `[dqt_us]` | `[DQT_US]` | no | 1 | `[pk_us]/8` |\
| dry pint | dry volume | `[dpt_us]` | `[DPT_US]` | no | 1 | `[dqt_us]/2` |\
| tablespoon | volume | `[tbs_us]` | `[TBS_US]` | no | 1 | `[foz_us]/2` |\
| teaspoon | volume | `[tsp_us]` | `[TSP_US]` | no | 1 | `[tbs_us]/3` |\
| cup | volume | `[cup_us]` | `[CUP_US]` | no | 16 | `[tbs_us]` |\
| metric fluid ounce | fluid volume | `[foz_m]` | `[FOZ_M]` | no | 30 | `mL` |\
| metric cup | volume | `[cup_m]` | `[CUP_M]` | no | 240 | `mL` |\
| metric teaspoon | volume | `[tsp_m]` | `[TSP_M]` | no | 5 | `mL` |\
| metric tablespoon | volume | `[tbs_m]` | `[TBS_M]` | no | 15 | `mL` |\
\
 Table\
 11: U.S. volumes including so called “dry measures”\
\
\
The U.S. fluid volumes have been defined based on Queen Anne's wine\
gallon which was in turn defined exactly as 231 cubic inch. Although\
we used international inch, we are not sure what inch definition is\
actually used for defining the exact size of a U.S. gallon. However,\
the differences between the various inches are minimal, even when\
raised to the 3rd power (i.e., the difference between the U.S. inch\
and the British Imperial inch remains in the sixth decimal digit.)\
\
\
\
Dry measures are based on the bushel (corn bushel), originally defined\
in 1701 as “any round measure with a plain and even bottom, being\
18.5 inches wide throughout and 8 inches deep.” This definition,\
being (18.5/2)2 π × 8 = 2150.42017138221... cubic\
inch was later truncated to 2150.42 cubic inch exactly. At times the\
bushel was closely related with the Winchester gallon (corn gallon),\
which has been mentioned as an historical curiosity.\
\
\
\
ANSI X3.50 defines symbols for the units cup, tablespoon and teaspoon\
which are predominantly used in cooking recipes but also in practical\
medicine. Similar units can often be found in European cook books, but\
are usually translated into metric units outside the U.S. For\
practical medicine these are still very handy units to give\
instructions to patients.\
\
\
\
**§38 British Imperial**\
**volumes** **■1**\
British Imperial volumes according to the Weights and Measures Act of\
1824 are defined in [Table\\
12](https://ucum.org/ucum#brit-volumes).\
**■2**\
The meaning of the columns is declared in [§34](https://ucum.org/ucum#para-34).\
\
\
\
| name | kind of quantity | c/s | c/i | M | definition value | definition unit |\
| gallon | volume | `[gal_br]` | `[GAL_BR]` | no | 4.54609 | `l` |\
| peck | volume | `[pk_br]` | `[PK_BR]` | no | 2 | `[gal_br]` |\
| bushel | volume | `[bu_br]` | `[BU_BR]` | no | 4 | `[pk_br]` |\
| quart | volume | `[qt_br]` | `[QT_BR]` | no | 1 | `[gal_br]/4` |\
| pint | volume | `[pt_br]` | `[PT_BR]` | no | 1 | `[qt_br]/2` |\
| gill | volume | `[gil_br]` | `[GIL_BR]` | no | 1 | `[pt_br]/4` |\
| fluid ounce | volume | `[foz_br]` | `[FOZ_BR]` | no | 1 | `[gil_br]/5` |\
| fluid dram | volume | `[fdr_br]` | `[FDR_BR]` | no | 1 | `[foz_br]/8` |\
| minim | volume | `[min_br]` | `[MIN_BR]` | no | 1 | `[fdr_br]/60` |\
\
 Table\
 12: British Imperial volumes\
\
\
The British Weights and Measures Act of 1824 removed the medieval\
distinction between wine and grain measures and defined one unified\
system of volumes based on a new Gallon that was defined similarly as\
the metric unit liter: “10 imperial pounds weight of distilled\
water weighed in air against brass weights with the water and the air\
at a temperature of 62 degrees of Fahrenheit's thermometer and with\
the barometer at 30 inches.”\
\
\
\
With the current definition of the gallon as 277.421 cubic inches\
(approximately) and a density of water of 0.99878 kg/l according\
to NIST data, the inch must have been approximately 2.5371 cm at\
that time. Because of this difficulty with the original definition of\
the British gallon we based the British Imperial volumes on the gallon\
for which there is an exact metric equivalence, according to NIST,\
which provides usually well researched data.\
\
\
\
Note that the subdivisions of the British Imperial system of volumes\
differs from the U.S. system of fluid volumes between gill and fluid\
ounce: in the British system 1 oz fl equals 1/5 gill where\
in the U.S. system 1 oz fl equals 1/4 gill. Thus, although\
the British system starts out with a 20% larger gallon, the British\
fluid ounce, fluid dram and minim are 4% smaller than the U.S. units\
with the same name.\
\
\
\
**§39 avoirdupois weights** **■1**\
The avoirdupois system of mass units is defined in [Table\\
13](https://ucum.org/ucum#avoirdupois).\
**■2**\
The meaning of the columns is declared in [§34](https://ucum.org/ucum#para-34).\
\
\
\
The avoirdupois system is used in the U.S. as well as in countries that\
use the British Imperial system. Avoirdupois is the default system of\
mass units used for all goods that “have weight”\
(fr. _avoir du poids_). Interestingly all three systems of\
weight are based on the same grain of barley, standardized to\
64.79891 mg exactly \[NIST\].\
\
\
\
| name | kind of quantity | c/s | c/i | M | definition value | definition unit |\
| grain | mass | `[gr]` | `[GR]` | no | 64.79891 | `mg` |\
| pound | mass | `[lb_av]` | `[LB_AV]` | no | 7000 | `[gr]` |\
| ounce | mass | `[oz_av]` | `[OZ_AV]` | no | 1 | `[lb_av]/16` |\
| dram | mass | `[dr_av]` | `[DR_AV]` | no | 1 | `[oz_av]/16` |\
| short hundredweight, U.S. hundredweight | mass | `[scwt_av]` | `[SCWT_AV]` | no | 100 | `[lb_av]` |\
| long hundredweight, British hundredweight | mass | `[lcwt_av]` | `[LCWT_AV]` | no | 112 | `[lb_av]` |\
| short ton, U.S. ton | mass | `[ston_av]` | `[STON_AV]` | no | 20 | `[scwt_av]` |\
| long ton, British ton | mass | `[lton_av]` | `[LTON_AV]` | no | 20 | `[lcwt_av]` |\
| stone, British stone | mass | `[stone_av]` | `[STONE_AV]` | no | 14 | `[lb_av]` |\
\
 Table\
 13: Avoirdupois weights\
\
\
**§40 troy weights** **■1**\
The troy system of mass units is defined in [Table\\
14](https://ucum.org/ucum#troy).\
**■2**\
The meaning of the columns is declared in [§34](https://ucum.org/ucum#para-34).\
\
\
\
The troy system originates in Troyes, a City in the Champagne (France)\
that hosted a major European fair. The troy system was later used for\
measuring precious metals. The World Monetary Fund valued all\
currencies against the troy ounce of gold at least until the 1960s\
(advice appreciated). The troy ounce is still used in worldwide trade\
with gold, even in countries that otherwise use metric units\
(de. “feinunze”). The troy system retains the original Roman\
subdivision of the pound in 12 ounces. The Roman _uncia_ was “one\
twelfth” of a _libra_ (hence the symbol “lb” for the pound),\
just as the inch (also originating from la. “libra” is one twelfth\
of a foot. The subdivision of 12 ounces/inches per pound/foot and 2\
foot per ell (la. “cubit” apparently originated in the ancient\
Egypt and was carried on by the Greeks and Romans into the medieval\
Europe. However, there was always an ambiguity such that the\
subdivision of 1/12 could become 1/16 and vice versa, hence the\
avoirdupois ounce of 1/16 pound.\
\
\
\
Note also that the troy pound was abolished in England on January 6,\
1879 \[Jacques J. Proot, _Anglo-Saxon weights & measures_, URL:\
`http://members.aol.com/JackProot/met/spvolas.html`\].\
\
\
\
| name | kind of quantity | c/s | c/i | M | definition value | definition unit |\
| pennyweight | mass | `[pwt_tr]` | `[PWT_TR]` | no | 24 | `[gr]` |\
| ounce | mass | `[oz_tr]` | `[OZ_TR]` | no | 20 | `[pwt_tr]` |\
| pound | mass | `[lb_tr]` | `[LB_TR]` | no | 12 | `[oz_tr]` |\
\
 Table\
 14: Troy weights\
\
\
**§41 apothecaries' weights.** **■1**\
The apothecaries' system of mass units is defined in [Table\\
15](https://ucum.org/ucum#apoth).\
**■2**\
The meaning of the columns is declared in [§34](https://ucum.org/ucum#para-34).\
\
\
\
| name | kind of quantity | c/s | c/i | M | definition value | definition unit |\
| scruple | mass | `[sc_ap]` | `[SC_AP]` | no | 20 | `[gr]` |\
| dram, drachm | mass | `[dr_ap]` | `[DR_AP]` | no | 3 | `[sc_ap]` |\
| ounce | mass | `[oz_ap]` | `[OZ_AP]` | no | 8 | `[dr_ap]` |\
| pound | mass | `[lb_ap]` | `[LB_AP]` | no | 12 | `[oz_ap]` |\
| metric ounce | mass | `[oz_m]` | `[OZ_M]` | no | 28 | `g` |\
\
 Table\
 15: Apothecaries' weights\
\
\
Note that some U.S. pharmacies still use this system of apothecaries'\
weights when measuring the amount of drugs. This system is very\
different from the avoirdupois system though based on the same\
grain. The apothecaries' dram is more than twice as much as the\
avoirdupois dram, the ounce is still 10% greater than the avoirdupois\
ounce while the pound is 20% less than the avoirdupois pound. The\
apothecaries' system, just as the troy system, keeps the original\
Roman subdivision of an ounce (la. “uncia” to be 1/12 pound\
(la. “libra”). Hence is the apothecaries' pound about 22% smaller\
than the avoirdupois pound, while its subdivisions are greater than\
the respective avoirdupois subdivisions (ounce 10%, dram 119%). This\
difference in the weight systems is the most important reason why\
ANSI X3.50 should not be applied in medicine, where both systems are\
being used and therefore misinterpretations are inevitable.\
\
\
\
**§42 typesetter's lengths** **■1**\
The units of length as used in typesetting are defined in [Table\\
16](https://ucum.org/ucum#typeset).\
**■2**\
The meaning of the columns is declared in [§34](https://ucum.org/ucum#para-34).\
\
\
\
| name | kind of quantity | c/s | c/i | M | definition value | definition unit |\
| line | length | `[lne]` | `[LNE]` | no | 1 | `[in_i]/12` |\
| point | length | `[pnt]` | `[PNT]` | no | 1 | `[lne]/6` |\
| pica | length | `[pca]` | `[PCA]` | no | 12 | `[pnt]` |\
| Printer's point | length | `[pnt_pr]` | `[PNT_PR]` | no | 0.013837 | `[in_i]` |\
| Printer's pica | length | `[pca_pr]` | `[PCA_PR]` | no | 12 | `[pnt_pr]` |\
| pied, French foot | length | `[pied]` | `[PIED]` | no | 32.48 | `cm` |\
| pouce, French inch | length | `[pouce]` | `[POUCE]` | no | 1 | `[pied]/12` |\
| ligne, French line | length | `[ligne]` | `[LIGNE]` | no | 1 | `[pouce]/12` |\
| didot, Didot's point | length | `[didot]` | `[DIDOT]` | no | 1 | `[ligne]/6` |\
| cicero, Didot's pica | length | `[cicero]` | `[CICERO]` | no | 12 | `[didot]` |\
\
 Table\
 16: Units used in typesetting\
\
\
There are three systems of typesetter's lengths in use today:\
Françcois-Ambroise Didot (1730-1804), a publisher in Paris,\
invented this system based on the traditional subdivisions of the\
customary units: 1 line was 1/12 inch and 1/6 line was one\
point. Henceforth the size of letters were measured in point. However,\
the Didot system is based on the _pouce_, i.e. the french\
inch, which, just as the English inch, is 1/12 _pied_\
(foot). But the French foot was about 6.5% greater than the British\
Imperial foot. In the Anglo-American realm the typesetter's point was\
based on the British Imperial inch, with the same\
subdivisions. However, in the type foundries' industry the original\
definition of a point drifted apart, and in the late 19th century\
U.S. type foundries reestablished a slightly (0.375%) greater standard\
point. This point made its way back to the British. However, recently,\
the computer typesetting industry readjusted the point to its original\
size of 1/72 inch. All three systems, however, are still being used\
today.\
\
\
\
**§43 legacy units for**\
**heat and temperature** **■1**\
Older units of heat (energy) and temperature are defined in [Table\\
17](https://ucum.org/ucum#heat).\
**■2**\
The meaning of the columns is declared in [§30](https://ucum.org/ucum#para-30).2.\
**■3**\
Only the columns titled “c/s,” “c/i,”\
“M,” “value,” and “definition” are\
normative. Full name and print symbol are either not standardized or\
standardized by other bodies and are out of scope of _The Unified Code for Units of Measure_.\
**■4**\
The function pair denoted “`degf(5 K/9)`” is\
defined as _f_ F( _x_) = 9/5 _x_ \- 459.67 to convert\
from kelvin to degree Fahrenheit, and\
_f_ F-1( _x_) = 5/9 ( _x_ \+ 459.67) to\
convert from degree Fahrenheit back to kelvin.\
**■5**\
The function pair denoted “`degre(5 K/4)`” is\
defined as _f_ Ré( _x_) = 4/5 _x_ \- 218.52 to convert\
from kelvin to degree Réaumur, and\
_f_ Ré-1( _x_) = 5/4 ( _x_ \+ 218.52) to\
convert from degree Réaumur back to kelvin.\
\
\
\
| name | kind of quantity | print | c/s | c/i | M | definition value | definition unit |\
| degree Fahrenheit | temperature | °F | `[degF]` | `[DEGF]` | no | • | `degf(5 K/9)` |\
| degree Rankine | temperature | °R | `[degR]` | `[degR]` | no | 5 | `K/9` |\
| degree Réaumur | temperature | °Ré | `[degRe]` | `[degRe]` | no | • | `degre(5 K/4)` |\
| calorie at 15 °C | energy | cal15°C | `cal_[15]` | `CAL_[15]` | yes | 4.18580 | `J` |\
| calorie at 20 °C | energy | cal20°C | `cal_[20]` | `CAL_[20]` | yes | 4.18190 | `J` |\
| mean calorie | energy | calm | `cal_m` | `CAL_M` | yes | 4.19002 | `J` |\
| international table calorie | energy | calIT | `cal_IT` | `CAL_IT` | yes | 4.1868 | `J` |\
| thermochemical calorie | energy | calth | `cal_th` | `CAL_TH` | yes | 4.184 | `J` |\
| calorie | energy | cal | `cal` | `CAL` | yes | 1 | `cal_th` |\
| nutrition label Calories | energy | Cal | `[Cal]` | `[CAL]` | no | 1 | `kcal_th` |\
| British thermal unit at 39 °F | energy | Btu39°F | `[Btu_39]` | `[BTU_39]` | no | 1.05967 | `kJ` |\
| British thermal unit at 59 °F | energy | Btu59°F | `[Btu_59]` | `[BTU_59]` | no | 1.05480 | `kJ` |\
| British thermal unit at 60 °F | energy | Btu60°F | `[Btu_60]` | `[BTU_60]` | no | 1.05468 | `kJ` |\
| mean British thermal unit | energy | Btum | `[Btu_m]` | `[BTU_M]` | no | 1.05587 | `kJ` |\
| international table British thermal unit | energy | BtuIT | `[Btu_IT]` | `[BTU_IT]` | no | 1.05505585262 | `kJ` |\
| thermochemical British thermal unit | energy | Btuth | `[Btu_th]` | `[BTU_TH]` | no | 1.054350 | `kJ` |\
| British thermal unit | energy | btu | `[Btu]` | `[BTU]` | no | 1 | `[Btu_th]` |\
| horsepower | power |  | `[HP]` | `[HP]` | no | 550 | `[ft_i].[lbf_av]/s` |\
| tex | linear mass density (of textile thread) | tex | `tex` | `TEX` | yes | 1 | `g/km` |\
| Denier | linear mass density (of textile thread) | den | `[den]` | `[DEN]` | no | 1 | `g/9/km` |\
\
 Table\
 17: Other Units for Heat and Temperature\
\
\
The degree Fahrenheit was missing in ANSI X3.50. HL7's\
“ISO+/ANS+” code defined the degree Fahrenheit under the\
symbol “`DEGF`” which is reflected here. This\
is the reason why _The Unified Code for Units of Measure_ does not define a new symbol\
“`Fah`” similar to\
“`Cel`” of\
ISO 2955 for the degree Celsius.\
\
\
\
Defining precise semantics for legacy units for “quantity of\
heat” is difficult. The many variants of these units are\
frequently confused because there is not just a calorie and not just a\
British thermal unit. The different calories usually being used vary\
by 1% but the confusion can result in an error as high as 100000%!\
Thus, if exactness and non-ambiguity is important one should use the\
joule to report amounts of heat, just like for any other energy and\
work kind-of-quantities.\
\
\
\
The gram-calorie, sometimes called “small calorie” is\
defined as the amount of heat required to raise the temperature of 1\
gram of Water from 14.5 °C to 15.5 °C. According to\
_Encyclopedia Britannica_, this is the calorie most often used in\
engineering. There is also a less frequently used gram-calorie at\
19.5 °C to 20.5 °C and a mean calorie that is 1/100\
of the amount of heat required to raise the temperature from\
0 °C to 100 °C. The _International Table_\
calorie is defined by the _International Conference on the_\
_Properties of Steam_ (1956) and is used in steam engineering. In\
chemistry a “thermochemical” calorie is used for reaction\
enthalpies.\
\
\
\
To complete the confusion, there is also a kilogram-calorie (“large\
calorie” , that has a similar definition based on a kilogram\
instead of a gram of water. This kilocalorie has also been called\
“calorie” in the sloppy speech of everyday life about\
food. U.S. “Nutrition Facts” that label almost every\
American food say “Calories: xxx” The _International_\
_Union of Nutritional Sciences_ recommends using either the joule\
or a kilocalorie based on the thermochemical calorie. Because of a\
perceived popular demand _The Unified Code for Units of Measure_ defines the nutrition Calorie as\
“`Cal`” with the conventional capital first\
letter. For the case insensitive variant of _The Unified Code for Units of Measure_, the symbol is\
enclosed in square brackets (“`[CAL]`”).\
\
\
\
Only the International Table calorie and the thermochemical calorie\
have exact definitions. To give some guidance in the confusing plenty\
of different calories, _The Unified Code for Units of Measure_ defines a default symbol\
“`cal`” as an alias for the thermochemical\
calorie, because the calorie is mostly used today in medicine and\
biochemistry. On the other hand, we consider engineers smart enough to\
select the precise calorie they mean.\
\
\
\
Similar to the calories, various “British Thermal Unit”\
(Btu) are defined and the confusion continues. One Btu is defined as\
the amount of heat necessary to raise the temperature of one\
avoirdupois pound of water by one degree Fahrenheit beginning from\
various temperatures (39 °F, 59 °F, or\
60 °F). There is also the International Table Btu and the\
thermochemical Btu. Just as with the calorie we define a default\
symbol “`Btu`” as an alias for the\
thermochemical Btu.\
\
\
\
**§44 units used predominantly in**\
**clinical medicine** **■1**\
Units used mainly in clinical medicine are defined in [Table\\
18](https://ucum.org/ucum#clinical).\
**■2**\
The meaning of the columns is declared in [§34](https://ucum.org/ucum#para-34).\
**■3**\
The function pair denoted “`hpX(1 l)`” is\
defined as _f_ hp X( _x_) = \- lg _x_ to\
convert from a number fraction (dilution) per liter to the\
homeopathic potency value of the decimal (X) series, and _f_ hp\
X-1( _x_) = 10- _x_ to convert\
from the potency value back to the number fraction. Likewise, the\
function pair denoted “`hpC(1 l)`” is defined\
as _f_ hp C( _x_) = \- ln( _x_) / ln(100)\
to convert from a number fraction (dilution) per liter to the\
homeopathic potency value of the centesimal (C) series, and _f_ hp\
C-1( _x_) = 100- _x_ to convert\
from the potency value back to the number fraction. Analogous\
functions are defined for the millesimal (M) series with basis 1,000\
and the series and the quintamillesimal (Q) series with basis 50,000.\
**■4**\
The function pair denoted “`100tan(1 rad)`” is\
defined as _f_ PD( _α_) = tan( _α_) × 100 to\
convert from a plane angle _α_ to a prism diopter value (or a\
slope percent value) and\
_f_ PD-1( _x_) = arctan( _x / 100_) to\
convert from prism diopter (or slope percent) value _x_ back to a plane angle.\
\
\
\
| name | kind of quantity | print | c/s | c/i | M | definition value | definition unit |\
| meter of water column | pressure | m H2O | `m[H2O]` | `M[H2O]` | yes | 9.80665 | `kPa` |\
| meter of mercury column | pressure | m Hg | `m[Hg]` | `M[HG]` | yes | 133.3220 | `kPa` |\
| inch of water column | pressure | in H2O | `[in_i'H2O]` | `[IN_I'H2O]` | no | 1 | `m[H2O].[in_i]/m` |\
| inch of mercury column | pressure | in Hg | `[in_i'Hg]` | `[IN_I'HG]` | no | 1 | `m[Hg].[in_i]/m` |\
| peripheral vascular resistance unit | fluid resistance | P.R.U. | `[PRU]` | `[PRU]` | no | 1 | `mm[Hg].s/ml` |\
| Wood unit | fluid resistance | Wood U. | `[wood'U]` | `[WOOD'U]` | no | 1 | `mm[Hg].min/L` |\
| diopter | refraction of a lens | dpt | `[diop]` | `[DIOP]` | no | 1 | `/m` |\
| prism diopter | refraction of a prism | PD | `[p'diop]` | `[P'DIOP]` | no | • | `100tan(1 rad)` |\
| percent of slope | slope | % | `%[slope]` | `%[SLOPE]` | no | • | `100tan(1 rad)` |\
| mesh | lineic number |  | `[mesh_i]` | `[MESH_I]` | no | 1 | `/[in_i]` |\
| Charrière, french | gauge of catheters | Ch | `[Ch]` | `[CH]` | no | 1 | `mm/3` |\
| drop | volume | drp | `[drp]` | `[DRP]` | no | 1 | `ml/20` |\
| Hounsfield unit | x-ray attenuation | HF | `[hnsf'U]` | `[HNSF'U]` | no | 1 | `1` |\
| metabolic equivalent | metabolic cost of physical activity | MET | `[MET]` | `[MET]` | no | 3.5 | `mL/min/kg` |\
| homeopathic potency of decimal series (retired) | homeopathic potency (retired) | X | `[hp'_X]` | `[HP'_X]` | no | • | `hpX(1 1)` |\
| homeopathic potency of centesimal series (retired) | homeopathic potency (retired) | C | `[hp'_C]` | `[HP'_C]` | no | • | `hpC(1 1)` |\
| homeopathic potency of millesimal series (retired) | homeopathic potency (retired) | M | `[hp'_M]` | `[HP'_M]` | no | • | `hpM(1 1)` |\
| homeopathic potency of quintamillesimal series (retired) | homeopathic potency (retired) | Q | `[hp'_Q]` | `[HP'_Q]` | no | • | `hpQ(1 1)` |\
| homeopathic potency of decimal hahnemannian series | homeopathic potency (Hahnemann) | X | `[hp_X]` | `[HP_X]` | no | • | • |\
| homeopathic potency of centesimal hahnemannian series | homeopathic potency (Hahnemann) | C | `[hp_C]` | `[HP_C]` | no | • | • |\
| homeopathic potency of millesimal hahnemannian series | homeopathic potency (Hahnemann) | M | `[hp_M]` | `[HP_M]` | no | • | • |\
| homeopathic potency of quintamillesimal hahnemannian series | homeopathic potency (Hahnemann) | Q | `[hp_Q]` | `[HP_Q]` | no | • | • |\
| homeopathic potency of decimal korsakovian series | homeopathic potency (Korsakov) | X | `[kp_X]` | `[KP_X]` | no | • | • |\
| homeopathic potency of centesimal korsakovian series | homeopathic potency (Korsakov) | C | `[kp_C]` | `[KP_C]` | no | • | • |\
| homeopathic potency of millesimal korsakovian series | homeopathic potency (Korsakov) | M | `[kp_M]` | `[KP_M]` | no | • | • |\
| homeopathic potency of quintamillesimal korsakovian series | homeopathic potency (Korsakov) | Q | `[kp_Q]` | `[KP_Q]` | no | • | • |\
\
 Table\
 18: Units Used Predominantly in Clinical Medicine\
\
\
Clinical medicine all over the world still uses  mm Hg to\
measure arterial blood pressure, and often the instruments used are\
real mercury columns. Likewise, the central venous blood pressure is\
often measured using simple water columns which is very practical for\
the routine. The units  m H2O and  m Hg\
are metric units even though they are “not accepted” for\
use with the SI for quite a while. Although more and more hospitals in\
Europe switch to using the pascal to measure partial pressures in\
blood gas analysis, the older units will not vanish any time soon.\
\
\
\
In the U.S. the inch is sometimes used instead of the millimeter, and\
because the inch is non-metric the inch of mercury or water columns is\
non-metric as well.\
\
\
\
The peripheral vascular resistance unit is the vascular resistance on\
which a perfusion pressure of 1 mm Hg causes a flow of\
1 ml/s.\
\
\
\
The “mesh” occurs in the NIST Guide to the SI. It seems like it is\
the customary counterpart of the diopter.\
\
\
\
The unit “charrière” originates from a French manufacturer of\
medical instruments by that name. One charrière is the gauge of a\
catheter with a circumference of approximately 1 mm\
such that it is by convention exactly one third of a millimeter.\
In the U.S. the charrière is simply called “french”\
\
\
\
> **NOTE:**\
>  Note that _Unified Code for Units of Measure_ versions prior to 1.9 defined this unit as 1/π, this use,\
>  however this was never common use of the unit.\
>  This is why the definition has been corrected instead of adding another one.\
\
A drop is a variable amount of fluid and depends on the device and\
technique used to produce the drop and on the physical properties of\
the fluid. This is similar to units like cup, tablespoon, and teaspoon\
that depend on the spoon or cup and are not exact either. However, in\
clinical medicine medication is dispensed by drops and unlike a\
“tablet” a drop refers to a real physical kind of quantity, volume,\
though not very exact.\
\
\
\
> **NOTE:**\
>  Note that _Unified Code for Units of Measure_ versions prior to 1.9 defined this unit as mL/12, this use,\
>  however this was not common use of the unit.\
>  This is why the definition has been corrected instead of adding another one.\
>  Typically it is stated as mL/20.\
>  Original research using a 20 mL syringe filled to 5 mL shows that\
>  1 mL has 25 drops of water,\
>  when tensides are added, the number goes up to 45.\
>  A saturated saline solution required 30 and plant oil 35.\
>  The speed of dropping, pressure and position of the syringe or the lumen of the outlet,\
>  open or partially clogged with wax,\
>  did not have a significant influence on the number of drops.\
>  While the original research suggests that the division should be by 25 or more, we use the common notion.\
>  It is discouraged to use the drop as any standard unit.\
\
The Hounsfield unit is a unit of X-ray attenuation used in evaluating\
CT scans. It is defined on an interval scale where air is -1000 HF,\
water is 0 HF and bone is +1000 HF. Any advice as to how this unit can\
be related to metric units of radiant intensity decremence is\
appreciated.\
\
\
\
We have always pointed out that the homeopathic teaching takes potency\
not as equivalent to dilution and the C and X series would not equate\
to each other in the strictly numerical manner. Homeopathic potency\
includes the “agitation” (a vigorous shaking) that needs\
to occur in every step of the dilluting process. Therefore as of April 2010,\
the homeopathic units are declared "arbitrary units", that is, they\
are no longer convertible. Therefore, also, we discontinue defining them\
using the dilution functions. The dilution functions sometimes cause\
truly astronomical values, leading to overflow conditions, e.g. in\
such potencies as 30 C or 100 X or 10 M, which do actually occur in\
homeopathics that are on the market. The previous units continue to\
exist as "retired", but their symbols now have a prime (apostrophe) in\
them.\
\
\
\
**§45 chemical and biochemical units** **■1**\
Units used mainly in chemical and biochemical laboratories are defined\
in [Table\\
19](https://ucum.org/ucum#chemical).\
**■2**\
The meaning of the columns is declared in [§43](https://ucum.org/ucum#para-43).\
**■3**\
The function pair denoted “`ph(1 mol/l)`” is\
defined as _f_ pH( _x_) = \- lg _x_ to\
convert from moles per liter to the pH value, and\
_f_ pH-1( _x_) = 10- _x_\
to convert from the pH value back to moles per liter.\
\
\
\
| name | kind of quantity | print | c/s | c/i | M | definition value | definition unit |\
| equivalents | amount of substance | eq | `eq` | `EQ` | yes | 1 | `mol` |\
| osmole | amount of substance (dissolved particles) | osm | `osm` | `OSM` | yes | 1 | `mol` |\
| pH | acidity | pH | `[pH]` | `[PH]` | no | • | `pH(1 mol/l)` |\
| gram percent | mass concentration | g% | `g%` | `G%` | yes | 1 | `g/dl` |\
| Svedberg unit | sedimentation coefficient | S | `[S]` | `[S]` | no | 1 | `10*-13.s` |\
| high power field | view area in microscope | HPF | `[HPF]` | `[HPF]` | no | 1 | `1` |\
| low power field | view area in microscope | LPF | `[LPF]` | `[LPF]` | no | 100 | `1` |\
| katal | catalytic activity | kat | `kat` | `KAT` | yes | 1 | `mol/s` |\
| Unit | catalytic activity | U | `U` | `U` | yes | 1 | `umol/min` |\
| international unit | arbitrary | IU | `[iU]` | `[IU]` | yes | • | • |\
| international unit | arbitrary | i.U. | `[IU]` | `[IU]` | yes | • | • |\
| arbitrary unit | arbitrary | arb. U | `[arb'U]` | `[ARB'U]` | no | • | • |\
| United States Pharmacopeia unit | arbitrary | U.S.P. | `[USP'U]` | `[USP'U]` | no | • | • |\
| GPL unit | biologic activity of anticardiolipin IgG |  | `[GPL'U]` | `[GPL'U]` | no | • | • |\
| MPL unit | biologic activity of anticardiolipin IgM |  | `[MPL'U]` | `[MPL'U]` | no | • | • |\
| APL unit | biologic activity of anticardiolipin IgA |  | `[APL'U]` | `[APL'U]` | no | • | • |\
| Bethesda unit | biologic activity of factor VIII inhibitor |  | `[beth'U]` | `[BETH'U]` | no | • | • |\
| anti factor Xa unit | biologic activity of factor Xa inhibitor (heparin) |  | `[anti'Xa'U]` | `[ANTI'XA'U]` | no | • | • |\
| Todd unit | biologic activity antistreptolysin O |  | `[todd'U]` | `[TODD'U]` | no | • | • |\
| Dye unit | biologic activity of amylase |  | `[dye'U]` | `[DYE'U]` | no | • | • |\
| Somogyi unit | biologic activity of amylase |  | `[smgy'U]` | `[SMGY'U]` | no | • | • |\
| Bodansky unit | biologic activity of phosphatase |  | `[bdsk'U]` | `[BDSK'U]` | no | • | • |\
| King-Armstrong unit | biologic activity of phosphatase |  | `[ka'U]` | `[KA'U]` | no | • | • |\
| Kunkel unit | arbitrary biologic activity |  | `[knk'U]` | `[KNK'U]` | no | • | • |\
| Mac Lagan unit | arbitrary biologic activity |  | `[mclg'U]` | `[MCLG'U]` | no | • | • |\
| tuberculin unit | biologic activity of tuberculin |  | `[tb'U]` | `[TB'U]` | no | • | • |\
| 50% cell culture infectious dose | biologic activity (infectivity) of an infectious agent preparation | CCID50 | `[CCID_50]` | `[CCID_50]` | no | • | • |\
| 50% tissue culture infectious dose | biologic activity (infectivity) of an infectious agent preparation | TCID50 | `[TCID_50]` | `[TCID_50]` | no | • | • |\
| 50% embryo infectious dose | biologic activity (infectivity) of an infectious agent preparation | EID50 | `[EID_50]` | `[EID_50]` | no | • | • |\
| plaque forming units | amount of an infectious agent | PFU | `[PFU]` | `[PFU]` | no | • | • |\
| focus forming units | amount of an infectious agent | FFU | `[FFU]` | `[FFU]` | no | • | • |\
| colony forming units | amount of a proliferating organism | CFU | `[CFU]` | `[CFU]` | no | • | • |\
| index of reactivity | amount of an allergen calibrated through in-vivo testing using the Stallergenes® method | IR | `[IR]` | `[IR]` | no | • | • |\
| bioequivalent allergen unit | amount of an allergen calibrated through in-vivo testing based on the ID50EAL method of (intradermal<br> dilution for 50mm sum<br> of erythema diameters | BAU | `[BAU]` | `[BAU]` | no | • | • |\
| allergen unit | procedure defined amount of an allergen using some reference standard | AU | `[AU]` | `[AU]` | no | • | • |\
| allergen unit for Ambrosia artemisiifolia | procedure defined amount of the major allergen of ragweed | Amb a 1 U | `[Amb'a'1'U]` | `[AMB'A'1'U]` | no | • | • |\
| protein nitrogen unit | procedure defined amount of a protein substance | PNU | `[PNU]` | `[PNU]` | no | • | • |\
| Limit of flocculation | procedure defined amount of an antigen substance | Lf | `[Lf]` | `[LF]` | no | • | • |\
| D-antigen unit | procedure defined amount of a poliomyelitis d-antigen substance |  | `[D'ag'U]` | `[D'AG'U]` | no | • | • |\
| fibrinogen equivalent unit | amount of fibrinogen broken down into the measured d-dimers |  | `[FEU]` | `[FEU]` | no | • | • |\
| ELISA unit | arbitrary ELISA unit |  | `[ELU]` | `[ELU]` | no | • | • |\
| Ehrlich unit | Ehrlich unit |  | `[EU]` | `[EU]` | no | • | • |\
\
 Table\
 19: Units used in Chemical and Biomedical Laboratories\
\
\
The amount of electrolytes (including acids and bases) is often\
reported as _equivalents_ instead of amount of substance. This\
habit originates in the measuring technique of titration. _The Unified Code for Units of Measure_\
does not endorse using equivalents. We rather recommend to calculate\
the proper amount of substance after titration, so that\
1 eq of Na+ ions is 1 mol, but\
1 eq of Ca++ ions is\
0.5 mol. The problem with equivalents is that the measurement\
results are difficult to compare because their magnitude depends on\
the degree of ionization of the substance. That is to say, the meaning\
of equivalents depend not only on the substance, but also on the state\
that the substance is in. For example, in iron we have to distinguish\
Fe2+ from Fe3+, so that no one can be sure how much 1 eq\
of iron really is.\
\
\
\
Degrees of acidity are normally measured as “the pH value” that is\
the negative decadic logarithmus of the concentration of free protons\
(or hydronium ions) expressed in 1 mol/l. Usually the pH value\
is considered a dimensionless quantity. With the semantics of special\
units ( [§§21ff](https://ucum.org/ucum#para-21)). _The Unified Code for Units of Measure_ can link the\
pH value tighter to the system\
of proper units. Thus “`[pH]`” is defined as a unit symbol with\
the corresponding unit 1 mol/l. This allows conversions between\
pH and concentrations, and---because _The Unified Code for Units of Measure_ identifies the mole with\
the Avogadro number---can be converted to an absolute number of\
protons: for example, pH 7.4 converts instantly to 0.04 μmol/l\
and approximately 23975 protons per picoliter.\
\
\
\
The unit osmol as the amount of dissolved particles is to be used with\
caution because it interferes with “osmolar” which is the amount of\
dissolved particles per liter.\
\
\
\
The gram-percent (g%) is a metric unit that has the same origin as\
%vol. Originally it was a dimensionless quantity expressing a ratio of\
two masses and thus equal to 1/100 g/g. Because water is the most\
important solvent in biochemistry and 1 g of a solution in water\
has a volume of approximately 1 ml, the meaning of the unit\
1 g% drifted towards 1/100 g/ml and farther off to\
1 g/dl. That way, the unit 1 g% regained a proper dimension\
(mass concentration, _M_/ _L_ 3). Most\
often it is used as 1 mg% = 1 mg/dl but all other SI\
prefixes are possible.\
\
\
\
The Svedberg unit S is used to classify macromolecules (e.g.,\
ribosomes) in different phases of a centrifugate.\
\
\
\
The units “high power field” (HPF) and “low power field” (LPF) are\
used in microscopic analysis mostly of urine sediments. These units\
are used in semi-quantitative estimations of the abundance of things\
like crystals, bacteria or red and white blood cells. The number of\
the objects of interest is counted in one view field in the microscope\
with a 10 times (low) or 100 times (high) magnifying objective lens\
and then reported as the number per LPF or per HPF\
respectively. Obviously the number of objects seen depends on the way\
the slide is prepared: the amount of emulgate dropped, its initial\
dilution, and the way the drop is smeared. These preparations of the\
slides are usually carried out with great routine but little\
exactness, hence LPF and HPF can hardly relate to any exact and\
meaningful volume.\
\
\
\
The best we could do is to define LPF and HPF as areas of the viewed\
field. However, the area of the field varies with the kind of eyepiece\
used in the microscope. The so called “field number” of\
the eyepiece, i.e., the diameter of the view area is typically between\
18 mm and 25 mm which is divided by the magnification of the\
objective lense to yield the actual field diameter _d_. Because the\
area _A_ = π d2, the LPF can be anywhere\
between 2.5 mm^2 and 5 mm^2 and the HPF between\
0.025 mm^2 and 0.05 mm^2. Because of this inexactness, we\
define LPF and HPF as dimensionless quantities with magnitudes that\
reflect the ratio of the view areas, i.e. 100:1. This allows at least\
to convert between numbers per LPF and per HPF and vice versa.\
\
\
\
The unit “U” of enzymatic activity was defined in 1964 by\
the _International Union of Biochemistry_ as the catalytic\
activity that catalyzes the transformation of 1 μmol of the\
substrate per minute. This unit is defined so that normal biological\
enzyme activities are in the range of 1 U-100 U. This unit\
could not be adopted by the CGPM because it violates the style rules\
of the SI, i.e. “unit” is a very indistinctive word,\
“U” is a capital letter, and the definition is not\
coherent with the SI.\
\
\
\
An SI-coherent unit katal 1 kat = 1 mol/s, had been proposed\
for adoption into the SI over 30 years ago and was finally adopted by\
the CGPM in 1999. However, perhaps because the unit katal is 7 orders\
of magnitudes greater than normal catalytic activities, in practice\
the katal has not gained much in popularity over the unit\
“U”.\
\
\
\
In its 1999 decision to add the katal to the SI, the CGPM explicitly\
“recommends that when the katal is used, the measurand be\
specified by reference to the measurement procedure; the measurement\
procedure must identify the indicator reaction.” The general\
problem with catalytic activities is that these heavily depend not\
only on the substance but on many side-conditions, such as\
temperature, acidity of the solution, presence or absence of\
cofactors, inhibitors or activators, and the amount of substrate.\
Particularly a catalytic activity measured _in vitro_ says\
little about the activity _in vivo_. Hence the use of katal\
alone without specifying exactly the measurement method, is not\
sufficient to improve comparability of the measurement of catalytic\
substances.\
\
\
\
Because of the influence of the measurement method, results of\
biologic activity measurement cannot usually be converted. This is a\
particular problem with the many named arbitrary units that are still\
used. _The Unified Code for Units of Measure_ initially defined all arbitrary units as\
dimensionless. But since this leads to the false conclusion that all\
arbitrary units are the same, the _Unified Code for Units of Measure_ now accounts for arbitrary units\
using a special flag. When a unit is marked as arbitrary, it is\
isolated from all other units, and no result can be converted from\
and to that unit (See [§24](https://ucum.org/ucum#para-24)).\
\
\
\
The unit “TCID50” expresses the result of\
quantifying an infectious agent in tissue culture. It is a titer, expressing the\
highest dilution of the specimen which produces a cytopathic effect in\
50% of the cell cultures or wells inoculated.\
\
\[Sources: Clinical Microbiology Reviews, July 1998, Vol. 11(3), p. 533-554\]\
\
\
\
The unit “CCID50” expresses the result of\
quantifying an infectious agent in a cell culture. It is a titer, expressing the\
highest dilution of the specimen which produces a cytopathic effect in\
50% of the cell cultures or wells inoculated.\
\
\[Sources: Schmidt NJ. Cell culture procedures for diagnostic\
virology, p. 78-79. In Schmidt NJ, Emmons RW (ed.),\
_Diagnostic procedures for viral, rickettsial and chlamydial_\
_infections_, 5th ed. American Public Health Association, Inc.,\
Washington, D.C.\]\
\
\
\
The unit “PFU” measures viral infectivity in a sensitive assay in cell\
culture where the titer is determined by counting the number of\
visible plaques developed following viral infection of a sensitive\
cell culture and results recorded as PFU/ml.\
\
\
\
The unit “FFU” measures viral infectivity in a sensitive\
assay in cell culture, for example, using immunofocus or vital dyes\
technology. For example, the titer is determined by visualizing\
infected areas of a cell monolayer by probing with virus-specific\
antibodies and results are recorded as FFU/ml.\
\
\[Sources: _WHO expert committee on biological standardization (55th Edition)._ WHO Technical Report #932;\]\
\
\
\
The unit “BAU” measures amount of an allergen based on an in-vivo calibrated test using the Intradermal Dilution\
for 50mm\
sum of Erythema Diameters (ID50EAL) Method.\
\
\[Source: _Turkeltaub PC. Biological Standardization based on_\
_Quantitative Skin Testing - The 1D50 EAL Method. Arbeiten aus dem_\
_Paul-Ehrlich-Institut, dem Georg-Speyer-Haus und dem_\
_Ferdinand-Blum-Institut, Band 80 Gustav Fischer Verlag' Stuttgart, New_\
_York. 1987_\]\
\
\
\
EDITORIAL NOTE: This method needs to be further investigated to\
determine a quantitative model which relates that would relate 1 BAU\
with a standardized amount of substance of the standardized allergenic\
protein. The situation is not unlike the titer and is not worse than\
for many of the arbitrary units listed already. In a future revision a\
stronger formalized metrologic model will be added to this\
specification.\
\
\
\
The unit “AU” (for allergen unit) is for the amount of an\
allergen based some procedure defined and allergen specific reference\
standard. Note, do not confuse with astronomical unit, distinguish\
`[AU]` from `AU`\
\
The unit “IR” has been defined to measure the\
allergenicity of an allergen extract. The allergen extract contains\
100 IR/ml when, on a skin prick-test using a Stallerpoint®, it induces\
a wheal diameter of 7 mm in 30 patients sensitized to this allergen,\
(geometric mean). The cutaneous reactivity of these patients is\
simultaneously demonstrated by a positive skin prick-test to either 9\
% codeine phosphate or 10 mg/ml histamine. The IR unit of Stallergenes\
is not comparable to the units used by other allergen manufacturers.\
\
\
\
EDITORIAL NOTE: Should more manufacturer specific units come up in the\
future, we will include a manufacturer abbreviation in the unit symbol.\
\
\
\
The unit “Amb a 1 U” is an arbitrary unit for the\
amount of Amb a 1, a 38 kD glycoprotein that is the major allergen in\
short ragweed (Ambrosia artemisiifolia) pollen allergen extracts. The\
amount of Amb a 1 units are determined by an in-vitro comparison of a\
test short ragweed extract to a FDA CBER Amb a 1 reference standard.\
Amb a 1 is the up-to-date term for the short ragweed pollen allergen\
that was originally described as Antigen E. They are\
synonyms. Although Antigen E is no longer used in the scientific\
literature, its meaning is unambiguous. The manufacturers are still\
licensed to use Antigen E as the designation. Therefore, Amb a 1 U =\
AgE U. There is an empiric relationship between Amb a 1 U and BAU\
(350 Amb a 1 U/mL = 100,000 BAU/mL). It was based on studies done\
decades ago on 15 study subjects. FDA's CBER considered mandating a\
conversion to BAU/mL in the labeling of short ragweed pollen products,\
based on AgE content, but this was never implemented. CBER provides\
two US standard reagents to manufacturers for their determination of\
Amb a 1 content, a reference standard and a reference serum. The assay\
used is a radial immunodiffusion assay (RID). Solid references\
discussing the relationship between Antigen E U/mL/Amb a 1 U/mL and\
micrograms of Antigen E U/mL/Amb a 1/mL are being researched.\
\
\
\
EDITORIAL NOTE: The University of Texas' Structural Database of\
Allergenic Proteins (SDAP) contains close to 1000 allergens,\
isoallergens. Comparing the prospect of thousands of such special\
units for every allergen, one begins to appreciate even the\
metrologically complex BAU unit.\
\
\
\
The unit “PNU” is defined as follows: 1 PNU/ml is\
equivalent to 1 x 10-5 mg of nitrogen determined to be in the material\
precipitated from 1 ml of allergenic extract by phosphotungstic acid\
(micro-Kjeldahl method). Typically, 1 mg of protein nitrogen equals\
100,000 PNU. The unit “PNU” is an old protein unit\
unrelated to SI units. Several hundred products, from several\
manufacturers, are labeled in PNUs, and a switch to SI units for\
protein content is impractical.\
\
\
\
The unit “Lf” is called the “Limit of\
Flocculation” or “limes flocculationis”. It is based\
on an antigen-antibody precipitation reaction and used for the\
quantification of the antigenic content of tetanus and diphteria toxin\
and toxoid. The limes flocculationis is the smallest amount of antigen\
that when mixed with one unit (Ramon) of antitoxin (antibody),\
produces the most rapid floccules in the flocculation test. For a\
purified crystalline tetanus or diphteria toxin 1 Lf is equivalent to\
~ 2 μg of protein. For tetanus and diphtheria toxoids, antigenic\
purity is defined and controlled by Lf units per mg of protein\
nitrogen.\
\
\
\
Many sources describe the unit of antitoxin as "international unit"\
(IU), however, this is no longer correct. It was correct for the first\
international standard for antitoxin, established in 1920s. It had an\
arbitrary unit defined as IU for in vivo antitoxic activity and that\
unit was also used for establishing Lf units of toxins and toxoids,\
that is why this standard had a ratio of 1 between flocculating\
activity (Lf) and antitoxic activity (IU). When WHO replaced that\
standard in 1970s, the second international standard related to Lf by\
a factor of 1.4 instead of 1. Ultimately, WHO decided to move to the\
toxoid standards and calibrated tetanus toxoid for flocculation using\
Lf unit (not IU). With the implementation of WHO standards for\
flocculation as tetanus and diphtheria toxoids, antitoxin standards\
were discontinued by the WHO. \[Source: _Lyng J. Quantitative_\
_Estimation of Diphtheria and Tetanus Toxoids - 4 - Toxoids as_\
_International Reference Materials Defining Lf-units for Diphtheria and_\
_Tetanus Toxoids. Biologicals (1990) 18, 11-17._ Also on the\
definition of the IU for antitoxin: _Spaun J, Lyng J. Replacement_\
_of the International Standard for Tetanus Antitoxin and the Use of the_\
_Standard in the Flocculation Test. Bull. Wid Hith Org. 1970, 42,_\
_523-534._`http://www.ncbi.nlm.nih.gov/pmc/articles/PMC2427455` and\
personal communication with FDA CBER representatives.\]\
\
\
\
**§46 levels** **■1**\
Pseudo-units defined to express logarithms of ratios between two\
quantities of the same kind are defined in [Table\\
20](https://ucum.org/ucum#levels).\
**■2**\
The meaning of the columns is declared in [§43](https://ucum.org/ucum#para-43).\
**■3**\
The function pairs denoted “`ln`”\
“`lg`” and “`2lg`” are\
defined as the natural logarithm, the decadic logarithm, and the\
decadic logarithm times two with their respective inverse functions.\
\
\
\
| name | kind of quantity | print | c/s | c/i | M | definition value | definition unit |\
| neper | level | Np | `Np` | `NEP` | yes | • | `ln(1 1)` |\
| bel | level | B | `B` | `B` | yes | • | `lg(1 1)` |\
| bel sound pressure | pressure level | B(SPL) | `B[SPL]` | `B[SPL]` | yes | • | `2lg(2 10*-5.Pa)` |\
| bel volt | electric potential level | B(V) | `B[V]` | `B[V]` | yes | • | `2lg(1 V)` |\
| bel millivolt | electric potential level | B(mV) | `B[mV]` | `B[MV]` | yes | • | `2lg(1 mV)` |\
| bel microvolt | electric potential level | B(μV) | `B[uV]` | `B[UV]` | yes | • | `2lg(1 uV)` |\
| bel 10 nanovolt | electric potential level | B(10 nV) | `B[10.nV]` | `B[10.NV]` | yes | • | `2lg(10 nV)` |\
| bel watt | power level | B(W) | `B[W]` | `B[W]` | yes | • | `lg(1 W)` |\
| bel kilowatt | power level | B(kW) | `B[kW]` | `B[KW]` | yes | • | `lg(1 kW)` |\
\
 Table\
 20: Levels\
\
\
These units are “pseudo-units” because of their standardized\
definition as being logarithms of a ratio of two measurements with the\
same kind-of-quantity: first, the units cancel out, and second, the\
logarithm does not produce a new unit. These units were defined as\
“metric” because they are used as such, although a multiplication\
operation is not defined on these quantities. Multiplication of the\
measurement value with a scalar _r_ is equivalent to raising the\
original ratio to the _r_-th power.\
\
\
\
According to NIST, the neper is used as the ratio level of field\
quantities and the bel is used for the level of power quantities. The\
factor 2 comes into play when field quantities (like electric\
potential) are expressed in decibel. The specialized bel-units B(V),\
B(mV), B(W), etc. are defined as the level of the measured quantity\
with reference quantities 1 V, 1 mV, and 1 W\
respectively. \[NIST Sp. Pub. 811, 1995 Edition\]\
\
\
\
Given the sound pressure level expressed in dB(SPL) it is feasible to\
define dB(A) for the A scale of loudness. Similar units such as phon\
and sone could be defined as well if a good approximation for the\
respective characteristic functions are available. Any advice is\
welcome.\
\
\
\
**§47 miscellaneous units** **■1**\
Not otherwise classified units are defined in [Table\\
21](https://ucum.org/ucum#misc).\
**■2**\
The meaning of the columns is declared in [§30](https://ucum.org/ucum#para-30).2.\
**■3**\
Only the columns titled “c/s,” “c/i,”\
“M,” “value,” and “definition” are\
normative. Full name and print symbol are either not standardized or\
standardized by other bodies and are out of scope of _The Unified Code for Units of Measure_.\
**■4**\
The function pair denoted “`sqrt`” is defined as\
the square root with its respective inverse function, the square.\
\
\
\
| name | kind of quantity | print | c/s | c/i | M | definition value | definition unit |\
| stere | volume | st | `st` | `STR` | yes | 1 | `m3` |\
| Ångström | length | Å | `Ao` | `AO` | no | 0.1 | `nm` |\
| barn | action area | b | `b` | `BRN` | no | 100 | `fm2` |\
| technical atmosphere | pressure | at | `att` | `ATT` | no | 1 | `kgf/cm2` |\
| mho | electric conductance | mho | `mho` | `MHO` | yes | 1 | `S` |\
| pound per square inch | pressure | psi | `[psi]` | `[PSI]` | no | 1 | `[lbf_av]/[in_i]2` |\
| circle | plane angle | circ | `circ` | `CIRC` | no | 2 | `[pi].rad` |\
| sphere | solid angle | sph | `sph` | `SPH` | no | 4 | `[pi].sr` |\
| metric carat | mass | ctm | `[car_m]` | `[CAR_M]` | no | 0.2 | `g` |\
| carat of gold alloys | mass fraction | ctAu | `[car_Au]` | `[CAR_AU]` | no | 1 | `/24` |\
| Smoot | length |  | `[smoot]` | `[SMOOT]` | no | 67 | `[in_i]` |\
| meter per square seconds per square root of hertz | amplitude spectral density |  | `[m/s2/Hz^(1/2)]` | `[M/S2/HZ^(1/2)]` | no | • | `sqrt(1 m2/s4/Hz)` |\
| Nephelometric Turbidity Unit | turbidity |  | `[NTU]` | `[NTU]` | no | 1 | `1` |\
| Formazin Nephelometric Unit | turbidity |  | `[FNU]` | `[FNU]` | no | 1 | `1` |\
\
 Table\
 21: Miscellaneous Units\
\
\
Although called “metric carat,” the carat really is a\
customary unit, still used for precious gems. The word carat comes\
from Greek\
κερατίκον (small\
horn) that originally was the horn-shaped grain of a locust-tree\
species in the pea family, hence the carat grain is about three barley\
grain that the other English systems of weights are based on. The arab\
carat was 1/24 of an ounce, the Imperial carat (1877) was\
205.3 mg or 3.168 grain. In other European cities, the carat\
was 205.8 mg (Hamburg, Lisboa) but there were great variations\
from 188.5 mg (Bologna) to 213.5 mg (Torino). Due to these\
variations no customary carat has gained importance today aside from\
the “metric carat” defined as 200 mg exactly.\
\[ _All About Carats_ URL:\
`http://www.channel1.com/users/scales/carat-def.htm`\]\
\
\
\
The “Mark” was a mass unit for precious metals (Köln 234 g,\
Paris 245 g, Wien 277 g). A mark of gold was subdivided into\
24 “karat,” a mark of silver into 16 “lot.” This led to the other\
use of the unit “carat” to mean 1/24 in measuring the finesse of\
pure gold in an alloy. For example, an 8 carat gold alloy contains 8\
parts of gold on 16 parts of silver = 8/24 = 1/3, or 333 per\
mille. This carat is spelled “karat” in the U.S. while other\
countries do not use different spellings.\
\
\
\
The unit “`[m/s2/Hz^(1/2)]`” is defined as a special unit to represent the odd fractional exponent of\
the second obtaining for the unit of the amplitude\
spectral density (ASD). It is defined based on the unit for the power spectral density (PSD), that is 1\
(m/s2)2/Hz or 1 m2 · s-3. Since the two measurements are directly comparable, PSD\
= ASD2.\
\
\
\
**§48 units used in information**\
**technology** **■1**\
Units used in information technology are defined in table 22.\
**■2**\
The meaning of the columns is declared in [§43](https://ucum.org/ucum#para-43).\
**■3**\
The function pair denoted “`ld`” is defined as\
the dual logarithm with its respective inverse function\
_f_-1( _x_) = 2x).\
\
\
\
This table is not complete. There are other units such as shannon\
(Sh), erlang (E), or hartley (Hart), for which we had no quantitative\
definitions. Any advice is appreciated.\
\
\
\
The bit is defined twice. One definition with a subscript letter\
‘s‘ is defined as the logarithmus dualis of the number of\
distinct signals. However this unit can not practically be used to\
express more than 1000 bits. Especially when the bit is used to\
express transmission rate or memory capacities, floating point\
registers would quickly overflow. Therefore we define a second symbol\
for bit, without the suffix, to be the dimensionless unit 1.\
\
\
\
The baud (Bd) is the number of distinct signals transmitted per second,\
it is _not_ the same as bits per second since one distinct signal\
usually carries more than one bit of information.\
\
\
\
| name | kind of quantity | print | c/s | c/i | M | definition value | definition unit |\
| bit | amount of information | bits | `bit_s` | `BIT_S` | no | • | `ld(1 1)` |\
| bit | amount of information | bit | `bit` | `BIT` | yes | 1 | `1` |\
| byte | amount of information | B | `By` | `BY` | yes | 8 | `bit` |\
| baud | signal transmission rate | Bd | `Bd` | `BD` | yes | 1 | `/s` |\
\
 Table\
 22: Units used in Information Science and Technology\
\
\
**§49 prefixes** **■1**\
The prefix symbols based on powers of two for use in information\
technology as proposed by the IEEE are defined in [Table\\
23](https://ucum.org/ucum#infopfx).\
**■2**\
The meaning of the columns is declared in [§49](https://ucum.org/ucum#para-49).2.\
**■3**\
Only the columns titled “c/s,” “c/i,” and\
“value,” are normative. Full name and print symbol are out\
of scope of _The Unified Code for Units of Measure_.\
\
\
\
This table reflects proposed prefixes which are not yet standardized.\
\[Bruce Barrow, _A Lesson in Megabytes._ IEEE Standards\
Bearer, January 1997\]\
\
\
\
| name | print | c/s | c/i | value |\
| kibi | Ki | `Ki` | `KIB` | 1024 |\
| mebi | Mi | `Mi` | `MIB` | 1048576 |\
| gibi | Gi | `Gi` | `GIB` | 1073741824 |\
| tebi | Ti | `Ti` | `TIB` | 1099511627776 |\
\
 Table\
 23: The special prefix symbols for powers of 2\
\
\
* * *\
\
**§50 Non-units** **■1**\
Symbols commonly used as units that are no real units of measurements\
are not defined by _The Unified Code for Units of Measure_.\
**■2**\
Users are free to use curly braces expressions ( [§12](https://ucum.org/ucum#para-12)) if they think it is\
important to use symbols\
rather than the default unit **1**.\
**■3**\
Curly braces expressions are equivalent to the unit **1**. The\
details of the annotations in the curly braces have no defined meaning\
in _The Unified Code for Units of Measure_.\
**■4** [Table\\
24](https://ucum.org/ucum#junk) gives some example for those non-units but is not\
normative.\
\
\
\
| name | kind of quantity | print | c/s | c/i | M | definition value | definition unit |\
| particles total count | number | tot. | `{tot}` | `{TOT}` | no |  | `1` |\
| tablets | number | tbl. | `{tbl}` | `{TBL}` | no |  | `1` |\
| red blood cell count | number | R.B.C. | `{rbc}` | `{RBC}` | no |  | `1` |\
| gram meter per heartbeat | proportional to ventricular stroke work | g· m/H.B. | `g.m/{H.B.}` | `G.M/{H.B.}` | no |  | `g.m` |\
| gram-force meter per heartbeat | ventricular stroke work | gf· m/H.B. | `gf.m/{H.B.}` | `GF.M/{H.B.}` | no |  | `gf.m` |\
| kilogram of wet tissue | mass | kg(wet tissue) | `kg{wet'tis}` | `KG{wet'tis}` | no |  | `kg` |\
| milligram of creatinine | mass | mg(creat.) | `mg{creat}` | `MG{creat}` | no |  | `mg` |\
\
Table\
24: Examples for Non-Units\
\
\
Although customarily cardiac stroke work is notated as "g.m" this is not a true unit of work. Instead one\
should use gram-force\
meter.\
\
\
\
_The Unified Code for Units of Measure_ is designed and maintained so that severe name conflicts do\
not occur. However, avoiding all conflicts is possible only at the\
cost of defining very unusual symbols for those units. As the [Table\\
25](https://ucum.org/ucum#conflicts) shows, all current conflicts are of type IVa between\
metric and nonmetric units. This means that there is only a conflict\
if the metric predicate is violated so that non-metric units are used\
with a prefix.\
\
\[Schadow G, McDonald CJ et al: Units of Measure in\
Clinical Information Systems. _JAMIA_ 6(2); Mar/Apr\
1999\. p. 151-162.\]\
\
\
|     |     |     |\
| --- | --- | --- |\
| Gb | G-b | Type IVa (metric-nonmetric) |\
| Pa | P-a | Type IVa (metric-nonmetric) |\
| ph | p-h | Type IVa (metric-nonmetric) |\
| cd | c-d | Type IVa (metric-nonmetric) |\
| CD | C-D | Type IVa (metric-nonmetric) |\
\
Table\
25: Summary of name conflicts\
\
\
|     |     |     |\
| --- | --- | --- |\
| (retired), homeopathic potency of centesimal series – homeopathic potency<br> (retired) – \[hp'\_C\]: [§44](https://ucum.org/ucum#para-44)<br>(retired), homeopathic potency of<br> decimal series – homeopathic potency (retired) – \[hp'\_X\]: [§44](https://ucum.org/ucum#para-44)<br>(retired), homeopathic potency of millesimal series – homeopathic potency<br> (retired) – \[hp'\_M\]: [§44](https://ucum.org/ucum#para-44)<br>(retired), homeopathic potency of<br> quintamillesimal series – homeopathic potency (retired) – \[hp'\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>10 nanovolt, bel – electric potential level – B\[10.nV\]: [§46](https://ucum.org/ucum#para-46)<br>15 °C, calorie at – energy – cal\_\[15\]: [§43](https://ucum.org/ucum#para-43)<br>20 °C, calorie at – energy – cal\_\[20\]: [§43](https://ucum.org/ucum#para-43)<br>39 °F, British thermal unit at – energy – \[Btu\_39\]: [§43](https://ucum.org/ucum#para-43)<br>50% cell culture infectious dose – biologic activity (infectivity) of an<br> infectious agent preparation – \[CCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>50% embryo<br> infectious dose – biologic activity (infectivity) of an infectious agent preparation – \[EID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>50% tissue culture infectious dose – biologic activity<br> (infectivity) of an infectious agent preparation – \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>59 °F, British thermal unit at – energy – \[Btu\_59\]: [§43](https://ucum.org/ucum#para-43)<br>60 °F, British thermal unit at – energy – \[Btu\_60\]: [§43](https://ucum.org/ucum#para-43)<br>APL unit – biologic activity of anticardiolipin IgA – \[APL'U\]: [§45](https://ucum.org/ucum#para-45)<br>Ambrosia artemisiifolia, allergen unit for – procedure<br> defined amount of the major allergen of ragweed – \[Amb'a'1'U\]: [§45](https://ucum.org/ucum#para-45)<br>Bethesda unit – biologic activity of factor VIII inhibitor – \[beth'U\]: [§45](https://ucum.org/ucum#para-45)<br>Biot – electric current – Bi: [§33](https://ucum.org/ucum#para-33)<br>Bodansky unit – biologic activity of phosphatase – \[bdsk'U\]: [§45](https://ucum.org/ucum#para-45)<br>Boltzmann constant – (unclassified) – \[k\]: [§32](https://ucum.org/ucum#para-32)<br>British hundredweight – mass – \[lcwt\_av\]: [§39](https://ucum.org/ucum#para-39)<br>British stone – mass – \[stone\_av\]: [§39](https://ucum.org/ucum#para-39)<br>British thermal unit at 39 °F – energy – \[Btu\_39\]: [§43](https://ucum.org/ucum#para-43)<br>British thermal unit at 59 °F – energy – \[Btu\_59\]: [§43](https://ucum.org/ucum#para-43)<br>British thermal unit at 60 °F – energy – \[Btu\_60\]: [§43](https://ucum.org/ucum#para-43)<br>British thermal unit – energy – \[Btu\]: [§43](https://ucum.org/ucum#para-43)<br>British thermal unit, international table – energy – \[Btu\_IT\]: [§43](https://ucum.org/ucum#para-43)<br>British thermal unit, mean – energy – \[Btu\_m\]: [§43](https://ucum.org/ucum#para-43)<br>British thermal unit, thermochemical – energy – \[Btu\_th\]:<br> [§43](https://ucum.org/ucum#para-43)<br>British ton – mass – \[lton\_av\]: [§39](https://ucum.org/ucum#para-39)<br>Calories, nutrition label – energy – \[Cal\]: [§43](https://ucum.org/ucum#para-43)<br>Celsius, degree – temperature – Cel: [§30](https://ucum.org/ucum#para-30)<br>Charrière – gauge of catheters – \[Ch\]: [§44](https://ucum.org/ucum#para-44)<br>Curie – radioactivity – Ci: [§33](https://ucum.org/ucum#para-33)<br>D-antigen unit – procedure defined amount of a poliomyelitis d-antigen<br> substance – \[D'ag'U\]: [§45](https://ucum.org/ucum#para-45)<br>Denier – linear mass density (of<br> textile thread) – \[den\]: [§43](https://ucum.org/ucum#para-43)<br>Didot's pica – length – \[cicero\]:<br> [§42](https://ucum.org/ucum#para-42)<br>Didot's point – length – \[didot\]: [§42](https://ucum.org/ucum#para-42)<br>Dye unit – biologic activity of amylase – \[dye'U\]: [§45](https://ucum.org/ucum#para-45)<br>ELISA unit – arbitrary ELISA unit – \[ELU\]: [§45](https://ucum.org/ucum#para-45)<br>Ehrlich unit – Ehrlich unit – \[EU\]: [§45](https://ucum.org/ucum#para-45)<br>Engineer's chain – length – \[rch\_us\]: [§35](https://ucum.org/ucum#para-35)<br>Fahrenheit, degree – temperature – \[degF\]: [§43](https://ucum.org/ucum#para-43)<br>Formazin Nephelometric Unit – turbidity – \[FNU\]: [§47](https://ucum.org/ucum#para-47)<br>French foot – length – \[pied\]: [§42](https://ucum.org/ucum#para-42)<br>French inch – length – \[pouce\]: [§42](https://ucum.org/ucum#para-42)<br>French line – length – \[ligne\]: [§42](https://ucum.org/ucum#para-42)<br>GPL unit – biologic activity of anticardiolipin IgG – \[GPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>Gal – acceleration – Gal: [§33](https://ucum.org/ucum#para-33)<br>Gauss – magnetic flux density – G: [§33](https://ucum.org/ucum#para-33)<br>Gilbert – magnetic tension – Gb: [§33](https://ucum.org/ucum#para-33)<br>Gregorian month, mean – time – mo\_g: [§31](https://ucum.org/ucum#para-31)<br>Gregorian year, mean – time – a\_g: [§31](https://ucum.org/ucum#para-31)<br>Gunter's chain – length – \[ch\_br\]: [§36](https://ucum.org/ucum#para-36)<br>Gunter's chain – length – \[ch\_us\]: [§35](https://ucum.org/ucum#para-35)<br>Gunter's chain, link for – length – \[lk\_br\]: [§36](https://ucum.org/ucum#para-36)<br>Gunter's chain, link for – length – \[lk\_us\]: [§35](https://ucum.org/ucum#para-35)<br>Hounsfield unit – x-ray attenuation – \[hnsf'U\]: [§44](https://ucum.org/ucum#para-44)<br>Julian month, mean – time – mo\_j: [§31](https://ucum.org/ucum#para-31)<br>Julian year, mean – time – a\_j: [§31](https://ucum.org/ucum#para-31)<br>Kayser – lineic number – Ky: [§33](https://ucum.org/ucum#para-33)<br>King-Armstrong unit – biologic activity of phosphatase – \[ka'U\]: [§45](https://ucum.org/ucum#para-45)<br>Kunkel unit – arbitrary biologic activity – \[knk'U\]: [§45](https://ucum.org/ucum#para-45)<br>Lagan unit, Mac – arbitrary biologic activity – \[mclg'U\]:<br> [§45](https://ucum.org/ucum#para-45)<br>Lambert – brightness – Lmb: [§33](https://ucum.org/ucum#para-33)<br>Limit of flocculation – procedure defined amount of an antigen substance –<br> \[Lf\]: [§45](https://ucum.org/ucum#para-45)<br>MPL unit – biologic activity of anticardiolipin IgM –<br> \[MPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>Mac Lagan unit – arbitrary biologic activity –<br> \[mclg'U\]: [§45](https://ucum.org/ucum#para-45)<br>Maxwell – flux of magnetic induction – Mx: [§33](https://ucum.org/ucum#para-33)<br>Nephelometric Turbidity Unit – turbidity – \[NTU\]: [§47](https://ucum.org/ucum#para-47)<br>Nephelometric Unit, Formazin – turbidity – \[FNU\]: [§47](https://ucum.org/ucum#para-47)<br>Newtonian constant of gravitation – (unclassified) – \[G\]:<br> [§32](https://ucum.org/ucum#para-32)<br>Oersted – magnetic field intensity – Oe: [§33](https://ucum.org/ucum#para-33)<br>Pharmacopeia unit, United States – arbitrary – \[USP'U\]: [§45](https://ucum.org/ucum#para-45)<br>Planck constant – action – \[h\]: [§32](https://ucum.org/ucum#para-32)<br>Poise – dynamic viscosity – P: [§33](https://ucum.org/ucum#para-33)<br>Printer's pica – length – \[pca\_pr\]: [§42](https://ucum.org/ucum#para-42)<br>Printer's point – length – \[pnt\_pr\]: [§42](https://ucum.org/ucum#para-42)<br>Queen Anne's wine gallon – fluid volume – \[gal\_us\]: [§37](https://ucum.org/ucum#para-37)<br>Ramden's chain – length – \[rch\_us\]: [§35](https://ucum.org/ucum#para-35)<br>Ramden's chain, link for – length – \[rlk\_us\]: [§35](https://ucum.org/ucum#para-35)<br>Rankine, degree – temperature – \[degR\]: [§43](https://ucum.org/ucum#para-43)<br>Roentgen – ion dose – R: [§33](https://ucum.org/ucum#para-33)<br>Réaumur, degree – temperature – \[degRe\]: [§43](https://ucum.org/ucum#para-43)<br>Smoot – length – \[smoot\]: [§47](https://ucum.org/ucum#para-47)<br>Somogyi unit – biologic activity of amylase – \[smgy'U\]: [§45](https://ucum.org/ucum#para-45)<br>States Pharmacopeia unit, United – arbitrary – \[USP'U\]: [§45](https://ucum.org/ucum#para-45)<br>Stokes – kinematic viscosity – St: [§33](https://ucum.org/ucum#para-33)<br>Surveyor's chain – length – \[ch\_us\]: [§35](https://ucum.org/ucum#para-35)<br>Svedberg unit – sedimentation coefficient – \[S\]: [§45](https://ucum.org/ucum#para-45)<br>Todd unit – biologic activity antistreptolysin O – \[todd'U\]: [§45](https://ucum.org/ucum#para-45)<br>Turbidity Unit, Nephelometric – turbidity – \[NTU\]: [§47](https://ucum.org/ucum#para-47)<br>U.S. hundredweight – mass – \[scwt\_av\]: [§39](https://ucum.org/ucum#para-39)<br>U.S. ton – mass – \[ston\_av\]: [§39](https://ucum.org/ucum#para-39)<br>Unit – catalytic activity – U: [§45](https://ucum.org/ucum#para-45)<br>Unit, Formazin Nephelometric – turbidity – \[FNU\]: [§47](https://ucum.org/ucum#para-47)<br>Unit, Nephelometric Turbidity – turbidity – \[NTU\]: [§47](https://ucum.org/ucum#para-47)<br>United States Pharmacopeia unit – arbitrary – \[USP'U\]: [§45](https://ucum.org/ucum#para-45)<br>Wood unit – fluid resistance – \[wood'U\]: [§44](https://ucum.org/ucum#para-44)<br>Xa unit, anti factor – biologic activity of factor Xa inhibitor (heparin) –<br> \[anti'Xa'U\]: [§45](https://ucum.org/ucum#para-45)<br>absorbed dose, radiation – energy dose – RAD:<br> [§33](https://ucum.org/ucum#para-33)<br>acceleration of free fall, standard – acceleration – \[g\]:<br> [§32](https://ucum.org/ucum#para-32)<br>acre – area – \[acr\_br\]: [§36](https://ucum.org/ucum#para-36)<br>acre – area – \[acr\_us\]: [§35](https://ucum.org/ucum#para-35)<br>allergen unit for Ambrosia artemisiifolia – procedure defined amount of the<br> major allergen of ragweed – \[Amb'a'1'U\]: [§45](https://ucum.org/ucum#para-45)<br>allergen unit –<br> procedure defined amount of an allergen using some reference standard – \[AU\]: [§45](https://ucum.org/ucum#para-45)<br>allergen unit, bioequivalent – amount of an allergen calibrated through<br> in-vivo testing based on the ID50EAL method of (intradermal<br> dilution for 50mm sum of erythema diameters – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>alloys, carat of gold – mass fraction – \[car\_Au\]: [§47](https://ucum.org/ucum#para-47)<br>ampère – electric current – A: [§30](https://ucum.org/ucum#para-30)<br>anti factor Xa unit – biologic activity of factor Xa inhibitor (heparin) –<br> \[anti'Xa'U\]: [§45](https://ucum.org/ucum#para-45)<br>arbitrary powers, the number ten for – number<br> – 10\*: [§29](https://ucum.org/ucum#para-29)<br>arbitrary powers, the number ten for – number – 10^:<br> [§29](https://ucum.org/ucum#para-29)<br>arbitrary unit – arbitrary – \[arb'U\]: [§45](https://ucum.org/ucum#para-45)<br>are – area – ar: [§31](https://ucum.org/ucum#para-31)<br>artemisiifolia, allergen unit for Ambrosia – procedure defined amount of<br> the major allergen of ragweed – \[Amb'a'1'U\]: [§45](https://ucum.org/ucum#para-45)<br>astronomic<br> unit – length – AU: [§31](https://ucum.org/ucum#para-31)<br>atmosphere, standard – pressure – atm:<br> [§32](https://ucum.org/ucum#para-32)<br>atmosphere, technical – pressure – att: [§47](https://ucum.org/ucum#para-47)<br>atomic mass unit, unified – mass – u: [§31](https://ucum.org/ucum#para-31)<br>atto – prefix – a: [§27](https://ucum.org/ucum#para-27)<br>bar –<br> pressure – bar: [§31](https://ucum.org/ucum#para-31)<br>barn – action area – b: [§47](https://ucum.org/ucum#para-47)<br>barrel – fluid volume – \[bbl\_us\]: [§37](https://ucum.org/ucum#para-37)<br>baud – signal transmission rate – Bd: [§48](https://ucum.org/ucum#para-48)<br>becquerel – radioactivity – Bq: [§30](https://ucum.org/ucum#para-30)<br>bel 10 nanovolt – electric potential level – B\[10.nV\]: [§46](https://ucum.org/ucum#para-46)<br>bel kilowatt – power level – B\[kW\]: [§46](https://ucum.org/ucum#para-46)<br>bel microvolt – electric potential level – B\[uV\]: [§46](https://ucum.org/ucum#para-46)<br>bel millivolt – electric potential level – B\[mV\]: [§46](https://ucum.org/ucum#para-46)<br>bel sound pressure – pressure level – B\[SPL\]: [§46](https://ucum.org/ucum#para-46)<br>bel volt – electric potential level – B\[V\]: [§46](https://ucum.org/ucum#para-46)<br>bel watt – power level – B\[W\]: [§46](https://ucum.org/ucum#para-46)<br>bel – level – B: [§46](https://ucum.org/ucum#para-46)<br>billion,<br> parts per – fraction – \[ppb\]: [§29](https://ucum.org/ucum#para-29)<br>bioequivalent allergen unit –<br> amount of an allergen calibrated through in-vivo testing based on the ID50EAL method of (intradermal<br> dilution for 50mm sum of erythema diameters – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>bit –<br> amount of information – bit: [§48](https://ucum.org/ucum#para-48)<br>bit – amount of information –<br> bit\_s: [§48](https://ucum.org/ucum#para-48)<br>blood cell count, red – number – {rbc}: [§50](https://ucum.org/ucum#para-50)<br>board foot – volume – \[bf\_i\]: [§34](https://ucum.org/ucum#para-34)<br>bushel – dry volume – \[bu\_us\]: [§37](https://ucum.org/ucum#para-37)<br>bushel – volume – \[bu\_br\]: [§38](https://ucum.org/ucum#para-38)<br>byte – amount of information – By: [§48](https://ucum.org/ucum#para-48)<br>calorie at 15 °C – energy – cal\_\[15\]: [§43](https://ucum.org/ucum#para-43)<br>calorie at 20 °C – energy – cal\_\[20\]: [§43](https://ucum.org/ucum#para-43)<br>calorie – energy – cal: [§43](https://ucum.org/ucum#para-43)<br>calorie, international table – energy – cal\_IT: [§43](https://ucum.org/ucum#para-43)<br>calorie, mean – energy – cal\_m: [§43](https://ucum.org/ucum#para-43)<br>calorie, thermochemical – energy – cal\_th: [§43](https://ucum.org/ucum#para-43)<br>candela – luminous intensity – cd: [§28](https://ucum.org/ucum#para-28)<br>carat of gold alloys – mass fraction – \[car\_Au\]: [§47](https://ucum.org/ucum#para-47)<br>carat, metric – mass – \[car\_m\]: [§47](https://ucum.org/ucum#para-47)<br>cell count, red blood – number – {rbc}: [§50](https://ucum.org/ucum#para-50)<br>cell culture infectious dose, 50% – biologic activity (infectivity) of an<br> infectious agent preparation – \[CCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>centesimal<br> hahnemannian series, homeopathic potency of – homeopathic potency (Hahnemann) – \[hp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>centesimal korsakovian series, homeopathic potency of –<br> homeopathic potency (Korsakov) – \[kp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>centesimal series<br> (retired), homeopathic potency of – homeopathic potency (retired) – \[hp'\_C\]: [§44](https://ucum.org/ucum#para-44)<br>centi – prefix – c: [§27](https://ucum.org/ucum#para-27)<br>chain,<br> Engineer's – length – \[rch\_us\]: [§35](https://ucum.org/ucum#para-35)<br>chain, Gunter's – length –<br> \[ch\_br\]: [§36](https://ucum.org/ucum#para-36)<br>chain, Gunter's – length – \[ch\_us\]: [§35](https://ucum.org/ucum#para-35)<br>chain, Ramden's – length – \[rch\_us\]: [§35](https://ucum.org/ucum#para-35)<br>chain, Surveyor's – length – \[ch\_us\]: [§35](https://ucum.org/ucum#para-35)<br>chain, link for Gunter's – length – \[lk\_br\]: [§36](https://ucum.org/ucum#para-36)<br>chain, link for Gunter's – length – \[lk\_us\]: [§35](https://ucum.org/ucum#para-35)<br>chain, link for Ramden's – length – \[rlk\_us\]: [§35](https://ucum.org/ucum#para-35)<br>charge, elementary – electric charge – \[e\]: [§32](https://ucum.org/ucum#para-32)<br>cicero – length – \[cicero\]: [§42](https://ucum.org/ucum#para-42)<br>circle – plane angle – circ: [§47](https://ucum.org/ucum#para-47)<br>circular mil – area – \[cml\_i\]: [§34](https://ucum.org/ucum#para-34)<br>colony forming units – amount of a proliferating organism – \[CFU\]: [§45](https://ucum.org/ucum#para-45)<br>column, inch of mercury – pressure – \[in\_i'Hg\]: [§44](https://ucum.org/ucum#para-44)<br>column, inch of water – pressure – \[in\_i'H2O\]: [§44](https://ucum.org/ucum#para-44)<br>column, meter of mercury – pressure – m\[Hg\]: [§44](https://ucum.org/ucum#para-44)<br>column, meter of water – pressure – m\[H2O\]: [§44](https://ucum.org/ucum#para-44)<br>constant of gravitation, Newtonian – (unclassified) – \[G\]:<br> [§32](https://ucum.org/ucum#para-32)<br>constant, Boltzmann – (unclassified) – \[k\]: [§32](https://ucum.org/ucum#para-32)<br>constant, Planck – action – \[h\]: [§32](https://ucum.org/ucum#para-32)<br>cord – fluid volume – \[crd\_us\]: [§37](https://ucum.org/ucum#para-37)<br>cord – volume – \[cr\_i\]: [§34](https://ucum.org/ucum#para-34)<br>coulomb – electric charge – C: [§28](https://ucum.org/ucum#para-28)<br>count, particles total – number – {tot}: [§50](https://ucum.org/ucum#para-50)<br>count, red blood cell – number – {rbc}: [§50](https://ucum.org/ucum#para-50)<br>creatinine, milligram of – mass – mg{creat}: [§50](https://ucum.org/ucum#para-50)<br>cubic foot – volume – \[cft\_i\]: [§34](https://ucum.org/ucum#para-34)<br>cubic inch – volume – \[cin\_i\]: [§34](https://ucum.org/ucum#para-34)<br>cubic yard – volume – \[cyd\_i\]: [§34](https://ucum.org/ucum#para-34)<br>culture infectious dose, 50% cell – biologic activity (infectivity) of an<br> infectious agent preparation – \[CCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>culture<br> infectious dose, 50% tissue – biologic activity (infectivity) of an infectious agent preparation –<br> \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>cup – volume – \[cup\_us\]: [§37](https://ucum.org/ucum#para-37)<br>cup, metric – volume – \[cup\_m\]: [§37](https://ucum.org/ucum#para-37)<br>day – time – d: [§31](https://ucum.org/ucum#para-31)<br>deci – prefix<br> – d: [§27](https://ucum.org/ucum#para-27)<br>decimal hahnemannian series, homeopathic potency of –<br> homeopathic potency (Hahnemann) – \[hp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>decimal<br> korsakovian series, homeopathic potency of – homeopathic potency (Korsakov) – \[kp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>decimal series (retired), homeopathic potency of – homeopathic potency<br> (retired) – \[hp'\_X\]: [§44](https://ucum.org/ucum#para-44)<br>degree Celsius – temperature – Cel: [§30](https://ucum.org/ucum#para-30)<br>degree Fahrenheit – temperature – \[degF\]: [§43](https://ucum.org/ucum#para-43)<br>degree Rankine – temperature – \[degR\]: [§43](https://ucum.org/ucum#para-43)<br>degree Réaumur – temperature – \[degRe\]: [§43](https://ucum.org/ucum#para-43)<br>degree – plane angle – deg: [§31](https://ucum.org/ucum#para-31)<br>deka – prefix – da: [§27](https://ucum.org/ucum#para-27)<br>didot –<br> length – \[didot\]: [§42](https://ucum.org/ucum#para-42)<br>diopter – refraction of a lens – \[diop\]:<br> [§44](https://ucum.org/ucum#para-44)<br>diopter, prism – refraction of a prism – \[p'diop\]: [§44](https://ucum.org/ucum#para-44)<br>dose, 50% cell culture infectious – biologic activity<br> (infectivity) of an infectious agent preparation – \[CCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>dose, 50% embryo infectious – biologic activity (infectivity) of an<br> infectious agent preparation – \[EID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>dose, 50% tissue<br> culture infectious – biologic activity (infectivity) of an infectious agent preparation – \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>dose, radiation absorbed – energy dose – RAD: [§33](https://ucum.org/ucum#para-33)<br>drachm – mass – \[dr\_ap\]: [§41](https://ucum.org/ucum#para-41)<br>dram – mass – \[dr\_ap\]: [§41](https://ucum.org/ucum#para-41)<br>dram –<br> mass – \[dr\_av\]: [§39](https://ucum.org/ucum#para-39)<br>dram, fluid – fluid volume – \[fdr\_us\]: [§37](https://ucum.org/ucum#para-37)<br>dram, fluid – volume – \[fdr\_br\]: [§38](https://ucum.org/ucum#para-38)<br>drop – volume – \[drp\]: [§44](https://ucum.org/ucum#para-44)<br>dry<br> pint – dry volume – \[dpt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>dry quart – dry volume –<br> \[dqt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>dyne – force – dyn: [§33](https://ucum.org/ucum#para-33)<br>electron mass – mass – \[m\_e\]: [§32](https://ucum.org/ucum#para-32)<br>electronvolt – energy – eV: [§31](https://ucum.org/ucum#para-31)<br>elementary charge – electric charge – \[e\]: [§32](https://ucum.org/ucum#para-32)<br>embryo infectious dose, 50% – biologic activity (infectivity) of an<br> infectious agent preparation – \[EID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>equivalent man,<br> radiation – dose equivalent – REM: [§33](https://ucum.org/ucum#para-33)<br>equivalent unit,<br> fibrinogen – amount of fibrinogen broken down into the measured d-dimers – \[FEU\]: [§45](https://ucum.org/ucum#para-45)<br>equivalent, metabolic – metabolic cost of physical activity – \[MET\]: [§44](https://ucum.org/ucum#para-44)<br>equivalents – amount of substance – eq: [§45](https://ucum.org/ucum#para-45)<br>erg – energy – erg: [§33](https://ucum.org/ucum#para-33)<br>exa –<br> prefix – E: [§27](https://ucum.org/ucum#para-27)<br>factor Xa unit, anti – biologic activity of<br> factor Xa inhibitor (heparin) – \[anti'Xa'U\]: [§45](https://ucum.org/ucum#para-45)<br>fall, standard<br> acceleration of free – acceleration – \[g\]: [§32](https://ucum.org/ucum#para-32)<br>farad – electric<br> capacitance – F: [§30](https://ucum.org/ucum#para-30)<br>fathom – depth of water – \[fth\_i\]: [§34](https://ucum.org/ucum#para-34)<br>fathom – length – \[fth\_br\]: [§36](https://ucum.org/ucum#para-36)<br>fathom – length – \[fth\_us\]: [§35](https://ucum.org/ucum#para-35)<br>femto – prefix – f: [§27](https://ucum.org/ucum#para-27)<br>fibrinogen equivalent unit – amount of fibrinogen broken down into the<br> measured d-dimers – \[FEU\]: [§45](https://ucum.org/ucum#para-45)<br>field, high power – view area in<br> microscope – \[HPF\]: [§45](https://ucum.org/ucum#para-45)<br>field, low power – view area in<br> microscope – \[LPF\]: [§45](https://ucum.org/ucum#para-45)<br>flocculation, Limit of – procedure<br> defined amount of an antigen substance – \[Lf\]: [§45](https://ucum.org/ucum#para-45)<br>fluid dram –<br> fluid volume – \[fdr\_us\]: [§37](https://ucum.org/ucum#para-37)<br>fluid dram – volume – \[fdr\_br\]: [§38](https://ucum.org/ucum#para-38)<br>fluid ounce – fluid volume – \[foz\_us\]: [§37](https://ucum.org/ucum#para-37)<br>fluid ounce – volume – \[foz\_br\]: [§38](https://ucum.org/ucum#para-38)<br>fluid ounce, metric – fluid volume – \[foz\_m\]: [§37](https://ucum.org/ucum#para-37)<br>focus forming units – amount of an infectious agent – \[FFU\]: [§45](https://ucum.org/ucum#para-45)<br>foot – length – \[ft\_br\]: [§36](https://ucum.org/ucum#para-36)<br>foot – length – \[ft\_i\]: [§34](https://ucum.org/ucum#para-34)<br>foot<br> – length – \[ft\_us\]: [§35](https://ucum.org/ucum#para-35)<br>foot, French – length – \[pied\]: [§42](https://ucum.org/ucum#para-42)<br>foot, board – volume – \[bf\_i\]: [§34](https://ucum.org/ucum#para-34)<br>foot, cubic – volume – \[cft\_i\]: [§34](https://ucum.org/ucum#para-34)<br>foot, square – area – \[sft\_i\]: [§34](https://ucum.org/ucum#para-34)<br>force, pound – force – \[lbf\_av\]: [§32](https://ucum.org/ucum#para-32)<br>forming units, colony – amount of a proliferating organism – \[CFU\]: [§45](https://ucum.org/ucum#para-45)<br>forming units, focus – amount of an infectious agent –<br> \[FFU\]: [§45](https://ucum.org/ucum#para-45)<br>forming units, plaque – amount of an infectious<br> agent – \[PFU\]: [§45](https://ucum.org/ucum#para-45)<br>free fall, standard acceleration of –<br> acceleration – \[g\]: [§32](https://ucum.org/ucum#para-32)<br>french – gauge of catheters – \[Ch\]: [§44](https://ucum.org/ucum#para-44)<br>furlong – length – \[fur\_us\]: [§35](https://ucum.org/ucum#para-35)<br>gallon – volume – \[gal\_br\]: [§38](https://ucum.org/ucum#para-38)<br>gallon, Queen Anne's wine – fluid volume – \[gal\_us\]: [§37](https://ucum.org/ucum#para-37)<br>gallon, historical winchester – dry volume – \[gal\_wi\]: [§37](https://ucum.org/ucum#para-37)<br>gibi – prefix – Gi: [§49](https://ucum.org/ucum#para-49)<br>giga – prefix – G: [§27](https://ucum.org/ucum#para-27)<br>gill –<br> fluid volume – \[gil\_us\]: [§37](https://ucum.org/ucum#para-37)<br>gill – volume – \[gil\_br\]: [§38](https://ucum.org/ucum#para-38)<br>gold alloys, carat of – mass fraction – \[car\_Au\]: [§47](https://ucum.org/ucum#para-47)<br>gon – plane angle – gon: [§31](https://ucum.org/ucum#para-31)<br>grade – plane angle – gon: [§31](https://ucum.org/ucum#para-31)<br>grain – mass – \[gr\]: [§39](https://ucum.org/ucum#para-39)<br>gram<br> meter per heartbeat – proportional to ventricular stroke work – g.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>gram percent – mass concentration – g%: [§45](https://ucum.org/ucum#para-45)<br>gram – mass – g: [§28](https://ucum.org/ucum#para-28)<br>gram-force<br> meter per heartbeat – ventricular stroke work – gf.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>gram-force – force – gf: [§32](https://ucum.org/ucum#para-32)<br>gravitation, Newtonian constant of – (unclassified) – \[G\]: [§32](https://ucum.org/ucum#para-32)<br>gray – energy dose – Gy: [§30](https://ucum.org/ucum#para-30)<br>hahnemannian series, homeopathic potency of centesimal – homeopathic<br> potency (Hahnemann) – \[hp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>hahnemannian series,<br> homeopathic potency of decimal – homeopathic potency (Hahnemann) – \[hp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>hahnemannian series, homeopathic potency of millesimal – homeopathic<br> potency (Hahnemann) – \[hp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>hahnemannian series,<br> homeopathic potency of quintamillesimal – homeopathic potency (Hahnemann) – \[hp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>hand – height of horses – \[hd\_i\]: [§34](https://ucum.org/ucum#para-34)<br>heartbeat, gram meter per – proportional to ventricular stroke work –<br> g.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>heartbeat, gram-force meter per – ventricular<br> stroke work – gf.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>hecto – prefix – h: [§27](https://ucum.org/ucum#para-27)<br>henry – inductance – H: [§30](https://ucum.org/ucum#para-30)<br>hertz – frequency – Hz: [§30](https://ucum.org/ucum#para-30)<br>hertz, meter per square seconds per square root of – amplitude spectral<br> density – \[m/s2/Hz^(1/2)\]: [§47](https://ucum.org/ucum#para-47)<br>high power field – view area in<br> microscope – \[HPF\]: [§45](https://ucum.org/ucum#para-45)<br>historical winchester gallon – dry<br> volume – \[gal\_wi\]: [§37](https://ucum.org/ucum#para-37)<br>homeopathic potency of centesimal<br> hahnemannian series – homeopathic potency (Hahnemann) – \[hp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency of centesimal korsakovian series – homeopathic potency<br> (Korsakov) – \[kp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency of centesimal<br> series (retired) – homeopathic potency (retired) – \[hp'\_C\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency of decimal hahnemannian series – homeopathic potency<br> (Hahnemann) – \[hp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency of decimal<br> korsakovian series – homeopathic potency (Korsakov) – \[kp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency of decimal series (retired) – homeopathic potency<br> (retired) – \[hp'\_X\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency of millesimal<br> hahnemannian series – homeopathic potency (Hahnemann) – \[hp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency of millesimal korsakovian series – homeopathic potency<br> (Korsakov) – \[kp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency of millesimal<br> series (retired) – homeopathic potency (retired) – \[hp'\_M\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency of quintamillesimal hahnemannian series – homeopathic<br> potency (Hahnemann) – \[hp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency of<br> quintamillesimal korsakovian series – homeopathic potency (Korsakov) – \[kp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency of quintamillesimal series (retired) – homeopathic<br> potency (retired) – \[hp'\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>horsepower – power – \[HP\]: [§43](https://ucum.org/ucum#para-43)<br>hour – time – h: [§31](https://ucum.org/ucum#para-31)<br>hundredweight, British – mass – \[lcwt\_av\]: [§39](https://ucum.org/ucum#para-39)<br>hundredweight, U.S. – mass – \[scwt\_av\]: [§39](https://ucum.org/ucum#para-39)<br>hundredweight, long – mass – \[lcwt\_av\]: [§39](https://ucum.org/ucum#para-39)<br>hundredweight, short – mass – \[scwt\_av\]: [§39](https://ucum.org/ucum#para-39)<br>inch of mercury column – pressure – \[in\_i'Hg\]: [§44](https://ucum.org/ucum#para-44)<br>inch of water column – pressure – \[in\_i'H2O\]: [§44](https://ucum.org/ucum#para-44)<br>inch – length – \[in\_br\]: [§36](https://ucum.org/ucum#para-36)<br>inch<br> – length – \[in\_i\]: [§34](https://ucum.org/ucum#para-34)<br>inch – length – \[in\_us\]: [§35](https://ucum.org/ucum#para-35)<br>inch, French – length – \[pouce\]: [§42](https://ucum.org/ucum#para-42)<br>inch, cubic – volume – \[cin\_i\]: [§34](https://ucum.org/ucum#para-34)<br>inch, pound per square – pressure – \[psi\]: [§47](https://ucum.org/ucum#para-47)<br>inch, square – area – \[sin\_i\]: [§34](https://ucum.org/ucum#para-34)<br>index of reactivity – amount of an allergen calibrated through in-vivo<br> testing using the Stallergenes® method – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>infectious<br> dose, 50% cell culture – biologic activity (infectivity) of an infectious agent preparation – \[CCID\_50\]:<br> [§45](https://ucum.org/ucum#para-45)<br>infectious dose, 50% embryo – biologic activity<br> (infectivity) of an infectious agent preparation – \[EID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>infectious dose, 50% tissue culture – biologic activity (infectivity) of an<br> infectious agent preparation – \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>international<br> table British thermal unit – energy – \[Btu\_IT\]: [§43](https://ucum.org/ucum#para-43)<br>international table calorie – energy – cal\_IT: [§43](https://ucum.org/ucum#para-43)<br>international unit – arbitrary – \[IU\]: [§45](https://ucum.org/ucum#para-45)<br>international unit – arbitrary – \[iU\]: [§45](https://ucum.org/ucum#para-45)<br>joule – energy – J: [§30](https://ucum.org/ucum#para-30)<br>katal –<br> catalytic activity – kat: [§45](https://ucum.org/ucum#para-45)<br>kelvin – temperature – K: [§28](https://ucum.org/ucum#para-28)<br>kibi – prefix – Ki: [§49](https://ucum.org/ucum#para-49)<br>kilo – prefix – k: [§27](https://ucum.org/ucum#para-27)<br>kilogram<br> of wet tissue – mass – kg{wet'tis}: [§50](https://ucum.org/ucum#para-50)<br>kilowatt, bel – power<br> level – B\[kW\]: [§46](https://ucum.org/ucum#para-46) |  | knot – velocity – \[kn\_br\]: [§36](https://ucum.org/ucum#para-36)<br>knot<br> – velocity – \[kn\_i\]: [§34](https://ucum.org/ucum#para-34)<br>korsakovian series, homeopathic<br> potency of centesimal – homeopathic potency (Korsakov) – \[kp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>korsakovian series, homeopathic potency of decimal – homeopathic potency<br> (Korsakov) – \[kp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>korsakovian series, homeopathic<br> potency of millesimal – homeopathic potency (Korsakov) – \[kp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>korsakovian series, homeopathic potency of quintamillesimal – homeopathic<br> potency (Korsakov) – \[kp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>label Calories, nutrition –<br> energy – \[Cal\]: [§43](https://ucum.org/ucum#para-43)<br>light, velocity of – velocity – \[c\]: [§32](https://ucum.org/ucum#para-32)<br>light-year – length – \[ly\]: [§32](https://ucum.org/ucum#para-32)<br>ligne – length – \[ligne\]: [§42](https://ucum.org/ucum#para-42)<br>line – length – \[lne\]: [§42](https://ucum.org/ucum#para-42)<br>line,<br> French – length – \[ligne\]: [§42](https://ucum.org/ucum#para-42)<br>link for Gunter's chain – length<br> – \[lk\_br\]: [§36](https://ucum.org/ucum#para-36)<br>link for Gunter's chain – length – \[lk\_us\]: [§35](https://ucum.org/ucum#para-35)<br>link for Ramden's chain – length – \[rlk\_us\]: [§35](https://ucum.org/ucum#para-35)<br>liter – volume – L: [§31](https://ucum.org/ucum#para-31)<br>liter – volume – l: [§31](https://ucum.org/ucum#para-31)<br>long<br> hundredweight – mass – \[lcwt\_av\]: [§39](https://ucum.org/ucum#para-39)<br>long ton – mass –<br> \[lton\_av\]: [§39](https://ucum.org/ucum#para-39)<br>low power field – view area in microscope –<br> \[LPF\]: [§45](https://ucum.org/ucum#para-45)<br>lumen – luminous flux – lm: [§30](https://ucum.org/ucum#para-30)<br>lux – illuminance – lx: [§30](https://ucum.org/ucum#para-30)<br>man,<br> radiation equivalent – dose equivalent – REM: [§33](https://ucum.org/ucum#para-33)<br>mass unit,<br> unified atomic – mass – u: [§31](https://ucum.org/ucum#para-31)<br>mass, electron – mass – \[m\_e\]:<br> [§32](https://ucum.org/ucum#para-32)<br>mass, proton – mass – \[m\_p\]: [§32](https://ucum.org/ucum#para-32)<br>mean British thermal unit – energy – \[Btu\_m\]: [§43](https://ucum.org/ucum#para-43)<br>mean Gregorian month – time – mo\_g: [§31](https://ucum.org/ucum#para-31)<br>mean Gregorian year – time – a\_g: [§31](https://ucum.org/ucum#para-31)<br>mean Julian month – time – mo\_j: [§31](https://ucum.org/ucum#para-31)<br>mean Julian year – time – a\_j: [§31](https://ucum.org/ucum#para-31)<br>mean calorie – energy – cal\_m: [§43](https://ucum.org/ucum#para-43)<br>mebi – prefix – Mi: [§49](https://ucum.org/ucum#para-49)<br>mega –<br> prefix – M: [§27](https://ucum.org/ucum#para-27)<br>mercury column, inch of – pressure – \[in\_i'Hg\]:<br> [§44](https://ucum.org/ucum#para-44)<br>mercury column, meter of – pressure – m\[Hg\]: [§44](https://ucum.org/ucum#para-44)<br>mesh – lineic number – \[mesh\_i\]: [§44](https://ucum.org/ucum#para-44)<br>metabolic equivalent – metabolic cost of physical activity – \[MET\]: [§44](https://ucum.org/ucum#para-44)<br>meter of mercury column – pressure – m\[Hg\]: [§44](https://ucum.org/ucum#para-44)<br>meter of water column – pressure – m\[H2O\]: [§44](https://ucum.org/ucum#para-44)<br>meter per heartbeat, gram – proportional to ventricular<br> stroke work – g.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>meter per heartbeat, gram-force –<br> ventricular stroke work – gf.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>meter per square<br> seconds per square root of hertz – amplitude spectral density – \[m/s2/Hz^(1/2)\]: [§47](https://ucum.org/ucum#para-47)<br>meter – length – m: [§28](https://ucum.org/ucum#para-28)<br>metric<br> carat – mass – \[car\_m\]: [§47](https://ucum.org/ucum#para-47)<br>metric cup – volume – \[cup\_m\]: [§37](https://ucum.org/ucum#para-37)<br>metric fluid ounce – fluid volume – \[foz\_m\]: [§37](https://ucum.org/ucum#para-37)<br>metric ounce – mass – \[oz\_m\]: [§41](https://ucum.org/ucum#para-41)<br>metric tablespoon – volume – \[tbs\_m\]: [§37](https://ucum.org/ucum#para-37)<br>metric teaspoon – volume – \[tsp\_m\]: [§37](https://ucum.org/ucum#para-37)<br>mho – electric conductance – mho: [§47](https://ucum.org/ucum#para-47)<br>micro – prefix – u: [§27](https://ucum.org/ucum#para-27)<br>microvolt, bel – electric potential level – B\[uV\]: [§46](https://ucum.org/ucum#para-46)<br>mil – length – \[mil\_i\]: [§34](https://ucum.org/ucum#para-34)<br>mil –<br> length – \[mil\_us\]: [§35](https://ucum.org/ucum#para-35)<br>mil, circular – area – \[cml\_i\]: [§34](https://ucum.org/ucum#para-34)<br>mile – length – \[mi\_br\]: [§36](https://ucum.org/ucum#para-36)<br>mile – length – \[mi\_i\]: [§34](https://ucum.org/ucum#para-34)<br>mile<br> – length – \[mi\_us\]: [§35](https://ucum.org/ucum#para-35)<br>mile, nautical – length – \[nmi\_br\]: [§36](https://ucum.org/ucum#para-36)<br>mile, nautical – length – \[nmi\_i\]: [§34](https://ucum.org/ucum#para-34)<br>mile, square – area – \[smi\_us\]: [§35](https://ucum.org/ucum#para-35)<br>millesimal hahnemannian series, homeopathic potency of – homeopathic<br> potency (Hahnemann) – \[hp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>millesimal korsakovian<br> series, homeopathic potency of – homeopathic potency (Korsakov) – \[kp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>millesimal series (retired), homeopathic potency of – homeopathic potency<br> (retired) – \[hp'\_M\]: [§44](https://ucum.org/ucum#para-44)<br>milli – prefix – m: [§27](https://ucum.org/ucum#para-27)<br>milligram of creatinine – mass – mg{creat}: [§50](https://ucum.org/ucum#para-50)<br>million, parts per – fraction – \[ppm\]: [§29](https://ucum.org/ucum#para-29)<br>millivolt, bel – electric potential level – B\[mV\]: [§46](https://ucum.org/ucum#para-46)<br>minim – fluid volume – \[min\_us\]: [§37](https://ucum.org/ucum#para-37)<br>minim – volume – \[min\_br\]: [§38](https://ucum.org/ucum#para-38)<br>minute – plane angle – ': [§31](https://ucum.org/ucum#para-31)<br>minute – time – min: [§31](https://ucum.org/ucum#para-31)<br>mole –<br> amount of substance – mol: [§30](https://ucum.org/ucum#para-30)<br>month – time – mo: [§31](https://ucum.org/ucum#para-31)<br>month, mean Gregorian – time – mo\_g: [§31](https://ucum.org/ucum#para-31)<br>month, mean Julian – time – mo\_j: [§31](https://ucum.org/ucum#para-31)<br>month, synodal – time – mo\_s: [§31](https://ucum.org/ucum#para-31)<br>nano – prefix – n: [§27](https://ucum.org/ucum#para-27)<br>nanovolt,<br> bel 10 – electric potential level – B\[10.nV\]: [§46](https://ucum.org/ucum#para-46)<br>nautical mile<br> – length – \[nmi\_br\]: [§36](https://ucum.org/ucum#para-36)<br>nautical mile – length – \[nmi\_i\]: [§34](https://ucum.org/ucum#para-34)<br>neper – level – Np: [§46](https://ucum.org/ucum#para-46)<br>newton – force – N: [§30](https://ucum.org/ucum#para-30)<br>nitrogen<br> unit, protein – procedure defined amount of a protein substance – \[PNU\]: [§45](https://ucum.org/ucum#para-45)<br>number pi, the – number – \[pi\]: [§29](https://ucum.org/ucum#para-29)<br>number ten for arbitrary powers, the – number – 10\*: [§29](https://ucum.org/ucum#para-29)<br>number ten for arbitrary powers, the – number – 10^: [§29](https://ucum.org/ucum#para-29)<br>nutrition label Calories – energy – \[Cal\]: [§43](https://ucum.org/ucum#para-43)<br>ohm – electric resistance – Ohm: [§30](https://ucum.org/ucum#para-30)<br>osmole – amount of substance (dissolved particles) – osm: [§45](https://ucum.org/ucum#para-45)<br>ounce – mass – \[oz\_ap\]: [§41](https://ucum.org/ucum#para-41)<br>ounce – mass – \[oz\_av\]: [§39](https://ucum.org/ucum#para-39)<br>ounce<br> – mass – \[oz\_tr\]: [§40](https://ucum.org/ucum#para-40)<br>ounce, fluid – fluid volume – \[foz\_us\]:<br> [§37](https://ucum.org/ucum#para-37)<br>ounce, fluid – volume – \[foz\_br\]: [§38](https://ucum.org/ucum#para-38)<br>ounce, metric fluid – fluid volume – \[foz\_m\]: [§37](https://ucum.org/ucum#para-37)<br>ounce, metric – mass – \[oz\_m\]: [§41](https://ucum.org/ucum#para-41)<br>pH – acidity – \[pH\]: [§45](https://ucum.org/ucum#para-45)<br>pace –<br> length – \[pc\_br\]: [§36](https://ucum.org/ucum#para-36)<br>parsec – length – pc: [§31](https://ucum.org/ucum#para-31)<br>particles total count – number – {tot}: [§50](https://ucum.org/ucum#para-50)<br>parts per billion – fraction – \[ppb\]: [§29](https://ucum.org/ucum#para-29)<br>parts per million – fraction – \[ppm\]: [§29](https://ucum.org/ucum#para-29)<br>parts per thousand – fraction – \[ppth\]: [§29](https://ucum.org/ucum#para-29)<br>parts per trillion – fraction – \[pptr\]: [§29](https://ucum.org/ucum#para-29)<br>pascal – pressure – Pa: [§30](https://ucum.org/ucum#para-30)<br>peck<br> – dry volume – \[pk\_us\]: [§37](https://ucum.org/ucum#para-37)<br>peck – volume – \[pk\_br\]: [§38](https://ucum.org/ucum#para-38)<br>pennyweight – mass – \[pwt\_tr\]: [§40](https://ucum.org/ucum#para-40)<br>per billion, parts – fraction – \[ppb\]: [§29](https://ucum.org/ucum#para-29)<br>per heartbeat, gram meter – proportional to ventricular stroke work –<br> g.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>per heartbeat, gram-force meter – ventricular<br> stroke work – gf.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>per million, parts – fraction –<br> \[ppm\]: [§29](https://ucum.org/ucum#para-29)<br>per square inch, pound – pressure – \[psi\]: [§47](https://ucum.org/ucum#para-47)<br>per square root of hertz, meter per square seconds –<br> amplitude spectral density – \[m/s2/Hz^(1/2)\]: [§47](https://ucum.org/ucum#para-47)<br>per square<br> seconds per square root of hertz, meter – amplitude spectral density – \[m/s2/Hz^(1/2)\]: [§47](https://ucum.org/ucum#para-47)<br>per thousand, parts – fraction – \[ppth\]: [§29](https://ucum.org/ucum#para-29)<br>per trillion, parts – fraction – \[pptr\]: [§29](https://ucum.org/ucum#para-29)<br>percent of slope – slope – %\[slope\]: [§44](https://ucum.org/ucum#para-44)<br>percent – fraction – %: [§29](https://ucum.org/ucum#para-29)<br>percent, gram – mass concentration – g%: [§45](https://ucum.org/ucum#para-45)<br>peripheral vascular resistance unit – fluid resistance – \[PRU\]: [§44](https://ucum.org/ucum#para-44)<br>permeability of vacuum – magnetic permeability – \[mu\_0\]: [§32](https://ucum.org/ucum#para-32)<br>permittivity of vacuum – electric permittivity – \[eps\_0\]:<br> [§32](https://ucum.org/ucum#para-32)<br>peta – prefix – P: [§27](https://ucum.org/ucum#para-27)<br>phot – illuminance – ph: [§33](https://ucum.org/ucum#para-33)<br>pi,<br> the number – number – \[pi\]: [§29](https://ucum.org/ucum#para-29)<br>pica – length – \[pca\]: [§42](https://ucum.org/ucum#para-42)<br>pica, Didot's – length – \[cicero\]: [§42](https://ucum.org/ucum#para-42)<br>pica, Printer's – length – \[pca\_pr\]: [§42](https://ucum.org/ucum#para-42)<br>pico – prefix – p: [§27](https://ucum.org/ucum#para-27)<br>pied –<br> length – \[pied\]: [§42](https://ucum.org/ucum#para-42)<br>pint – fluid volume – \[pt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>pint – volume – \[pt\_br\]: [§38](https://ucum.org/ucum#para-38)<br>pint, dry – dry volume – \[dpt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>plaque forming units – amount of an infectious agent – \[PFU\]: [§45](https://ucum.org/ucum#para-45)<br>point – length – \[pnt\]: [§42](https://ucum.org/ucum#para-42)<br>point, Didot's – length – \[didot\]: [§42](https://ucum.org/ucum#para-42)<br>point, Printer's – length – \[pnt\_pr\]: [§42](https://ucum.org/ucum#para-42)<br>potency of centesimal hahnemannian series, homeopathic – homeopathic<br> potency (Hahnemann) – \[hp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>potency of centesimal<br> korsakovian series, homeopathic – homeopathic potency (Korsakov) – \[kp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>potency of centesimal series (retired), homeopathic – homeopathic potency<br> (retired) – \[hp'\_C\]: [§44](https://ucum.org/ucum#para-44)<br>potency of decimal hahnemannian<br> series, homeopathic – homeopathic potency (Hahnemann) – \[hp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>potency of decimal korsakovian series, homeopathic – homeopathic potency<br> (Korsakov) – \[kp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>potency of decimal series (retired),<br> homeopathic – homeopathic potency (retired) – \[hp'\_X\]: [§44](https://ucum.org/ucum#para-44)<br>potency of millesimal hahnemannian series, homeopathic – homeopathic<br> potency (Hahnemann) – \[hp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>potency of millesimal<br> korsakovian series, homeopathic – homeopathic potency (Korsakov) – \[kp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>potency of millesimal series (retired), homeopathic – homeopathic potency<br> (retired) – \[hp'\_M\]: [§44](https://ucum.org/ucum#para-44)<br>potency of quintamillesimal<br> hahnemannian series, homeopathic – homeopathic potency (Hahnemann) – \[hp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>potency of quintamillesimal korsakovian series, homeopathic – homeopathic<br> potency (Korsakov) – \[kp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>potency of quintamillesimal<br> series (retired), homeopathic – homeopathic potency (retired) – \[hp'\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>pouce – length – \[pouce\]: [§42](https://ucum.org/ucum#para-42)<br>pound force – force – \[lbf\_av\]: [§32](https://ucum.org/ucum#para-32)<br>pound per square inch – pressure – \[psi\]: [§47](https://ucum.org/ucum#para-47)<br>pound – mass – \[lb\_ap\]: [§41](https://ucum.org/ucum#para-41)<br>pound<br> – mass – \[lb\_av\]: [§39](https://ucum.org/ucum#para-39)<br>pound – mass – \[lb\_tr\]: [§40](https://ucum.org/ucum#para-40)<br>power field, high – view area in microscope – \[HPF\]: [§45](https://ucum.org/ucum#para-45)<br>power field, low – view area in microscope – \[LPF\]: [§45](https://ucum.org/ucum#para-45)<br>powers, the number ten for arbitrary – number – 10\*: [§29](https://ucum.org/ucum#para-29)<br>powers, the number ten for arbitrary – number – 10^: [§29](https://ucum.org/ucum#para-29)<br>pressure, bel sound – pressure level – B\[SPL\]: [§46](https://ucum.org/ucum#para-46)<br>prism diopter – refraction of a prism – \[p'diop\]: [§44](https://ucum.org/ucum#para-44)<br>protein nitrogen unit – procedure defined amount of a<br> protein substance – \[PNU\]: [§45](https://ucum.org/ucum#para-45)<br>proton mass – mass – \[m\_p\]: [§32](https://ucum.org/ucum#para-32)<br>quart – fluid volume – \[qt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>quart – volume – \[qt\_br\]: [§38](https://ucum.org/ucum#para-38)<br>quart, dry – dry volume – \[dqt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>quintamillesimal hahnemannian series, homeopathic potency of – homeopathic<br> potency (Hahnemann) – \[hp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>quintamillesimal korsakovian<br> series, homeopathic potency of – homeopathic potency (Korsakov) – \[kp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>quintamillesimal series (retired), homeopathic potency of – homeopathic<br> potency (retired) – \[hp'\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>radian – plane angle – rad: [§28](https://ucum.org/ucum#para-28)<br>radiation absorbed dose – energy dose – RAD: [§33](https://ucum.org/ucum#para-33)<br>radiation equivalent man – dose equivalent – REM: [§33](https://ucum.org/ucum#para-33)<br>reactivity, index of – amount of an allergen calibrated<br> through in-vivo testing using the Stallergenes® method – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>red blood cell count – number – {rbc}: [§50](https://ucum.org/ucum#para-50)<br>resistance unit, peripheral vascular – fluid resistance – \[PRU\]: [§44](https://ucum.org/ucum#para-44)<br>rod – length – \[rd\_br\]: [§36](https://ucum.org/ucum#para-36)<br>rod – length – \[rd\_us\]: [§35](https://ucum.org/ucum#para-35)<br>rod,<br> square – area – \[srd\_us\]: [§35](https://ucum.org/ucum#para-35)<br>root of hertz, meter per square<br> seconds per square – amplitude spectral density – \[m/s2/Hz^(1/2)\]: [§47](https://ucum.org/ucum#para-47)<br>scruple – mass – \[sc\_ap\]: [§41](https://ucum.org/ucum#para-41)<br>second – plane angle – '': [§31](https://ucum.org/ucum#para-31)<br>second – time – s: [§28](https://ucum.org/ucum#para-28)<br>seconds<br> per square root of hertz, meter per square – amplitude spectral density – \[m/s2/Hz^(1/2)\]: [§47](https://ucum.org/ucum#para-47)<br>section – area – \[sct\]: [§35](https://ucum.org/ucum#para-35)<br>series (retired), homeopathic potency of centesimal – homeopathic potency<br> (retired) – \[hp'\_C\]: [§44](https://ucum.org/ucum#para-44)<br>series (retired), homeopathic potency<br> of decimal – homeopathic potency (retired) – \[hp'\_X\]: [§44](https://ucum.org/ucum#para-44)<br>series (retired), homeopathic potency of millesimal – homeopathic potency<br> (retired) – \[hp'\_M\]: [§44](https://ucum.org/ucum#para-44)<br>series (retired), homeopathic potency<br> of quintamillesimal – homeopathic potency (retired) – \[hp'\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>series, homeopathic potency of centesimal hahnemannian – homeopathic<br> potency (Hahnemann) – \[hp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>series, homeopathic potency<br> of centesimal korsakovian – homeopathic potency (Korsakov) – \[kp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>series, homeopathic potency of decimal hahnemannian – homeopathic potency<br> (Hahnemann) – \[hp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>series, homeopathic potency of<br> decimal korsakovian – homeopathic potency (Korsakov) – \[kp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>series, homeopathic potency of millesimal hahnemannian – homeopathic<br> potency (Hahnemann) – \[hp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>series, homeopathic potency<br> of millesimal korsakovian – homeopathic potency (Korsakov) – \[kp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>series, homeopathic potency of quintamillesimal hahnemannian – homeopathic<br> potency (Hahnemann) – \[hp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>series, homeopathic potency<br> of quintamillesimal korsakovian – homeopathic potency (Korsakov) – \[kp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>short hundredweight – mass – \[scwt\_av\]: [§39](https://ucum.org/ucum#para-39)<br>short ton – mass – \[ston\_av\]: [§39](https://ucum.org/ucum#para-39)<br>siemens – electric conductance – S: [§30](https://ucum.org/ucum#para-30)<br>sievert – dose equivalent – Sv: [§30](https://ucum.org/ucum#para-30)<br>slope, percent of – slope – %\[slope\]: [§44](https://ucum.org/ucum#para-44)<br>sound pressure, bel – pressure level – B\[SPL\]: [§46](https://ucum.org/ucum#para-46)<br>sphere – solid angle – sph: [§47](https://ucum.org/ucum#para-47)<br>square foot – area – \[sft\_i\]: [§34](https://ucum.org/ucum#para-34)<br>square inch – area – \[sin\_i\]: [§34](https://ucum.org/ucum#para-34)<br>square inch, pound per – pressure – \[psi\]: [§47](https://ucum.org/ucum#para-47)<br>square mile – area – \[smi\_us\]: [§35](https://ucum.org/ucum#para-35)<br>square rod – area – \[srd\_us\]: [§35](https://ucum.org/ucum#para-35)<br>square root of hertz, meter per square seconds per – amplitude spectral<br> density – \[m/s2/Hz^(1/2)\]: [§47](https://ucum.org/ucum#para-47)<br>square seconds per square root<br> of hertz, meter per – amplitude spectral density – \[m/s2/Hz^(1/2)\]: [§47](https://ucum.org/ucum#para-47)<br>square yard – area – \[syd\_i\]: [§34](https://ucum.org/ucum#para-34)<br>standard acceleration of free fall – acceleration – \[g\]: [§32](https://ucum.org/ucum#para-32)<br>standard atmosphere – pressure – atm: [§32](https://ucum.org/ucum#para-32)<br>steradian – solid angle – sr: [§30](https://ucum.org/ucum#para-30)<br>stere – volume – st: [§47](https://ucum.org/ucum#para-47)<br>stilb –<br> lum. intensity density – sb: [§33](https://ucum.org/ucum#para-33)<br>stone – mass – \[stone\_av\]: [§39](https://ucum.org/ucum#para-39)<br>stone, British – mass – \[stone\_av\]: [§39](https://ucum.org/ucum#para-39)<br>synodal month – time – mo\_s: [§31](https://ucum.org/ucum#para-31)<br>table British thermal unit, international – energy – \[Btu\_IT\]: [§43](https://ucum.org/ucum#para-43)<br>table calorie, international – energy – cal\_IT: [§43](https://ucum.org/ucum#para-43)<br>tablespoon – volume – \[tbs\_us\]: [§37](https://ucum.org/ucum#para-37)<br>tablespoon, metric – volume – \[tbs\_m\]: [§37](https://ucum.org/ucum#para-37)<br>tablets – number – {tbl}: [§50](https://ucum.org/ucum#para-50)<br>teaspoon – volume – \[tsp\_us\]: [§37](https://ucum.org/ucum#para-37)<br>teaspoon, metric – volume – \[tsp\_m\]: [§37](https://ucum.org/ucum#para-37)<br>tebi – prefix – Ti: [§49](https://ucum.org/ucum#para-49)<br>technical<br> atmosphere – pressure – att: [§47](https://ucum.org/ucum#para-47)<br>ten for arbitrary powers, the<br> number – number – 10\*: [§29](https://ucum.org/ucum#para-29)<br>ten for arbitrary powers, the number<br> – number – 10^: [§29](https://ucum.org/ucum#para-29)<br>tera – prefix – T: [§27](https://ucum.org/ucum#para-27)<br>tesla – magnetic flux density – T: [§30](https://ucum.org/ucum#para-30)<br>tex – linear mass density (of textile thread) – tex: [§43](https://ucum.org/ucum#para-43)<br>thermal unit at 39 °F, British – energy – \[Btu\_39\]: [§43](https://ucum.org/ucum#para-43)<br>thermal unit at 59 °F, British – energy – \[Btu\_59\]: [§43](https://ucum.org/ucum#para-43)<br>thermal unit at 60 °F, British – energy – \[Btu\_60\]: [§43](https://ucum.org/ucum#para-43)<br>thermal unit, British – energy – \[Btu\]: [§43](https://ucum.org/ucum#para-43)<br>thermal unit, international table British – energy – \[Btu\_IT\]: [§43](https://ucum.org/ucum#para-43)<br>thermal unit, mean British – energy – \[Btu\_m\]: [§43](https://ucum.org/ucum#para-43)<br>thermal unit, thermochemical British – energy – \[Btu\_th\]:<br> [§43](https://ucum.org/ucum#para-43)<br>thermochemical British thermal unit – energy – \[Btu\_th\]: [§43](https://ucum.org/ucum#para-43)<br>thermochemical calorie – energy – cal\_th: [§43](https://ucum.org/ucum#para-43)<br>thousand, parts per – fraction – \[ppth\]: [§29](https://ucum.org/ucum#para-29)<br>tissue culture infectious dose, 50% – biologic activity (infectivity) of an<br> infectious agent preparation – \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>tissue, kilogram<br> of wet – mass – kg{wet'tis}: [§50](https://ucum.org/ucum#para-50)<br>ton, British – mass –<br> \[lton\_av\]: [§39](https://ucum.org/ucum#para-39)<br>ton, U.S. – mass – \[ston\_av\]: [§39](https://ucum.org/ucum#para-39)<br>ton, long – mass – \[lton\_av\]: [§39](https://ucum.org/ucum#para-39)<br>ton, short – mass – \[ston\_av\]: [§39](https://ucum.org/ucum#para-39)<br>tonne – mass – t: [§31](https://ucum.org/ucum#para-31)<br>total<br> count, particles – number – {tot}: [§50](https://ucum.org/ucum#para-50)<br>township – area – \[twp\]:<br> [§35](https://ucum.org/ucum#para-35)<br>trillion, parts per – fraction – \[pptr\]: [§29](https://ucum.org/ucum#para-29)<br>tropical year – time – a\_t: [§31](https://ucum.org/ucum#para-31)<br>tuberculin unit – biologic activity of tuberculin – \[tb'U\]: [§45](https://ucum.org/ucum#para-45)<br>unified atomic mass unit – mass – u: [§31](https://ucum.org/ucum#para-31)<br>unit at 39 °F, British thermal – energy – \[Btu\_39\]: [§43](https://ucum.org/ucum#para-43)<br>unit at 59 °F, British thermal – energy – \[Btu\_59\]: [§43](https://ucum.org/ucum#para-43)<br>unit at 60 °F, British thermal – energy – \[Btu\_60\]: [§43](https://ucum.org/ucum#para-43)<br>unit for Ambrosia artemisiifolia, allergen – procedure defined amount of<br> the major allergen of ragweed – \[Amb'a'1'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, APL –<br> biologic activity of anticardiolipin IgA – \[APL'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit,<br> Bethesda – biologic activity of factor VIII inhibitor – \[beth'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, Bodansky – biologic activity of phosphatase – \[bdsk'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, British thermal – energy – \[Btu\]: [§43](https://ucum.org/ucum#para-43)<br>unit, D-antigen – procedure defined amount of a poliomyelitis d-antigen<br> substance – \[D'ag'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, Dye – biologic activity of<br> amylase – \[dye'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, ELISA – arbitrary ELISA unit –<br> \[ELU\]: [§45](https://ucum.org/ucum#para-45)<br>unit, Ehrlich – Ehrlich unit – \[EU\]: [§45](https://ucum.org/ucum#para-45)<br>unit, GPL – biologic activity of anticardiolipin IgG –<br> \[GPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, Hounsfield – x-ray attenuation – \[hnsf'U\]:<br> [§44](https://ucum.org/ucum#para-44)<br>unit, King-Armstrong – biologic activity of phosphatase –<br> \[ka'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, Kunkel – arbitrary biologic activity –<br> \[knk'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, MPL – biologic activity of anticardiolipin<br> IgM – \[MPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, Mac Lagan – arbitrary biologic<br> activity – \[mclg'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, Somogyi – biologic activity of<br> amylase – \[smgy'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, Svedberg – sedimentation<br> coefficient – \[S\]: [§45](https://ucum.org/ucum#para-45)<br>unit, Todd – biologic activity<br> antistreptolysin O – \[todd'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, United States<br> Pharmacopeia – arbitrary – \[USP'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, Wood – fluid<br> resistance – \[wood'U\]: [§44](https://ucum.org/ucum#para-44)<br>unit, allergen – procedure defined<br> amount of an allergen using some reference standard – \[AU\]: [§45](https://ucum.org/ucum#para-45)<br>unit, anti factor Xa – biologic activity of factor Xa inhibitor (heparin) –<br> \[anti'Xa'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, arbitrary – arbitrary – \[arb'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, astronomic – length – AU: [§31](https://ucum.org/ucum#para-31)<br>unit, bioequivalent allergen – amount of an allergen calibrated through<br> in-vivo testing based on the ID50EAL method of (intradermal<br> dilution for 50mm sum of erythema diameters – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>unit,<br> fibrinogen equivalent – amount of fibrinogen broken down into the measured d-dimers – \[FEU\]: [§45](https://ucum.org/ucum#para-45)<br>unit, international table British thermal – energy –<br> \[Btu\_IT\]: [§43](https://ucum.org/ucum#para-43)<br>unit, international – arbitrary – \[IU\]: [§45](https://ucum.org/ucum#para-45)<br>unit, international – arbitrary – \[iU\]: [§45](https://ucum.org/ucum#para-45)<br>unit, mean British thermal – energy – \[Btu\_m\]: [§43](https://ucum.org/ucum#para-43)<br>unit, peripheral vascular resistance – fluid resistance – \[PRU\]: [§44](https://ucum.org/ucum#para-44)<br>unit, protein nitrogen – procedure defined amount of a<br> protein substance – \[PNU\]: [§45](https://ucum.org/ucum#para-45)<br>unit, thermochemical British<br> thermal – energy – \[Btu\_th\]: [§43](https://ucum.org/ucum#para-43)<br>unit, tuberculin – biologic<br> activity of tuberculin – \[tb'U\]: [§45](https://ucum.org/ucum#para-45)<br>unit, unified atomic mass<br> – mass – u: [§31](https://ucum.org/ucum#para-31)<br>units, colony forming – amount of a<br> proliferating organism – \[CFU\]: [§45](https://ucum.org/ucum#para-45)<br>units, focus forming –<br> amount of an infectious agent – \[FFU\]: [§45](https://ucum.org/ucum#para-45)<br>units, plaque<br> forming – amount of an infectious agent – \[PFU\]: [§45](https://ucum.org/ucum#para-45)<br>vacuum,<br> permeability of – magnetic permeability – \[mu\_0\]: [§32](https://ucum.org/ucum#para-32)<br>vacuum,<br> permittivity of – electric permittivity – \[eps\_0\]: [§32](https://ucum.org/ucum#para-32)<br>vascular<br> resistance unit, peripheral – fluid resistance – \[PRU\]: [§44](https://ucum.org/ucum#para-44)<br>velocity of light – velocity – \[c\]: [§32](https://ucum.org/ucum#para-32)<br>volt – electric potential – V: [§30](https://ucum.org/ucum#para-30)<br>volt, bel – electric potential level – B\[V\]: [§46](https://ucum.org/ucum#para-46)<br>water column, inch of – pressure – \[in\_i'H2O\]: [§44](https://ucum.org/ucum#para-44)<br>water column, meter of – pressure – m\[H2O\]: [§44](https://ucum.org/ucum#para-44)<br>watt – power – W: [§30](https://ucum.org/ucum#para-30)<br>watt, bel –<br> power level – B\[W\]: [§46](https://ucum.org/ucum#para-46)<br>weber – magnetic flux – Wb: [§30](https://ucum.org/ucum#para-30)<br>week – time – wk: [§31](https://ucum.org/ucum#para-31)<br>wet tissue, kilogram of – mass – kg{wet'tis}: [§50](https://ucum.org/ucum#para-50)<br>winchester gallon, historical – dry volume – \[gal\_wi\]: [§37](https://ucum.org/ucum#para-37)<br>wine gallon, Queen Anne's – fluid volume – \[gal\_us\]: [§37](https://ucum.org/ucum#para-37)<br>yard – length – \[yd\_br\]: [§36](https://ucum.org/ucum#para-36)<br>yard – length – \[yd\_i\]: [§34](https://ucum.org/ucum#para-34)<br>yard<br> – length – \[yd\_us\]: [§35](https://ucum.org/ucum#para-35)<br>yard, cubic – volume – \[cyd\_i\]: [§34](https://ucum.org/ucum#para-34)<br>yard, square – area – \[syd\_i\]: [§34](https://ucum.org/ucum#para-34)<br>year – time – a: [§31](https://ucum.org/ucum#para-31)<br>year, mean<br> Gregorian – time – a\_g: [§31](https://ucum.org/ucum#para-31)<br>year, mean Julian – time – a\_j: [§31](https://ucum.org/ucum#para-31)<br>year, tropical – time – a\_t: [§31](https://ucum.org/ucum#para-31)<br>yocto – prefix – y: [§27](https://ucum.org/ucum#para-27)<br>yotta –<br> prefix – Y: [§27](https://ucum.org/ucum#para-27)<br>zepto – prefix – z: [§27](https://ucum.org/ucum#para-27)<br>zetta – prefix – Z: [§27](https://ucum.org/ucum#para-27)<br>Ångström<br> – length – Ao: [§47](https://ucum.org/ucum#para-47) |\
\
|     |     |     |\
| --- | --- | --- |\
| % – percent – fraction: [§29](https://ucum.org/ucum#para-29)<br>%\[slope\]<br> – percent of slope – slope: [§44](https://ucum.org/ucum#para-44)<br>' – minute – plane angle: [§31](https://ucum.org/ucum#para-31)<br>'' – second – plane angle: [§31](https://ucum.org/ucum#para-31)<br>10\* – the number ten for arbitrary powers – number: [§29](https://ucum.org/ucum#para-29)<br>10^ – the number ten for arbitrary powers – number: [§29](https://ucum.org/ucum#para-29)<br>A – ampère – electric current: [§30](https://ucum.org/ucum#para-30)<br>AU – astronomic unit – length: [§31](https://ucum.org/ucum#para-31)<br>Ao – Ångström – length: [§47](https://ucum.org/ucum#para-47)<br>B –<br> bel – level: [§46](https://ucum.org/ucum#para-46)<br>B\[10.nV\] – bel 10 nanovolt – electric<br> potential level: [§46](https://ucum.org/ucum#para-46)<br>B\[SPL\] – bel sound pressure – pressure<br> level: [§46](https://ucum.org/ucum#para-46)<br>B\[V\] – bel volt – electric potential level: [§46](https://ucum.org/ucum#para-46)<br>B\[W\] – bel watt – power level: [§46](https://ucum.org/ucum#para-46)<br>B\[kW\] – bel kilowatt – power level: [§46](https://ucum.org/ucum#para-46)<br>B\[mV\] – bel millivolt – electric potential level: [§46](https://ucum.org/ucum#para-46)<br>B\[uV\] – bel microvolt – electric potential level: [§46](https://ucum.org/ucum#para-46)<br>Bd – baud – signal transmission rate: [§48](https://ucum.org/ucum#para-48)<br>Bi – Biot – electric current: [§33](https://ucum.org/ucum#para-33)<br>Bq – becquerel – radioactivity: [§30](https://ucum.org/ucum#para-30)<br>By – byte – amount of information: [§48](https://ucum.org/ucum#para-48)<br>C – coulomb – electric charge: [§28](https://ucum.org/ucum#para-28)<br>Cel – degree Celsius – temperature: [§30](https://ucum.org/ucum#para-30)<br>Ci – Curie – radioactivity: [§33](https://ucum.org/ucum#para-33)<br>E<br> – exa – prefix : [§27](https://ucum.org/ucum#para-27)<br>F – farad – electric capacitance: [§30](https://ucum.org/ucum#para-30)<br>G – Gauss – magnetic flux density: [§33](https://ucum.org/ucum#para-33)<br>G – giga – prefix : [§27](https://ucum.org/ucum#para-27)<br>Gal – Gal<br> – acceleration: [§33](https://ucum.org/ucum#para-33)<br>Gb – Gilbert – magnetic tension: [§33](https://ucum.org/ucum#para-33)<br>Gi – gibi – prefix : [§49](https://ucum.org/ucum#para-49)<br>Gy – gray – energy dose: [§30](https://ucum.org/ucum#para-30)<br>H –<br> henry – inductance: [§30](https://ucum.org/ucum#para-30)<br>Hz – hertz – frequency: [§30](https://ucum.org/ucum#para-30)<br>J – joule – energy: [§30](https://ucum.org/ucum#para-30)<br>K – kelvin – temperature: [§28](https://ucum.org/ucum#para-28)<br>Ki<br> – kibi – prefix : [§49](https://ucum.org/ucum#para-49)<br>Ky – Kayser – lineic number: [§33](https://ucum.org/ucum#para-33)<br>L – liter – volume: [§31](https://ucum.org/ucum#para-31)<br>Lmb – Lambert – brightness: [§33](https://ucum.org/ucum#para-33)<br>M<br> – mega – prefix : [§27](https://ucum.org/ucum#para-27)<br>Mi – mebi – prefix : [§49](https://ucum.org/ucum#para-49)<br>Mx – Maxwell – flux of magnetic induction: [§33](https://ucum.org/ucum#para-33)<br>N – newton – force: [§30](https://ucum.org/ucum#para-30)<br>Np –<br> neper – level: [§46](https://ucum.org/ucum#para-46)<br>Oe – Oersted – magnetic field intensity: [§33](https://ucum.org/ucum#para-33)<br>Ohm – ohm – electric resistance: [§30](https://ucum.org/ucum#para-30)<br>P – Poise – dynamic viscosity: [§33](https://ucum.org/ucum#para-33)<br>P – peta – prefix : [§27](https://ucum.org/ucum#para-27)<br>Pa –<br> pascal – pressure: [§30](https://ucum.org/ucum#para-30)<br>R – Roentgen – ion dose: [§33](https://ucum.org/ucum#para-33)<br>RAD – radiation absorbed dose – energy dose: [§33](https://ucum.org/ucum#para-33)<br>REM – radiation equivalent man – dose equivalent: [§33](https://ucum.org/ucum#para-33)<br>S – siemens – electric conductance: [§30](https://ucum.org/ucum#para-30)<br>St – Stokes – kinematic viscosity: [§33](https://ucum.org/ucum#para-33)<br>Sv – sievert – dose equivalent: [§30](https://ucum.org/ucum#para-30)<br>T – tera – prefix : [§27](https://ucum.org/ucum#para-27)<br>T – tesla<br> – magnetic flux density: [§30](https://ucum.org/ucum#para-30)<br>Ti – tebi – prefix : [§49](https://ucum.org/ucum#para-49)<br>U – Unit – catalytic activity: [§45](https://ucum.org/ucum#para-45)<br>V – volt – electric potential: [§30](https://ucum.org/ucum#para-30)<br>W – watt – power: [§30](https://ucum.org/ucum#para-30)<br>Wb – weber<br> – magnetic flux: [§30](https://ucum.org/ucum#para-30)<br>Y – yotta – prefix : [§27](https://ucum.org/ucum#para-27)<br>Z – zetta – prefix : [§27](https://ucum.org/ucum#para-27)<br>\[APL'U\]<br> – APL unit – biologic activity of anticardiolipin IgA: [§45](https://ucum.org/ucum#para-45)<br>\[AU\]<br> – allergen unit – procedure defined amount of an allergen using some reference standard: [§45](https://ucum.org/ucum#para-45)<br>\[Amb'a'1'U\] – allergen unit for Ambrosia artemisiifolia –<br> procedure defined amount of the major allergen of ragweed: [§45](https://ucum.org/ucum#para-45)<br>\[BAU\] – bioequivalent allergen unit – amount of an allergen calibrated<br> through in-vivo testing based on the ID50EAL method<br> of (intradermal dilution for 50mm sum of erythema diameters: [§45](https://ucum.org/ucum#para-45)<br>\[Btu\] – British thermal unit – energy: [§43](https://ucum.org/ucum#para-43)<br>\[Btu\_39\] – British thermal unit at 39 °F – energy: [§43](https://ucum.org/ucum#para-43)<br>\[Btu\_59\] – British thermal unit at 59 °F – energy: [§43](https://ucum.org/ucum#para-43)<br>\[Btu\_60\] – British thermal unit at 60 °F – energy: [§43](https://ucum.org/ucum#para-43)<br>\[Btu\_IT\] – international table British thermal unit – energy: [§43](https://ucum.org/ucum#para-43)<br>\[Btu\_m\] – mean British thermal unit – energy: [§43](https://ucum.org/ucum#para-43)<br>\[Btu\_th\] – thermochemical British thermal unit – energy: [§43](https://ucum.org/ucum#para-43)<br>\[CCID\_50\] – 50% cell culture infectious dose – biologic<br> activity (infectivity) of an infectious agent preparation: [§45](https://ucum.org/ucum#para-45)<br>\[CFU\] – colony forming units – amount of a proliferating organism: [§45](https://ucum.org/ucum#para-45)<br>\[Cal\] – nutrition label Calories – energy: [§43](https://ucum.org/ucum#para-43)<br>\[Ch\] – Charrière french – gauge of catheters: [§44](https://ucum.org/ucum#para-44)<br>\[D'ag'U\] – D-antigen unit – procedure defined amount of a<br> poliomyelitis d-antigen substance: [§45](https://ucum.org/ucum#para-45)<br>\[EID\_50\] – 50% embryo<br> infectious dose – biologic activity (infectivity) of an infectious agent preparation: [§45](https://ucum.org/ucum#para-45)<br>\[ELU\] – ELISA unit – arbitrary ELISA unit: [§45](https://ucum.org/ucum#para-45)<br>\[EU\] – Ehrlich unit – Ehrlich unit: [§45](https://ucum.org/ucum#para-45)<br>\[FEU\] – fibrinogen equivalent unit – amount of fibrinogen broken down into<br> the measured d-dimers: [§45](https://ucum.org/ucum#para-45)<br>\[FFU\] – focus forming units – amount<br> of an infectious agent: [§45](https://ucum.org/ucum#para-45)<br>\[FNU\] – Formazin Nephelometric Unit<br> – turbidity: [§47](https://ucum.org/ucum#para-47)<br>\[GPL'U\] – GPL unit – biologic activity of<br> anticardiolipin IgG: [§45](https://ucum.org/ucum#para-45)<br>\[G\] – Newtonian constant of<br> gravitation – (unclassified): [§32](https://ucum.org/ucum#para-32)<br>\[HPF\] – high power field –<br> view area in microscope: [§45](https://ucum.org/ucum#para-45)<br>\[HP\] – horsepower – power: [§43](https://ucum.org/ucum#para-43)<br>\[IR\] – index of reactivity – amount of an allergen<br> calibrated through in-vivo testing using the Stallergenes® method: [§45](https://ucum.org/ucum#para-45)<br>\[IU\] – international unit – arbitrary: [§45](https://ucum.org/ucum#para-45)<br>\[LPF\] – low power field – view area in microscope: [§45](https://ucum.org/ucum#para-45)<br>\[Lf\] – Limit of flocculation – procedure defined amount of an antigen<br> substance: [§45](https://ucum.org/ucum#para-45)<br>\[MET\] – metabolic equivalent – metabolic cost of<br> physical activity: [§44](https://ucum.org/ucum#para-44)<br>\[MPL'U\] – MPL unit – biologic activity<br> of anticardiolipin IgM: [§45](https://ucum.org/ucum#para-45)<br>\[NTU\] – Nephelometric Turbidity<br> Unit – turbidity: [§47](https://ucum.org/ucum#para-47)<br>\[PFU\] – plaque forming units – amount of<br> an infectious agent: [§45](https://ucum.org/ucum#para-45)<br>\[PNU\] – protein nitrogen unit –<br> procedure defined amount of a protein substance: [§45](https://ucum.org/ucum#para-45)<br>\[PRU\] –<br> peripheral vascular resistance unit – fluid resistance: [§44](https://ucum.org/ucum#para-44)<br>\[S\]<br> – Svedberg unit – sedimentation coefficient: [§45](https://ucum.org/ucum#para-45)<br>\[TCID\_50\] –<br> 50% tissue culture infectious dose – biologic activity (infectivity) of an infectious agent preparation:<br> [§45](https://ucum.org/ucum#para-45)<br>\[USP'U\] – United States Pharmacopeia unit – arbitrary: [§45](https://ucum.org/ucum#para-45)<br>\[acr\_br\] – acre – area: [§36](https://ucum.org/ucum#para-36)<br>\[acr\_us\] – acre – area: [§35](https://ucum.org/ucum#para-35)<br>\[anti'Xa'U\] – anti factor Xa unit – biologic activity of factor Xa<br> inhibitor (heparin): [§45](https://ucum.org/ucum#para-45)<br>\[arb'U\] – arbitrary unit – arbitrary:<br> [§45](https://ucum.org/ucum#para-45)<br>\[bbl\_us\] – barrel – fluid volume: [§37](https://ucum.org/ucum#para-37)<br>\[bdsk'U\] – Bodansky unit – biologic activity of phosphatase: [§45](https://ucum.org/ucum#para-45)<br>\[beth'U\] – Bethesda unit – biologic activity of factor VIII<br> inhibitor: [§45](https://ucum.org/ucum#para-45)<br>\[bf\_i\] – board foot – volume: [§34](https://ucum.org/ucum#para-34)<br>\[bu\_br\] – bushel – volume: [§38](https://ucum.org/ucum#para-38)<br>\[bu\_us\] – bushel – dry volume: [§37](https://ucum.org/ucum#para-37)<br>\[c\] – velocity of light – velocity: [§32](https://ucum.org/ucum#para-32)<br>\[car\_Au\] – carat of gold alloys – mass fraction: [§47](https://ucum.org/ucum#para-47)<br>\[car\_m\] – metric carat – mass: [§47](https://ucum.org/ucum#para-47)<br>\[cft\_i\] – cubic foot – volume: [§34](https://ucum.org/ucum#para-34)<br>\[ch\_br\] – Gunter's chain – length: [§36](https://ucum.org/ucum#para-36)<br>\[ch\_us\] – Gunter's chain Surveyor's chain – length: [§35](https://ucum.org/ucum#para-35)<br>\[cicero\] – cicero Didot's pica – length: [§42](https://ucum.org/ucum#para-42)<br>\[cin\_i\] – cubic inch – volume: [§34](https://ucum.org/ucum#para-34)<br>\[cml\_i\] – circular mil – area: [§34](https://ucum.org/ucum#para-34)<br>\[cr\_i\] – cord – volume: [§34](https://ucum.org/ucum#para-34)<br>\[crd\_us\] – cord – fluid volume: [§37](https://ucum.org/ucum#para-37)<br>\[cup\_m\] – metric cup – volume: [§37](https://ucum.org/ucum#para-37)<br>\[cup\_us\] – cup – volume: [§37](https://ucum.org/ucum#para-37)<br>\[cyd\_i\] – cubic yard – volume: [§34](https://ucum.org/ucum#para-34)<br>\[degF\] – degree Fahrenheit – temperature: [§43](https://ucum.org/ucum#para-43)<br>\[degR\] – degree Rankine – temperature: [§43](https://ucum.org/ucum#para-43)<br>\[degRe\] – degree Réaumur – temperature: [§43](https://ucum.org/ucum#para-43)<br>\[den\] – Denier – linear mass density (of textile thread): [§43](https://ucum.org/ucum#para-43)<br>\[didot\] – didot Didot's point – length: [§42](https://ucum.org/ucum#para-42)<br>\[diop\] – diopter – refraction of a lens: [§44](https://ucum.org/ucum#para-44)<br>\[dpt\_us\] – dry pint – dry volume: [§37](https://ucum.org/ucum#para-37)<br>\[dqt\_us\] – dry quart – dry volume: [§37](https://ucum.org/ucum#para-37)<br>\[dr\_ap\] – dram drachm – mass: [§41](https://ucum.org/ucum#para-41)<br>\[dr\_av\] – dram – mass: [§39](https://ucum.org/ucum#para-39)<br>\[drp\]<br> – drop – volume: [§44](https://ucum.org/ucum#para-44)<br>\[dye'U\] – Dye unit – biologic activity of<br> amylase: [§45](https://ucum.org/ucum#para-45)<br>\[e\] – elementary charge – electric charge: [§32](https://ucum.org/ucum#para-32)<br>\[eps\_0\] – permittivity of vacuum – electric permittivity:<br> [§32](https://ucum.org/ucum#para-32)<br>\[fdr\_br\] – fluid dram – volume: [§38](https://ucum.org/ucum#para-38)<br>\[fdr\_us\] – fluid dram – fluid volume: [§37](https://ucum.org/ucum#para-37)<br>\[foz\_br\] – fluid ounce – volume: [§38](https://ucum.org/ucum#para-38)<br>\[foz\_m\] – metric fluid ounce – fluid volume: [§37](https://ucum.org/ucum#para-37)<br>\[foz\_us\] – fluid ounce – fluid volume: [§37](https://ucum.org/ucum#para-37)<br>\[ft\_br\] – foot – length: [§36](https://ucum.org/ucum#para-36)<br>\[ft\_i\] – foot – length: [§34](https://ucum.org/ucum#para-34)<br>\[ft\_us\] – foot – length: [§35](https://ucum.org/ucum#para-35)<br>\[fth\_br\] – fathom – length: [§36](https://ucum.org/ucum#para-36)<br>\[fth\_i\] – fathom – depth of water: [§34](https://ucum.org/ucum#para-34)<br>\[fth\_us\] – fathom – length: [§35](https://ucum.org/ucum#para-35)<br>\[fur\_us\] – furlong – length: [§35](https://ucum.org/ucum#para-35)<br>\[g\] – standard acceleration of free fall – acceleration: [§32](https://ucum.org/ucum#para-32)<br>\[gal\_br\] – gallon – volume: [§38](https://ucum.org/ucum#para-38)<br>\[gal\_us\] – Queen Anne's wine gallon – fluid volume: [§37](https://ucum.org/ucum#para-37)<br>\[gal\_wi\] – historical winchester gallon – dry volume: [§37](https://ucum.org/ucum#para-37)<br>\[gil\_br\] – gill – volume: [§38](https://ucum.org/ucum#para-38)<br>\[gil\_us\] – gill – fluid volume: [§37](https://ucum.org/ucum#para-37)<br>\[gr\] – grain – mass: [§39](https://ucum.org/ucum#para-39)<br>\[h\] –<br> Planck constant – action: [§32](https://ucum.org/ucum#para-32)<br>\[hd\_i\] – hand – height of horses:<br> [§34](https://ucum.org/ucum#para-34)<br>\[hnsf'U\] – Hounsfield unit – x-ray attenuation: [§44](https://ucum.org/ucum#para-44)<br>\[hp'\_C\] – homeopathic potency of centesimal series<br> (retired) – homeopathic potency (retired): [§44](https://ucum.org/ucum#para-44)<br>\[hp'\_M\] –<br> homeopathic potency of millesimal series (retired) – homeopathic potency (retired): [§44](https://ucum.org/ucum#para-44)<br>\[hp'\_Q\] – homeopathic potency of quintamillesimal series (retired) –<br> homeopathic potency (retired): [§44](https://ucum.org/ucum#para-44)<br>\[hp'\_X\] – homeopathic<br> potency of decimal series (retired) – homeopathic potency (retired): [§44](https://ucum.org/ucum#para-44)<br>\[hp\_C\] – homeopathic potency of centesimal hahnemannian series –<br> homeopathic potency (Hahnemann): [§44](https://ucum.org/ucum#para-44)<br>\[hp\_M\] – homeopathic<br> potency of millesimal hahnemannian series – homeopathic potency (Hahnemann): [§44](https://ucum.org/ucum#para-44)<br>\[hp\_Q\] – homeopathic potency of quintamillesimal hahnemannian series –<br> homeopathic potency (Hahnemann): [§44](https://ucum.org/ucum#para-44)<br>\[hp\_X\] – homeopathic<br> potency of decimal hahnemannian series – homeopathic potency (Hahnemann): [§44](https://ucum.org/ucum#para-44) |  | \[iU\] – international unit – arbitrary: [§45](https://ucum.org/ucum#para-45)<br>\[in\_br\] – inch – length: [§36](https://ucum.org/ucum#para-36)<br>\[in\_i'H2O\] – inch of water column – pressure: [§44](https://ucum.org/ucum#para-44)<br>\[in\_i'Hg\] – inch of mercury column – pressure: [§44](https://ucum.org/ucum#para-44)<br>\[in\_i\] – inch – length: [§34](https://ucum.org/ucum#para-34)<br>\[in\_us\] – inch – length: [§35](https://ucum.org/ucum#para-35)<br>\[k\]<br> – Boltzmann constant – (unclassified): [§32](https://ucum.org/ucum#para-32)<br>\[ka'U\] –<br> King-Armstrong unit – biologic activity of phosphatase: [§45](https://ucum.org/ucum#para-45)<br>\[kn\_br\] – knot – velocity: [§36](https://ucum.org/ucum#para-36)<br>\[kn\_i\] – knot – velocity: [§34](https://ucum.org/ucum#para-34)<br>\[knk'U\] – Kunkel unit – arbitrary biologic activity: [§45](https://ucum.org/ucum#para-45)<br>\[kp\_C\] – homeopathic potency of centesimal korsakovian series – homeopathic<br> potency (Korsakov): [§44](https://ucum.org/ucum#para-44)<br>\[kp\_M\] – homeopathic potency of<br> millesimal korsakovian series – homeopathic potency (Korsakov): [§44](https://ucum.org/ucum#para-44)<br>\[kp\_Q\] – homeopathic potency of quintamillesimal korsakovian series –<br> homeopathic potency (Korsakov): [§44](https://ucum.org/ucum#para-44)<br>\[kp\_X\] – homeopathic<br> potency of decimal korsakovian series – homeopathic potency (Korsakov): [§44](https://ucum.org/ucum#para-44)<br>\[lb\_ap\] – pound – mass: [§41](https://ucum.org/ucum#para-41)<br>\[lb\_av\] – pound – mass: [§39](https://ucum.org/ucum#para-39)<br>\[lb\_tr\] – pound – mass: [§40](https://ucum.org/ucum#para-40)<br>\[lbf\_av\] – pound force – force: [§32](https://ucum.org/ucum#para-32)<br>\[lcwt\_av\] – long hundredweight British hundredweight – mass: [§39](https://ucum.org/ucum#para-39)<br>\[ligne\] – ligne French line – length: [§42](https://ucum.org/ucum#para-42)<br>\[lk\_br\] – link for Gunter's chain – length: [§36](https://ucum.org/ucum#para-36)<br>\[lk\_us\] – link for Gunter's chain – length: [§35](https://ucum.org/ucum#para-35)<br>\[lne\] – line – length: [§42](https://ucum.org/ucum#para-42)<br>\[lton\_av\] – long ton British ton – mass: [§39](https://ucum.org/ucum#para-39)<br>\[ly\] – light-year – length: [§32](https://ucum.org/ucum#para-32)<br>\[m/s2/Hz^(1/2)\] – meter per square seconds per square root of hertz –<br> amplitude spectral density: [§47](https://ucum.org/ucum#para-47)<br>\[m\_e\] – electron mass – mass:<br> [§32](https://ucum.org/ucum#para-32)<br>\[m\_p\] – proton mass – mass: [§32](https://ucum.org/ucum#para-32)<br>\[mclg'U\] – Mac Lagan unit – arbitrary biologic activity: [§45](https://ucum.org/ucum#para-45)<br>\[mesh\_i\] – mesh – lineic number: [§44](https://ucum.org/ucum#para-44)<br>\[mi\_br\] – mile – length: [§36](https://ucum.org/ucum#para-36)<br>\[mi\_i\] – mile – length: [§34](https://ucum.org/ucum#para-34)<br>\[mi\_us\] – mile – length: [§35](https://ucum.org/ucum#para-35)<br>\[mil\_i\] – mil – length: [§34](https://ucum.org/ucum#para-34)<br>\[mil\_us\] – mil – length: [§35](https://ucum.org/ucum#para-35)<br>\[min\_br\] – minim – volume: [§38](https://ucum.org/ucum#para-38)<br>\[min\_us\] – minim – fluid volume: [§37](https://ucum.org/ucum#para-37)<br>\[mu\_0\] – permeability of vacuum – magnetic permeability: [§32](https://ucum.org/ucum#para-32)<br>\[nmi\_br\] – nautical mile – length: [§36](https://ucum.org/ucum#para-36)<br>\[nmi\_i\] – nautical mile – length: [§34](https://ucum.org/ucum#para-34)<br>\[oz\_ap\] – ounce – mass: [§41](https://ucum.org/ucum#para-41)<br>\[oz\_av\] – ounce – mass: [§39](https://ucum.org/ucum#para-39)<br>\[oz\_m\] – metric ounce – mass: [§41](https://ucum.org/ucum#para-41)<br>\[oz\_tr\] – ounce – mass: [§40](https://ucum.org/ucum#para-40)<br>\[p'diop\] – prism diopter – refraction of a prism: [§44](https://ucum.org/ucum#para-44)<br>\[pH\] – pH – acidity: [§45](https://ucum.org/ucum#para-45)<br>\[pc\_br\]<br> – pace – length: [§36](https://ucum.org/ucum#para-36)<br>\[pca\] – pica – length: [§42](https://ucum.org/ucum#para-42)<br>\[pca\_pr\] – Printer's pica – length: [§42](https://ucum.org/ucum#para-42)<br>\[pi\] – the number pi – number: [§29](https://ucum.org/ucum#para-29)<br>\[pied\] – pied French foot – length: [§42](https://ucum.org/ucum#para-42)<br>\[pk\_br\] – peck – volume: [§38](https://ucum.org/ucum#para-38)<br>\[pk\_us\] – peck – dry volume: [§37](https://ucum.org/ucum#para-37)<br>\[pnt\] – point – length: [§42](https://ucum.org/ucum#para-42)<br>\[pnt\_pr\] – Printer's point – length: [§42](https://ucum.org/ucum#para-42)<br>\[pouce\] – pouce French inch – length: [§42](https://ucum.org/ucum#para-42)<br>\[ppb\] – parts per billion – fraction: [§29](https://ucum.org/ucum#para-29)<br>\[ppm\] – parts per million – fraction: [§29](https://ucum.org/ucum#para-29)<br>\[ppth\] – parts per thousand – fraction: [§29](https://ucum.org/ucum#para-29)<br>\[pptr\] – parts per trillion – fraction: [§29](https://ucum.org/ucum#para-29)<br>\[psi\] – pound per square inch – pressure: [§47](https://ucum.org/ucum#para-47)<br>\[pt\_br\] – pint – volume: [§38](https://ucum.org/ucum#para-38)<br>\[pt\_us\] – pint – fluid volume: [§37](https://ucum.org/ucum#para-37)<br>\[pwt\_tr\] – pennyweight – mass: [§40](https://ucum.org/ucum#para-40)<br>\[qt\_br\] – quart – volume: [§38](https://ucum.org/ucum#para-38)<br>\[qt\_us\] – quart – fluid volume: [§37](https://ucum.org/ucum#para-37)<br>\[rch\_us\] – Ramden's chain Engineer's chain – length: [§35](https://ucum.org/ucum#para-35)<br>\[rd\_br\] – rod – length: [§36](https://ucum.org/ucum#para-36)<br>\[rd\_us\] – rod – length: [§35](https://ucum.org/ucum#para-35)<br>\[rlk\_us\] – link for Ramden's chain – length: [§35](https://ucum.org/ucum#para-35)<br>\[sc\_ap\] – scruple – mass: [§41](https://ucum.org/ucum#para-41)<br>\[sct\] – section – area: [§35](https://ucum.org/ucum#para-35)<br>\[scwt\_av\] – short hundredweight U.S. hundredweight – mass: [§39](https://ucum.org/ucum#para-39)<br>\[sft\_i\] – square foot – area: [§34](https://ucum.org/ucum#para-34)<br>\[sin\_i\] – square inch – area: [§34](https://ucum.org/ucum#para-34)<br>\[smgy'U\] – Somogyi unit – biologic activity of amylase: [§45](https://ucum.org/ucum#para-45)<br>\[smi\_us\] – square mile – area: [§35](https://ucum.org/ucum#para-35)<br>\[smoot\] – Smoot – length: [§47](https://ucum.org/ucum#para-47)<br>\[srd\_us\] – square rod – area: [§35](https://ucum.org/ucum#para-35)<br>\[ston\_av\] – short ton U.S. ton – mass: [§39](https://ucum.org/ucum#para-39)<br>\[stone\_av\] – stone British stone – mass: [§39](https://ucum.org/ucum#para-39)<br>\[syd\_i\] – square yard – area: [§34](https://ucum.org/ucum#para-34)<br>\[tb'U\] – tuberculin unit – biologic activity of tuberculin: [§45](https://ucum.org/ucum#para-45)<br>\[tbs\_m\] – metric tablespoon – volume: [§37](https://ucum.org/ucum#para-37)<br>\[tbs\_us\] – tablespoon – volume: [§37](https://ucum.org/ucum#para-37)<br>\[todd'U\] – Todd unit – biologic activity antistreptolysin O: [§45](https://ucum.org/ucum#para-45)<br>\[tsp\_m\] – metric teaspoon – volume: [§37](https://ucum.org/ucum#para-37)<br>\[tsp\_us\] – teaspoon – volume: [§37](https://ucum.org/ucum#para-37)<br>\[twp\] – township – area: [§35](https://ucum.org/ucum#para-35)<br>\[wood'U\] – Wood unit – fluid resistance: [§44](https://ucum.org/ucum#para-44)<br>\[yd\_br\] – yard – length: [§36](https://ucum.org/ucum#para-36)<br>\[yd\_i\] – yard – length: [§34](https://ucum.org/ucum#para-34)<br>\[yd\_us\] – yard – length: [§35](https://ucum.org/ucum#para-35)<br>a –<br> atto – prefix : [§27](https://ucum.org/ucum#para-27)<br>a – year – time: [§31](https://ucum.org/ucum#para-31)<br>a\_g – mean Gregorian year – time: [§31](https://ucum.org/ucum#para-31)<br>a\_j – mean Julian year – time: [§31](https://ucum.org/ucum#para-31)<br>a\_t – tropical year – time: [§31](https://ucum.org/ucum#para-31)<br>ar – are – area: [§31](https://ucum.org/ucum#para-31)<br>atm –<br> standard atmosphere – pressure: [§32](https://ucum.org/ucum#para-32)<br>att – technical atmosphere<br> – pressure: [§47](https://ucum.org/ucum#para-47)<br>b – barn – action area: [§47](https://ucum.org/ucum#para-47)<br>bar – bar – pressure: [§31](https://ucum.org/ucum#para-31)<br>bit –<br> bit – amount of information: [§48](https://ucum.org/ucum#para-48)<br>bit\_s – bit – amount of<br> information: [§48](https://ucum.org/ucum#para-48)<br>c – centi – prefix : [§27](https://ucum.org/ucum#para-27)<br>cal – calorie – energy: [§43](https://ucum.org/ucum#para-43)<br>cal\_IT – international table calorie – energy: [§43](https://ucum.org/ucum#para-43)<br>cal\_\[15\] – calorie at 15 °C – energy: [§43](https://ucum.org/ucum#para-43)<br>cal\_\[20\] – calorie at 20 °C – energy: [§43](https://ucum.org/ucum#para-43)<br>cal\_m – mean calorie – energy: [§43](https://ucum.org/ucum#para-43)<br>cal\_th – thermochemical calorie – energy: [§43](https://ucum.org/ucum#para-43)<br>cd – candela – luminous intensity: [§28](https://ucum.org/ucum#para-28)<br>circ – circle – plane angle: [§47](https://ucum.org/ucum#para-47)<br>d – day – time: [§31](https://ucum.org/ucum#para-31)<br>d – deci –<br> prefix : [§27](https://ucum.org/ucum#para-27)<br>da – deka – prefix : [§27](https://ucum.org/ucum#para-27)<br>deg – degree – plane angle: [§31](https://ucum.org/ucum#para-31)<br>dyn – dyne – force: [§33](https://ucum.org/ucum#para-33)<br>eV –<br> electronvolt – energy: [§31](https://ucum.org/ucum#para-31)<br>eq – equivalents – amount of<br> substance: [§45](https://ucum.org/ucum#para-45)<br>erg – erg – energy: [§33](https://ucum.org/ucum#para-33)<br>f – femto – prefix : [§27](https://ucum.org/ucum#para-27)<br>g – gram<br> – mass: [§28](https://ucum.org/ucum#para-28)<br>g% – gram percent – mass concentration: [§45](https://ucum.org/ucum#para-45)<br>g.m/{H.B.} – gram meter per heartbeat – proportional to<br> ventricular stroke work: [§50](https://ucum.org/ucum#para-50)<br>gf – gram-force – force: [§32](https://ucum.org/ucum#para-32)<br>gf.m/{H.B.} – gram-force meter per heartbeat – ventricular<br> stroke work: [§50](https://ucum.org/ucum#para-50)<br>gon – gon grade – plane angle: [§31](https://ucum.org/ucum#para-31)<br>h – hecto – prefix : [§27](https://ucum.org/ucum#para-27)<br>h – hour – time: [§31](https://ucum.org/ucum#para-31)<br>k – kilo –<br> prefix : [§27](https://ucum.org/ucum#para-27)<br>kat – katal – catalytic activity: [§45](https://ucum.org/ucum#para-45)<br>kg{wet'tis} – kilogram of wet tissue – mass: [§50](https://ucum.org/ucum#para-50)<br>l – liter – volume: [§31](https://ucum.org/ucum#para-31)<br>lm – lumen – luminous flux: [§30](https://ucum.org/ucum#para-30)<br>lx – lux – illuminance: [§30](https://ucum.org/ucum#para-30)<br>m –<br> meter – length: [§28](https://ucum.org/ucum#para-28)<br>m – milli – prefix : [§27](https://ucum.org/ucum#para-27)<br>m\[H2O\] – meter of water column – pressure: [§44](https://ucum.org/ucum#para-44)<br>m\[Hg\] – meter of mercury column – pressure: [§44](https://ucum.org/ucum#para-44)<br>mg{creat} – milligram of creatinine – mass: [§50](https://ucum.org/ucum#para-50)<br>mho – mho – electric conductance: [§47](https://ucum.org/ucum#para-47)<br>min – minute – time: [§31](https://ucum.org/ucum#para-31)<br>mo –<br> month – time: [§31](https://ucum.org/ucum#para-31)<br>mo\_g – mean Gregorian month – time: [§31](https://ucum.org/ucum#para-31)<br>mo\_j – mean Julian month – time: [§31](https://ucum.org/ucum#para-31)<br>mo\_s – synodal month – time: [§31](https://ucum.org/ucum#para-31)<br>mol – mole – amount of substance: [§30](https://ucum.org/ucum#para-30)<br>n – nano – prefix : [§27](https://ucum.org/ucum#para-27)<br>osm –<br> osmole – amount of substance (dissolved particles): [§45](https://ucum.org/ucum#para-45)<br>p –<br> pico – prefix : [§27](https://ucum.org/ucum#para-27)<br>pc – parsec – length: [§31](https://ucum.org/ucum#para-31)<br>ph – phot – illuminance: [§33](https://ucum.org/ucum#para-33)<br>rad<br> – radian – plane angle: [§28](https://ucum.org/ucum#para-28)<br>s – second – time: [§28](https://ucum.org/ucum#para-28)<br>sb – stilb – lum. intensity density: [§33](https://ucum.org/ucum#para-33)<br>sph – sphere – solid angle: [§47](https://ucum.org/ucum#para-47)<br>sr – steradian – solid angle: [§30](https://ucum.org/ucum#para-30)<br>st – stere – volume: [§47](https://ucum.org/ucum#para-47)<br>t –<br> tonne – mass: [§31](https://ucum.org/ucum#para-31)<br>tex – tex – linear mass density (of textile<br> thread): [§43](https://ucum.org/ucum#para-43)<br>u – micro – prefix : [§27](https://ucum.org/ucum#para-27)<br>u – unified atomic mass unit – mass: [§31](https://ucum.org/ucum#para-31)<br>wk – week – time: [§31](https://ucum.org/ucum#para-31)<br>y – yocto –<br> prefix : [§27](https://ucum.org/ucum#para-27)<br>z – zepto – prefix : [§27](https://ucum.org/ucum#para-27)<br>{rbc} – red blood cell count – number: [§50](https://ucum.org/ucum#para-50)<br>{tbl} – tablets – number: [§50](https://ucum.org/ucum#para-50)<br>{tot} – particles total count – number: [§50](https://ucum.org/ucum#para-50) |\
\
|     |     |     |\
| --- | --- | --- |\
| (Hahnemann), homeopathic potency – homeopathic potency of centesimal<br> hahnemannian series – \[hp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>(Hahnemann), homeopathic<br> potency – homeopathic potency of decimal hahnemannian series – \[hp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>(Hahnemann), homeopathic potency – homeopathic potency of millesimal<br> hahnemannian series – \[hp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>(Hahnemann), homeopathic<br> potency – homeopathic potency of quintamillesimal hahnemannian series – \[hp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>(Korsakov), homeopathic potency – homeopathic potency of centesimal<br> korsakovian series – \[kp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>(Korsakov), homeopathic<br> potency – homeopathic potency of decimal korsakovian series – \[kp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>(Korsakov), homeopathic potency – homeopathic potency of millesimal<br> korsakovian series – \[kp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>(Korsakov), homeopathic<br> potency – homeopathic potency of quintamillesimal korsakovian series – \[kp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>(dissolved particles), amount of substance – osmole – osm: [§45](https://ucum.org/ucum#para-45)<br>(heparin), biologic activity of factor Xa inhibitor – anti<br> factor Xa unit – \[anti'Xa'U\]: [§45](https://ucum.org/ucum#para-45)<br>(infectivity) of an<br> infectious agent preparation, biologic activity – 50% cell culture infectious dose – \[CCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>(infectivity) of an infectious agent preparation, biologic<br> activity – 50% embryo infectious dose – \[EID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>(infectivity) of an infectious agent preparation, biologic activity – 50%<br> tissue culture infectious dose – \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>(intradermal<br> dilution for 50mm sum of erythema diameters, amount of an allergen calibrated through in-vivo testing<br> based<br> on the ID50EAL method of – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>(of textile thread), linear mass density – Denier – \[den\]: [§43](https://ucum.org/ucum#para-43)<br>(of textile thread), linear mass density – tex – tex: [§43](https://ucum.org/ucum#para-43)<br>(retired), homeopathic potency – homeopathic potency of<br> centesimal series (retired) – \[hp'\_C\]: [§44](https://ucum.org/ucum#para-44)<br>(retired),<br> homeopathic potency – homeopathic potency of decimal series (retired) – \[hp'\_X\]: [§44](https://ucum.org/ucum#para-44)<br>(retired), homeopathic potency – homeopathic potency of millesimal series<br> (retired) – \[hp'\_M\]: [§44](https://ucum.org/ucum#para-44)<br>(retired), homeopathic potency –<br> homeopathic potency of quintamillesimal series (retired) – \[hp'\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>(unclassified) – Boltzmann constant – \[k\]: [§32](https://ucum.org/ucum#para-32)<br>(unclassified) – Newtonian constant of gravitation – \[G\]: [§32](https://ucum.org/ucum#para-32)<br>50mm sum of erythema diameters, amount of an allergen<br> calibrated through in-vivo testing based on the ID50EAL method of (intradermal<br> dilution for – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>ELISA<br> unit, arbitrary – ELISA unit – \[ELU\]: [§45](https://ucum.org/ucum#para-45)<br>Ehrlich unit –<br> Ehrlich unit – \[EU\]: [§45](https://ucum.org/ucum#para-45)<br>ID50EAL method of (intradermal<br> dilution for 50mm sum of erythema diameters, amount of an allergen calibrated through in-vivo<br> testing based on the – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>IgA, biologic activity of anticardiolipin – APL unit – \[APL'U\]: [§45](https://ucum.org/ucum#para-45)<br>IgG, biologic activity of anticardiolipin – GPL unit –<br> \[GPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>IgM, biologic activity of anticardiolipin – MPL<br> unit – \[MPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>O, biologic activity antistreptolysin –<br> Todd unit – \[todd'U\]: [§45](https://ucum.org/ucum#para-45)<br>Stallergenes® method, amount of an<br> allergen calibrated through in-vivo testing using the – index of reactivity – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>VIII inhibitor, biologic activity of factor – Bethesda unit – \[beth'U\]: [§45](https://ucum.org/ucum#para-45)<br>Xa inhibitor (heparin), biologic activity of factor – anti<br> factor Xa unit – \[anti'Xa'U\]: [§45](https://ucum.org/ucum#para-45)<br>a lens, refraction of –<br> diopter – \[diop\]: [§44](https://ucum.org/ucum#para-44)<br>a poliomyelitis d-antigen substance,<br> procedure defined amount of – D-antigen unit – \[D'ag'U\]: [§45](https://ucum.org/ucum#para-45)<br>a<br> prism, refraction of – prism diopter – \[p'diop\]: [§44](https://ucum.org/ucum#para-44)<br>a<br> proliferating organism, amount of – colony forming units – \[CFU\]: [§45](https://ucum.org/ucum#para-45)<br>a protein substance, procedure defined amount of – protein nitrogen unit –<br> \[PNU\]: [§45](https://ucum.org/ucum#para-45)<br>acceleration – Gal – Gal: [§33](https://ucum.org/ucum#para-33)<br>acceleration – standard acceleration of free fall – \[g\]: [§32](https://ucum.org/ucum#para-32)<br>acidity – pH – \[pH\]: [§45](https://ucum.org/ucum#para-45)<br>action<br> area – barn – b: [§47](https://ucum.org/ucum#para-47)<br>action – Planck constant – \[h\]: [§32](https://ucum.org/ucum#para-32)<br>activity (infectivity) of an infectious agent preparation,<br> biologic – 50% cell culture infectious dose – \[CCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>activity (infectivity) of an infectious agent preparation, biologic – 50%<br> embryo infectious dose – \[EID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>activity (infectivity)<br> of an infectious agent preparation, biologic – 50% tissue culture infectious dose – \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>activity antistreptolysin O, biologic – Todd unit –<br> \[todd'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity of amylase, biologic – Dye unit –<br> \[dye'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity of amylase, biologic – Somogyi unit –<br> \[smgy'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity of anticardiolipin IgA, biologic – APL<br> unit – \[APL'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity of anticardiolipin IgG, biologic –<br> GPL unit – \[GPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity of anticardiolipin IgM,<br> biologic – MPL unit – \[MPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity of factor VIII<br> inhibitor, biologic – Bethesda unit – \[beth'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity of<br> factor Xa inhibitor (heparin), biologic – anti factor Xa unit – \[anti'Xa'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity of phosphatase, biologic – Bodansky unit – \[bdsk'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity of phosphatase, biologic – King-Armstrong unit –<br> \[ka'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity of tuberculin, biologic – tuberculin unit<br> – \[tb'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity, arbitrary biologic – Kunkel unit –<br> \[knk'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity, arbitrary biologic – Mac Lagan unit –<br> \[mclg'U\]: [§45](https://ucum.org/ucum#para-45)<br>activity, catalytic – Unit – U: [§45](https://ucum.org/ucum#para-45)<br>activity, catalytic – katal – kat: [§45](https://ucum.org/ucum#para-45)<br>activity, metabolic cost of physical – metabolic equivalent – \[MET\]: [§44](https://ucum.org/ucum#para-44)<br>agent preparation, biologic activity (infectivity) of an<br> infectious – 50% cell culture infectious dose – \[CCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>agent preparation, biologic activity (infectivity) of an infectious – 50%<br> embryo infectious dose – \[EID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>agent preparation,<br> biologic activity (infectivity) of an infectious – 50% tissue culture infectious dose – \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>agent, amount of an infectious – focus forming units –<br> \[FFU\]: [§45](https://ucum.org/ucum#para-45)<br>agent, amount of an infectious – plaque forming<br> units – \[PFU\]: [§45](https://ucum.org/ucum#para-45)<br>allergen calibrated through in-vivo testing<br> based on the ID50EAL method of (intradermal dilution for 50mm sum of erythema<br> diameters, amount of an – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>allergen calibrated through in-vivo testing using the Stallergenes® method,<br> amount of an – index of reactivity – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>allergen of<br> ragweed, procedure defined amount of the major – allergen unit for Ambrosia artemisiifolia – \[Amb'a'1'U\]:<br> [§45](https://ucum.org/ucum#para-45)<br>allergen using some reference standard, procedure defined<br> amount of an – allergen unit – \[AU\]: [§45](https://ucum.org/ucum#para-45)<br>amount of a<br> poliomyelitis d-antigen substance, procedure defined – D-antigen unit – \[D'ag'U\]: [§45](https://ucum.org/ucum#para-45)<br>amount of a proliferating organism – colony forming units – \[CFU\]: [§45](https://ucum.org/ucum#para-45)<br>amount of a protein substance, procedure defined – protein<br> nitrogen unit – \[PNU\]: [§45](https://ucum.org/ucum#para-45)<br>amount of an allergen calibrated<br> through in-vivo testing based on the ID50EAL method of (intradermal dilution for 50mm sum<br> of erythema diameters – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>amount of an allergen calibrated through in-vivo testing using the<br> Stallergenes® method – index of reactivity – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>amount<br> of an allergen using some reference standard, procedure defined – allergen unit – \[AU\]: [§45](https://ucum.org/ucum#para-45)<br>amount of an antigen substance, procedure defined – Limit<br> of flocculation – \[Lf\]: [§45](https://ucum.org/ucum#para-45)<br>amount of an infectious agent –<br> focus forming units – \[FFU\]: [§45](https://ucum.org/ucum#para-45)<br>amount of an infectious agent<br> – plaque forming units – \[PFU\]: [§45](https://ucum.org/ucum#para-45)<br>amount of fibrinogen broken<br> down into the measured d-dimers – fibrinogen equivalent unit – \[FEU\]: [§45](https://ucum.org/ucum#para-45)<br>amount of information – bit – bit: [§48](https://ucum.org/ucum#para-48)<br>amount of information – bit – bit\_s: [§48](https://ucum.org/ucum#para-48)<br>amount of information – byte – By: [§48](https://ucum.org/ucum#para-48)<br>amount of substance (dissolved particles) – osmole – osm: [§45](https://ucum.org/ucum#para-45)<br>amount of substance – equivalents – eq: [§45](https://ucum.org/ucum#para-45)<br>amount of substance – mole – mol: [§30](https://ucum.org/ucum#para-30)<br>amount of the major allergen of ragweed, procedure defined – allergen unit<br> for Ambrosia artemisiifolia – \[Amb'a'1'U\]: [§45](https://ucum.org/ucum#para-45)<br>amplitude<br> spectral density – meter per square seconds per square root of hertz – \[m/s2/Hz^(1/2)\]: [§47](https://ucum.org/ucum#para-47)<br>amylase, biologic activity of – Dye unit – \[dye'U\]: [§45](https://ucum.org/ucum#para-45)<br>amylase, biologic activity of – Somogyi unit – \[smgy'U\]: [§45](https://ucum.org/ucum#para-45)<br>an allergen calibrated through in-vivo testing based on the<br> ID50EAL method of (intradermal dilution for 50mm sum of erythema<br> diameters, amount of – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>an allergen calibrated through in-vivo testing using the Stallergenes®<br> method, amount of – index of reactivity – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>an allergen<br> using some reference standard, procedure defined amount of – allergen unit – \[AU\]: [§45](https://ucum.org/ucum#para-45)<br>an antigen substance, procedure defined amount of – Limit of flocculation –<br> \[Lf\]: [§45](https://ucum.org/ucum#para-45)<br>an infectious agent preparation, biologic activity<br> (infectivity) of – 50% cell culture infectious dose – \[CCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>an infectious agent preparation, biologic activity (infectivity) of – 50%<br> embryo infectious dose – \[EID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>an infectious agent<br> preparation, biologic activity (infectivity) of – 50% tissue culture infectious dose – \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>an infectious agent, amount of – focus forming units –<br> \[FFU\]: [§45](https://ucum.org/ucum#para-45)<br>an infectious agent, amount of – plaque forming<br> units – \[PFU\]: [§45](https://ucum.org/ucum#para-45)<br>angle, plane – circle – circ: [§47](https://ucum.org/ucum#para-47)<br>angle, plane – degree – deg: [§31](https://ucum.org/ucum#para-31)<br>angle, plane – gon grade – gon: [§31](https://ucum.org/ucum#para-31)<br>angle, plane – minute – ': [§31](https://ucum.org/ucum#para-31)<br>angle, plane – radian – rad: [§28](https://ucum.org/ucum#para-28)<br>angle, plane – second – '': [§31](https://ucum.org/ucum#para-31)<br>angle, solid – sphere – sph: [§47](https://ucum.org/ucum#para-47)<br>angle, solid – steradian – sr: [§30](https://ucum.org/ucum#para-30)<br>anticardiolipin IgA, biologic activity of – APL unit – \[APL'U\]: [§45](https://ucum.org/ucum#para-45)<br>anticardiolipin IgG, biologic activity of – GPL unit –<br> \[GPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>anticardiolipin IgM, biologic activity of – MPL<br> unit – \[MPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>antigen substance, procedure defined amount<br> of an – Limit of flocculation – \[Lf\]: [§45](https://ucum.org/ucum#para-45)<br>antistreptolysin O,<br> biologic activity – Todd unit – \[todd'U\]: [§45](https://ucum.org/ucum#para-45)<br>arbitrary ELISA<br> unit – ELISA unit – \[ELU\]: [§45](https://ucum.org/ucum#para-45)<br>arbitrary biologic activity –<br> Kunkel unit – \[knk'U\]: [§45](https://ucum.org/ucum#para-45)<br>arbitrary biologic activity – Mac<br> Lagan unit – \[mclg'U\]: [§45](https://ucum.org/ucum#para-45)<br>arbitrary – United States<br> Pharmacopeia unit – \[USP'U\]: [§45](https://ucum.org/ucum#para-45)<br>arbitrary – arbitrary unit –<br> \[arb'U\]: [§45](https://ucum.org/ucum#para-45)<br>arbitrary – international unit – \[IU\]: [§45](https://ucum.org/ucum#para-45)<br>arbitrary – international unit – \[iU\]: [§45](https://ucum.org/ucum#para-45)<br>area in microscope, view – high power field – \[HPF\]: [§45](https://ucum.org/ucum#para-45)<br>area in microscope, view – low power field – \[LPF\]: [§45](https://ucum.org/ucum#para-45)<br>area – acre – \[acr\_br\]: [§36](https://ucum.org/ucum#para-36)<br>area<br> – acre – \[acr\_us\]: [§35](https://ucum.org/ucum#para-35)<br>area – are – ar: [§31](https://ucum.org/ucum#para-31)<br>area – circular mil – \[cml\_i\]: [§34](https://ucum.org/ucum#para-34)<br>area – section – \[sct\]: [§35](https://ucum.org/ucum#para-35)<br>area<br> – square foot – \[sft\_i\]: [§34](https://ucum.org/ucum#para-34)<br>area – square inch – \[sin\_i\]: [§34](https://ucum.org/ucum#para-34)<br>area – square mile – \[smi\_us\]: [§35](https://ucum.org/ucum#para-35)<br>area – square rod – \[srd\_us\]: [§35](https://ucum.org/ucum#para-35)<br>area – square yard – \[syd\_i\]: [§34](https://ucum.org/ucum#para-34)<br>area – township – \[twp\]: [§35](https://ucum.org/ucum#para-35)<br>area, action – barn – b: [§47](https://ucum.org/ucum#para-47)<br>attenuation, x-ray – Hounsfield unit – \[hnsf'U\]: [§44](https://ucum.org/ucum#para-44)<br>based on the ID50EAL method of (intradermal dilution for 50mm sum of<br> erythema diameters, amount of an allergen calibrated<br> through in-vivo testing – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity (infectivity) of an infectious agent preparation – 50%<br> cell culture infectious dose – \[CCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity<br> (infectivity) of an infectious agent preparation – 50% embryo infectious dose – \[EID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity (infectivity) of an infectious agent<br> preparation – 50% tissue culture infectious dose – \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity antistreptolysin O – Todd unit – \[todd'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity of amylase – Dye unit – \[dye'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity of amylase – Somogyi unit – \[smgy'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity of anticardiolipin IgA – APL unit –<br> \[APL'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity of anticardiolipin IgG – GPL<br> unit – \[GPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity of anticardiolipin IgM –<br> MPL unit – \[MPL'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity of factor VIII<br> inhibitor – Bethesda unit – \[beth'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity of<br> factor Xa inhibitor (heparin) – anti factor Xa unit – \[anti'Xa'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity of phosphatase – Bodansky unit – \[bdsk'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity of phosphatase – King-Armstrong unit –<br> \[ka'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity of tuberculin – tuberculin unit –<br> \[tb'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity, arbitrary – Kunkel unit –<br> \[knk'U\]: [§45](https://ucum.org/ucum#para-45)<br>biologic activity, arbitrary – Mac Lagan unit –<br> \[mclg'U\]: [§45](https://ucum.org/ucum#para-45)<br>brightness – Lambert – Lmb: [§33](https://ucum.org/ucum#para-33)<br>broken down into the measured d-dimers, amount of fibrinogen – fibrinogen<br> equivalent unit – \[FEU\]: [§45](https://ucum.org/ucum#para-45)<br>calibrated through in-vivo testing<br> based on the ID50EAL method of (intradermal dilution for 50mm sum of erythema diameters,<br> amount of an allergen – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>calibrated through in-vivo testing using the Stallergenes® method, amount<br> of an allergen – index of reactivity – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>capacitance,<br> electric – farad – F: [§30](https://ucum.org/ucum#para-30)<br>catalytic activity – Unit – U: [§45](https://ucum.org/ucum#para-45)<br>catalytic activity – katal – kat: [§45](https://ucum.org/ucum#para-45)<br>catheters, gauge of – Charrière french – \[Ch\]: [§44](https://ucum.org/ucum#para-44)<br>charge, electric – coulomb – C: [§28](https://ucum.org/ucum#para-28)<br>charge, electric – elementary charge – \[e\]: [§32](https://ucum.org/ucum#para-32)<br>coefficient, sedimentation – Svedberg unit – \[S\]: [§45](https://ucum.org/ucum#para-45)<br>concentration, mass – gram percent – g%: [§45](https://ucum.org/ucum#para-45)<br>conductance, electric – mho – mho: [§47](https://ucum.org/ucum#para-47)<br>conductance, electric – siemens – S: [§30](https://ucum.org/ucum#para-30)<br>cost of physical activity, metabolic – metabolic equivalent – \[MET\]: [§44](https://ucum.org/ucum#para-44)<br>current, electric – Biot – Bi: [§33](https://ucum.org/ucum#para-33)<br>current, electric – ampère – A: [§30](https://ucum.org/ucum#para-30)<br>d-antigen substance, procedure defined amount of a poliomyelitis –<br> D-antigen unit – \[D'ag'U\]: [§45](https://ucum.org/ucum#para-45)<br>d-dimers, amount of fibrinogen<br> broken down into the measured – fibrinogen equivalent unit – \[FEU\]: [§45](https://ucum.org/ucum#para-45)<br>defined amount of a poliomyelitis d-antigen substance, procedure –<br> D-antigen unit – \[D'ag'U\]: [§45](https://ucum.org/ucum#para-45)<br>defined amount of a protein<br> substance, procedure – protein nitrogen unit – \[PNU\]: [§45](https://ucum.org/ucum#para-45)<br>defined amount of an allergen using some reference standard, procedure –<br> allergen unit – \[AU\]: [§45](https://ucum.org/ucum#para-45)<br>defined amount of an antigen<br> substance, procedure – Limit of flocculation – \[Lf\]: [§45](https://ucum.org/ucum#para-45)<br>defined amount of the major allergen of ragweed, procedure – allergen unit<br> for Ambrosia artemisiifolia – \[Amb'a'1'U\]: [§45](https://ucum.org/ucum#para-45)<br>density (of<br> textile thread), linear mass – Denier – \[den\]: [§43](https://ucum.org/ucum#para-43)<br>density (of<br> textile thread), linear mass – tex – tex: [§43](https://ucum.org/ucum#para-43)<br>density,<br> amplitude spectral – meter per square seconds per square root of hertz – \[m/s2/Hz^(1/2)\]: [§47](https://ucum.org/ucum#para-47)<br>density, lum. intensity – stilb – sb: [§33](https://ucum.org/ucum#para-33)<br>density, magnetic flux – Gauss – G: [§33](https://ucum.org/ucum#para-33)<br>density, magnetic flux – tesla – T: [§30](https://ucum.org/ucum#para-30)<br>depth of water – fathom – \[fth\_i\]: [§34](https://ucum.org/ucum#para-34)<br>diameters, amount of an allergen calibrated through in-vivo testing based<br> on the ID50EAL method of (intradermal dilution<br> for 50mm sum of erythema – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>dilution for 50mm sum of erythema diameters, amount of an allergen<br> calibrated through in-vivo testing based on the ID50EAL<br> method of (intradermal – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>dose equivalent – radiation equivalent man – REM: [§33](https://ucum.org/ucum#para-33)<br>dose equivalent – sievert – Sv: [§30](https://ucum.org/ucum#para-30)<br>dose, energy – gray – Gy: [§30](https://ucum.org/ucum#para-30)<br>dose, energy – radiation absorbed dose – RAD: [§33](https://ucum.org/ucum#para-33)<br>dose, ion – Roentgen – R: [§33](https://ucum.org/ucum#para-33)<br>down into the measured d-dimers, amount of fibrinogen broken – fibrinogen<br> equivalent unit – \[FEU\]: [§45](https://ucum.org/ucum#para-45)<br>dry volume – bushel – \[bu\_us\]: [§37](https://ucum.org/ucum#para-37)<br>dry volume – dry pint – \[dpt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>dry volume – dry quart – \[dqt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>dry volume – historical winchester gallon – \[gal\_wi\]: [§37](https://ucum.org/ucum#para-37)<br>dry volume – peck – \[pk\_us\]: [§37](https://ucum.org/ucum#para-37)<br>dynamic viscosity – Poise – P: [§33](https://ucum.org/ucum#para-33)<br>electric capacitance – farad – F: [§30](https://ucum.org/ucum#para-30)<br>electric charge – coulomb – C: [§28](https://ucum.org/ucum#para-28)<br>electric charge – elementary charge – \[e\]: [§32](https://ucum.org/ucum#para-32)<br>electric conductance – mho – mho: [§47](https://ucum.org/ucum#para-47)<br>electric conductance – siemens – S: [§30](https://ucum.org/ucum#para-30)<br>electric current – Biot – Bi: [§33](https://ucum.org/ucum#para-33)<br>electric current – ampère – A: [§30](https://ucum.org/ucum#para-30)<br>electric permittivity – permittivity of vacuum – \[eps\_0\]: [§32](https://ucum.org/ucum#para-32)<br>electric potential level – bel 10 nanovolt – B\[10.nV\]: [§46](https://ucum.org/ucum#para-46)<br>electric potential level – bel microvolt – B\[uV\]: [§46](https://ucum.org/ucum#para-46)<br>electric potential level – bel millivolt – B\[mV\]: [§46](https://ucum.org/ucum#para-46)<br>electric potential level – bel volt – B\[V\]: [§46](https://ucum.org/ucum#para-46)<br>electric potential – volt – V: [§30](https://ucum.org/ucum#para-30)<br>electric resistance – ohm – Ohm: [§30](https://ucum.org/ucum#para-30)<br>energy dose – gray – Gy: [§30](https://ucum.org/ucum#para-30)<br>energy dose – radiation absorbed dose – RAD: [§33](https://ucum.org/ucum#para-33)<br>energy – British thermal unit at 39 °F – \[Btu\_39\]: [§43](https://ucum.org/ucum#para-43)<br>energy – British thermal unit at 59 °F – \[Btu\_59\]: [§43](https://ucum.org/ucum#para-43)<br>energy – British thermal unit at 60 °F – \[Btu\_60\]: [§43](https://ucum.org/ucum#para-43)<br>energy – British thermal unit – \[Btu\]: [§43](https://ucum.org/ucum#para-43)<br>energy – calorie at 15 °C – cal\_\[15\]: [§43](https://ucum.org/ucum#para-43)<br>energy – calorie at 20 °C – cal\_\[20\]: [§43](https://ucum.org/ucum#para-43)<br>energy – calorie – cal: [§43](https://ucum.org/ucum#para-43)<br>energy – electronvolt – eV: [§31](https://ucum.org/ucum#para-31)<br>energy – erg – erg: [§33](https://ucum.org/ucum#para-33)<br>energy –<br> international table British thermal unit – \[Btu\_IT\]: [§43](https://ucum.org/ucum#para-43)<br>energy<br> – international table calorie – cal\_IT: [§43](https://ucum.org/ucum#para-43)<br>energy – joule – J:<br> [§30](https://ucum.org/ucum#para-30)<br>energy – mean British thermal unit – \[Btu\_m\]: [§43](https://ucum.org/ucum#para-43)<br>energy – mean calorie – cal\_m: [§43](https://ucum.org/ucum#para-43)<br>energy – nutrition label Calories – \[Cal\]: [§43](https://ucum.org/ucum#para-43)<br>energy – thermochemical British thermal unit – \[Btu\_th\]: [§43](https://ucum.org/ucum#para-43)<br>energy – thermochemical calorie – cal\_th: [§43](https://ucum.org/ucum#para-43)<br>equivalent, dose – radiation equivalent man – REM: [§33](https://ucum.org/ucum#para-33)<br>equivalent, dose – sievert – Sv: [§30](https://ucum.org/ucum#para-30)<br>erythema diameters, amount of an allergen calibrated through in-vivo<br> testing based on the ID50EAL method of (intradermal<br> dilution for 50mm sum of – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>factor VIII inhibitor, biologic activity of – Bethesda unit – \[beth'U\]: [§45](https://ucum.org/ucum#para-45)<br>factor Xa inhibitor (heparin), biologic activity of – anti<br> factor Xa unit – \[anti'Xa'U\]: [§45](https://ucum.org/ucum#para-45)<br>fibrinogen broken down into<br> the measured d-dimers, amount of – fibrinogen equivalent unit – \[FEU\]: [§45](https://ucum.org/ucum#para-45)<br>field intensity, magnetic – Oersted – Oe: [§33](https://ucum.org/ucum#para-33)<br>fluid resistance – Wood unit – \[wood'U\]: [§44](https://ucum.org/ucum#para-44)<br>fluid resistance – peripheral vascular resistance unit – \[PRU\]: [§44](https://ucum.org/ucum#para-44)<br>fluid volume – Queen Anne's wine gallon – \[gal\_us\]: [§37](https://ucum.org/ucum#para-37)<br>fluid volume – barrel – \[bbl\_us\]: [§37](https://ucum.org/ucum#para-37)<br>fluid volume – cord – \[crd\_us\]: [§37](https://ucum.org/ucum#para-37)<br>fluid volume – fluid dram – \[fdr\_us\]: [§37](https://ucum.org/ucum#para-37)<br>fluid volume – fluid ounce – \[foz\_us\]: [§37](https://ucum.org/ucum#para-37)<br>fluid volume – gill – \[gil\_us\]: [§37](https://ucum.org/ucum#para-37)<br>fluid volume – metric fluid ounce – \[foz\_m\]: [§37](https://ucum.org/ucum#para-37)<br>fluid volume – minim – \[min\_us\]: [§37](https://ucum.org/ucum#para-37)<br>fluid volume – pint – \[pt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>fluid volume – quart – \[qt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>flux density, magnetic – Gauss – G: [§33](https://ucum.org/ucum#para-33)<br>flux density, magnetic – tesla – T: [§30](https://ucum.org/ucum#para-30)<br>flux of magnetic induction – Maxwell – Mx: [§33](https://ucum.org/ucum#para-33)<br>flux, luminous – lumen – lm: [§30](https://ucum.org/ucum#para-30)<br>flux, magnetic – weber – Wb: [§30](https://ucum.org/ucum#para-30)<br>force – dyne – dyn: [§33](https://ucum.org/ucum#para-33)<br>force –<br> gram-force – gf: [§32](https://ucum.org/ucum#para-32)<br>force – newton – N: [§30](https://ucum.org/ucum#para-30)<br>force – pound force – \[lbf\_av\]: [§32](https://ucum.org/ucum#para-32)<br>fraction – parts per billion – \[ppb\]: [§29](https://ucum.org/ucum#para-29)<br>fraction – parts per million – \[ppm\]: [§29](https://ucum.org/ucum#para-29)<br>fraction – parts per thousand – \[ppth\]: [§29](https://ucum.org/ucum#para-29)<br>fraction – parts per trillion – \[pptr\]: [§29](https://ucum.org/ucum#para-29)<br>fraction – percent – %: [§29](https://ucum.org/ucum#para-29)<br>fraction, mass – carat of gold alloys – \[car\_Au\]: [§47](https://ucum.org/ucum#para-47)<br>frequency – hertz – Hz: [§30](https://ucum.org/ucum#para-30)<br>gauge<br> of catheters – Charrière french – \[Ch\]: [§44](https://ucum.org/ucum#para-44)<br>height of horses –<br> hand – \[hd\_i\]: [§34](https://ucum.org/ucum#para-34)<br>homeopathic potency (Hahnemann) –<br> homeopathic potency of centesimal hahnemannian series – \[hp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency (Hahnemann) – homeopathic potency of decimal<br> hahnemannian series – \[hp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency<br> (Hahnemann) – homeopathic potency of millesimal hahnemannian series – \[hp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency (Hahnemann) – homeopathic potency of quintamillesimal<br> hahnemannian series – \[hp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency<br> (Korsakov) – homeopathic potency of centesimal korsakovian series – \[kp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency (Korsakov) – homeopathic potency of decimal korsakovian<br> series – \[kp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency (Korsakov) –<br> homeopathic potency of millesimal korsakovian series – \[kp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency (Korsakov) – homeopathic potency of quintamillesimal<br> korsakovian series – \[kp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency (retired)<br> – homeopathic potency of centesimal series (retired) – \[hp'\_C\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency (retired) – homeopathic potency of decimal series<br> (retired) – \[hp'\_X\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency (retired) –<br> homeopathic potency of millesimal series (retired) – \[hp'\_M\]: [§44](https://ucum.org/ucum#para-44)<br>homeopathic potency (retired) – homeopathic potency of quintamillesimal<br> series (retired) – \[hp'\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>horses, height of – hand –<br> \[hd\_i\]: [§34](https://ucum.org/ucum#para-34)<br>illuminance – lux – lx: [§30](https://ucum.org/ucum#para-30)<br>illuminance – phot – ph: [§33](https://ucum.org/ucum#para-33)<br>in<br> microscope, view area – high power field – \[HPF\]: [§45](https://ucum.org/ucum#para-45)<br>in<br> microscope, view area – low power field – \[LPF\]: [§45](https://ucum.org/ucum#para-45)<br>in-vivo<br> testing based on the ID50EAL method of (intradermal dilution for 50mm sum of erythema diameters, amount<br> of an allergen<br> calibrated through – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>in-vivo testing using the Stallergenes® method, amount of an allergen<br> calibrated through – index of reactivity – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>inductance<br> – henry – H: [§30](https://ucum.org/ucum#para-30)<br>induction, flux of magnetic – Maxwell – Mx: [§33](https://ucum.org/ucum#para-33)<br>infectious agent preparation, biologic activity<br> (infectivity) of an – 50% cell culture infectious dose – \[CCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>infectious agent preparation, biologic activity (infectivity) of an – 50%<br> embryo infectious dose – \[EID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>infectious agent<br> preparation, biologic activity (infectivity) of an – 50% tissue culture infectious dose – \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>infectious agent, amount of an – focus forming units –<br> \[FFU\]: [§45](https://ucum.org/ucum#para-45)<br>infectious agent, amount of an – plaque forming<br> units – \[PFU\]: [§45](https://ucum.org/ucum#para-45)<br>information, amount of – bit – bit: [§48](https://ucum.org/ucum#para-48) |  | information, amount of – bit – bit\_s: [§48](https://ucum.org/ucum#para-48)<br>information, amount of – byte – By: [§48](https://ucum.org/ucum#para-48)<br>inhibitor (heparin), biologic activity of factor Xa – anti factor Xa unit –<br> \[anti'Xa'U\]: [§45](https://ucum.org/ucum#para-45)<br>inhibitor, biologic activity of factor VIII –<br> Bethesda unit – \[beth'U\]: [§45](https://ucum.org/ucum#para-45)<br>intensity density, lum. – stilb –<br> sb: [§33](https://ucum.org/ucum#para-33)<br>intensity, luminous – candela – cd: [§28](https://ucum.org/ucum#para-28)<br>intensity, magnetic field – Oersted – Oe: [§33](https://ucum.org/ucum#para-33)<br>into the measured d-dimers, amount of fibrinogen broken down – fibrinogen<br> equivalent unit – \[FEU\]: [§45](https://ucum.org/ucum#para-45)<br>ion dose – Roentgen – R: [§33](https://ucum.org/ucum#para-33)<br>kinematic viscosity – Stokes – St: [§33](https://ucum.org/ucum#para-33)<br>length – Gunter's chain Surveyor's chain – \[ch\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – Gunter's chain – \[ch\_br\]: [§36](https://ucum.org/ucum#para-36)<br>length – Printer's pica – \[pca\_pr\]: [§42](https://ucum.org/ucum#para-42)<br>length – Printer's point – \[pnt\_pr\]: [§42](https://ucum.org/ucum#para-42)<br>length – Ramden's chain Engineer's chain – \[rch\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – Smoot – \[smoot\]: [§47](https://ucum.org/ucum#para-47)<br>length – astronomic unit – AU: [§31](https://ucum.org/ucum#para-31)<br>length – cicero Didot's pica – \[cicero\]: [§42](https://ucum.org/ucum#para-42)<br>length – didot Didot's point – \[didot\]: [§42](https://ucum.org/ucum#para-42)<br>length – fathom – \[fth\_br\]: [§36](https://ucum.org/ucum#para-36)<br>length – fathom – \[fth\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – foot – \[ft\_br\]: [§36](https://ucum.org/ucum#para-36)<br>length – foot – \[ft\_i\]: [§34](https://ucum.org/ucum#para-34)<br>length – foot – \[ft\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – furlong – \[fur\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – inch – \[in\_br\]: [§36](https://ucum.org/ucum#para-36)<br>length – inch – \[in\_i\]: [§34](https://ucum.org/ucum#para-34)<br>length – inch – \[in\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – light-year – \[ly\]: [§32](https://ucum.org/ucum#para-32)<br>length – ligne French line – \[ligne\]: [§42](https://ucum.org/ucum#para-42)<br>length – line – \[lne\]: [§42](https://ucum.org/ucum#para-42)<br>length<br> – link for Gunter's chain – \[lk\_br\]: [§36](https://ucum.org/ucum#para-36)<br>length – link for<br> Gunter's chain – \[lk\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – link for Ramden's chain<br> – \[rlk\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – meter – m: [§28](https://ucum.org/ucum#para-28)<br>length – mil – \[mil\_i\]: [§34](https://ucum.org/ucum#para-34)<br>length – mil – \[mil\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – mile – \[mi\_br\]: [§36](https://ucum.org/ucum#para-36)<br>length – mile – \[mi\_i\]: [§34](https://ucum.org/ucum#para-34)<br>length – mile – \[mi\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – nautical mile – \[nmi\_br\]: [§36](https://ucum.org/ucum#para-36)<br>length – nautical mile – \[nmi\_i\]: [§34](https://ucum.org/ucum#para-34)<br>length – pace – \[pc\_br\]: [§36](https://ucum.org/ucum#para-36)<br>length – parsec – pc: [§31](https://ucum.org/ucum#para-31)<br>length<br> – pica – \[pca\]: [§42](https://ucum.org/ucum#para-42)<br>length – pied French foot – \[pied\]: [§42](https://ucum.org/ucum#para-42)<br>length – point – \[pnt\]: [§42](https://ucum.org/ucum#para-42)<br>length – pouce French inch – \[pouce\]: [§42](https://ucum.org/ucum#para-42)<br>length – rod – \[rd\_br\]: [§36](https://ucum.org/ucum#para-36)<br>length – rod – \[rd\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – yard – \[yd\_br\]: [§36](https://ucum.org/ucum#para-36)<br>length – yard – \[yd\_i\]: [§34](https://ucum.org/ucum#para-34)<br>length – yard – \[yd\_us\]: [§35](https://ucum.org/ucum#para-35)<br>length – Ångström – Ao: [§47](https://ucum.org/ucum#para-47)<br>lens,<br> refraction of a – diopter – \[diop\]: [§44](https://ucum.org/ucum#para-44)<br>level – bel – B: [§46](https://ucum.org/ucum#para-46)<br>level – neper – Np: [§46](https://ucum.org/ucum#para-46)<br>level, electric potential – bel 10 nanovolt – B\[10.nV\]: [§46](https://ucum.org/ucum#para-46)<br>level, electric potential – bel microvolt – B\[uV\]: [§46](https://ucum.org/ucum#para-46)<br>level, electric potential – bel millivolt – B\[mV\]: [§46](https://ucum.org/ucum#para-46)<br>level, electric potential – bel volt – B\[V\]: [§46](https://ucum.org/ucum#para-46)<br>level, power – bel kilowatt – B\[kW\]: [§46](https://ucum.org/ucum#para-46)<br>level, power – bel watt – B\[W\]: [§46](https://ucum.org/ucum#para-46)<br>level, pressure – bel sound pressure – B\[SPL\]: [§46](https://ucum.org/ucum#para-46)<br>linear mass density (of textile thread) – Denier – \[den\]: [§43](https://ucum.org/ucum#para-43)<br>linear mass density (of textile thread) – tex – tex: [§43](https://ucum.org/ucum#para-43)<br>lineic number – Kayser – Ky: [§33](https://ucum.org/ucum#para-33)<br>lineic number – mesh – \[mesh\_i\]: [§44](https://ucum.org/ucum#para-44)<br>lum. intensity density – stilb – sb: [§33](https://ucum.org/ucum#para-33)<br>luminous flux – lumen – lm: [§30](https://ucum.org/ucum#para-30)<br>luminous intensity – candela – cd: [§28](https://ucum.org/ucum#para-28)<br>magnetic field intensity – Oersted – Oe: [§33](https://ucum.org/ucum#para-33)<br>magnetic flux density – Gauss – G: [§33](https://ucum.org/ucum#para-33)<br>magnetic flux density – tesla – T: [§30](https://ucum.org/ucum#para-30)<br>magnetic flux – weber – Wb: [§30](https://ucum.org/ucum#para-30)<br>magnetic induction, flux of – Maxwell – Mx: [§33](https://ucum.org/ucum#para-33)<br>magnetic permeability – permeability of vacuum – \[mu\_0\]: [§32](https://ucum.org/ucum#para-32)<br>magnetic tension – Gilbert – Gb: [§33](https://ucum.org/ucum#para-33)<br>major allergen of ragweed, procedure defined amount of the – allergen unit<br> for Ambrosia artemisiifolia – \[Amb'a'1'U\]: [§45](https://ucum.org/ucum#para-45)<br>mass<br> concentration – gram percent – g%: [§45](https://ucum.org/ucum#para-45)<br>mass density (of textile<br> thread), linear – Denier – \[den\]: [§43](https://ucum.org/ucum#para-43)<br>mass density (of textile<br> thread), linear – tex – tex: [§43](https://ucum.org/ucum#para-43)<br>mass fraction – carat of gold<br> alloys – \[car\_Au\]: [§47](https://ucum.org/ucum#para-47)<br>mass – dram drachm – \[dr\_ap\]: [§41](https://ucum.org/ucum#para-41)<br>mass – dram – \[dr\_av\]: [§39](https://ucum.org/ucum#para-39)<br>mass – electron mass – \[m\_e\]: [§32](https://ucum.org/ucum#para-32)<br>mass – grain – \[gr\]: [§39](https://ucum.org/ucum#para-39)<br>mass –<br> gram – g: [§28](https://ucum.org/ucum#para-28)<br>mass – kilogram of wet tissue – kg{wet'tis}: [§50](https://ucum.org/ucum#para-50)<br>mass – long hundredweight British hundredweight –<br> \[lcwt\_av\]: [§39](https://ucum.org/ucum#para-39)<br>mass – long ton British ton – \[lton\_av\]: [§39](https://ucum.org/ucum#para-39)<br>mass – metric carat – \[car\_m\]: [§47](https://ucum.org/ucum#para-47)<br>mass – metric ounce – \[oz\_m\]: [§41](https://ucum.org/ucum#para-41)<br>mass – milligram of creatinine – mg{creat}: [§50](https://ucum.org/ucum#para-50)<br>mass – ounce – \[oz\_ap\]: [§41](https://ucum.org/ucum#para-41)<br>mass<br> – ounce – \[oz\_av\]: [§39](https://ucum.org/ucum#para-39)<br>mass – ounce – \[oz\_tr\]: [§40](https://ucum.org/ucum#para-40)<br>mass – pennyweight – \[pwt\_tr\]: [§40](https://ucum.org/ucum#para-40)<br>mass – pound – \[lb\_ap\]: [§41](https://ucum.org/ucum#para-41)<br>mass<br> – pound – \[lb\_av\]: [§39](https://ucum.org/ucum#para-39)<br>mass – pound – \[lb\_tr\]: [§40](https://ucum.org/ucum#para-40)<br>mass – proton mass – \[m\_p\]: [§32](https://ucum.org/ucum#para-32)<br>mass – scruple – \[sc\_ap\]: [§41](https://ucum.org/ucum#para-41)<br>mass – short hundredweight U.S. hundredweight – \[scwt\_av\]: [§39](https://ucum.org/ucum#para-39)<br>mass – short ton U.S. ton – \[ston\_av\]: [§39](https://ucum.org/ucum#para-39)<br>mass – stone British stone – \[stone\_av\]: [§39](https://ucum.org/ucum#para-39)<br>mass – tonne – t: [§31](https://ucum.org/ucum#para-31)<br>mass –<br> unified atomic mass unit – u: [§31](https://ucum.org/ucum#para-31)<br>measured d-dimers, amount of<br> fibrinogen broken down into the – fibrinogen equivalent unit – \[FEU\]: [§45](https://ucum.org/ucum#para-45)<br>metabolic cost of physical activity – metabolic equivalent – \[MET\]: [§44](https://ucum.org/ucum#para-44)<br>method of (intradermal dilution for 50mm sum of erythema<br> diameters, amount of an allergen calibrated through in-vivo testing<br> based on the ID50EAL – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>method, amount of an allergen calibrated through in-vivo testing using the<br> Stallergenes® – index of reactivity – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>microscope,<br> view area in – high power field – \[HPF\]: [§45](https://ucum.org/ucum#para-45)<br>microscope, view<br> area in – low power field – \[LPF\]: [§45](https://ucum.org/ucum#para-45)<br>number – particles total<br> count – {tot}: [§50](https://ucum.org/ucum#para-50)<br>number – red blood cell count – {rbc}: [§50](https://ucum.org/ucum#para-50)<br>number – tablets – {tbl}: [§50](https://ucum.org/ucum#para-50)<br>number – the number pi – \[pi\]: [§29](https://ucum.org/ucum#para-29)<br>number – the number ten for arbitrary powers – 10\*: [§29](https://ucum.org/ucum#para-29)<br>number – the number ten for arbitrary powers – 10^: [§29](https://ucum.org/ucum#para-29)<br>number, lineic – Kayser – Ky: [§33](https://ucum.org/ucum#para-33)<br>number, lineic – mesh – \[mesh\_i\]: [§44](https://ucum.org/ucum#para-44)<br>on the ID50EAL method of (intradermal dilution for 50mm sum of erythema<br> diameters, amount of an allergen calibrated through<br> in-vivo testing based – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>organism, amount of a proliferating – colony forming units – \[CFU\]: [§45](https://ucum.org/ucum#para-45)<br>particles), amount of substance (dissolved – osmole – osm:<br> [§45](https://ucum.org/ucum#para-45)<br>permeability, magnetic – permeability of vacuum – \[mu\_0\]:<br> [§32](https://ucum.org/ucum#para-32)<br>permittivity, electric – permittivity of vacuum – \[eps\_0\]:<br> [§32](https://ucum.org/ucum#para-32)<br>phosphatase, biologic activity of – Bodansky unit –<br> \[bdsk'U\]: [§45](https://ucum.org/ucum#para-45)<br>phosphatase, biologic activity of –<br> King-Armstrong unit – \[ka'U\]: [§45](https://ucum.org/ucum#para-45)<br>physical activity, metabolic<br> cost of – metabolic equivalent – \[MET\]: [§44](https://ucum.org/ucum#para-44)<br>plane angle –<br> circle – circ: [§47](https://ucum.org/ucum#para-47)<br>plane angle – degree – deg: [§31](https://ucum.org/ucum#para-31)<br>plane angle – gon grade – gon: [§31](https://ucum.org/ucum#para-31)<br>plane angle – minute – ': [§31](https://ucum.org/ucum#para-31)<br>plane angle – radian – rad: [§28](https://ucum.org/ucum#para-28)<br>plane angle – second – '': [§31](https://ucum.org/ucum#para-31)<br>poliomyelitis d-antigen substance, procedure defined amount of a –<br> D-antigen unit – \[D'ag'U\]: [§45](https://ucum.org/ucum#para-45)<br>potency (Hahnemann), homeopathic<br> – homeopathic potency of centesimal hahnemannian series – \[hp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>potency (Hahnemann), homeopathic – homeopathic potency of decimal<br> hahnemannian series – \[hp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>potency (Hahnemann),<br> homeopathic – homeopathic potency of millesimal hahnemannian series – \[hp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>potency (Hahnemann), homeopathic – homeopathic potency of quintamillesimal<br> hahnemannian series – \[hp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>potency (Korsakov),<br> homeopathic – homeopathic potency of centesimal korsakovian series – \[kp\_C\]: [§44](https://ucum.org/ucum#para-44)<br>potency (Korsakov), homeopathic – homeopathic potency of decimal<br> korsakovian series – \[kp\_X\]: [§44](https://ucum.org/ucum#para-44)<br>potency (Korsakov),<br> homeopathic – homeopathic potency of millesimal korsakovian series – \[kp\_M\]: [§44](https://ucum.org/ucum#para-44)<br>potency (Korsakov), homeopathic – homeopathic potency of quintamillesimal<br> korsakovian series – \[kp\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>potency (retired), homeopathic<br> – homeopathic potency of centesimal series (retired) – \[hp'\_C\]: [§44](https://ucum.org/ucum#para-44)<br>potency (retired), homeopathic – homeopathic potency of decimal series<br> (retired) – \[hp'\_X\]: [§44](https://ucum.org/ucum#para-44)<br>potency (retired), homeopathic –<br> homeopathic potency of millesimal series (retired) – \[hp'\_M\]: [§44](https://ucum.org/ucum#para-44)<br>potency (retired), homeopathic – homeopathic potency of quintamillesimal<br> series (retired) – \[hp'\_Q\]: [§44](https://ucum.org/ucum#para-44)<br>potential level, electric – bel<br> 10 nanovolt – B\[10.nV\]: [§46](https://ucum.org/ucum#para-46)<br>potential level, electric – bel<br> microvolt – B\[uV\]: [§46](https://ucum.org/ucum#para-46)<br>potential level, electric – bel<br> millivolt – B\[mV\]: [§46](https://ucum.org/ucum#para-46)<br>potential level, electric – bel volt –<br> B\[V\]: [§46](https://ucum.org/ucum#para-46)<br>potential, electric – volt – V: [§30](https://ucum.org/ucum#para-30)<br>power level – bel kilowatt – B\[kW\]: [§46](https://ucum.org/ucum#para-46)<br>power level – bel watt – B\[W\]: [§46](https://ucum.org/ucum#para-46)<br>power – horsepower – \[HP\]: [§43](https://ucum.org/ucum#para-43)<br>power – watt – W: [§30](https://ucum.org/ucum#para-30)<br>preparation, biologic activity (infectivity) of an infectious agent – 50%<br> cell culture infectious dose – \[CCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>preparation,<br> biologic activity (infectivity) of an infectious agent – 50% embryo infectious dose – \[EID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>preparation, biologic activity (infectivity) of an<br> infectious agent – 50% tissue culture infectious dose – \[TCID\_50\]: [§45](https://ucum.org/ucum#para-45)<br>pressure level – bel sound pressure – B\[SPL\]: [§46](https://ucum.org/ucum#para-46)<br>pressure – bar – bar: [§31](https://ucum.org/ucum#para-31)<br>pressure – inch of mercury column – \[in\_i'Hg\]: [§44](https://ucum.org/ucum#para-44)<br>pressure – inch of water column – \[in\_i'H2O\]: [§44](https://ucum.org/ucum#para-44)<br>pressure – meter of mercury column – m\[Hg\]: [§44](https://ucum.org/ucum#para-44)<br>pressure – meter of water column – m\[H2O\]: [§44](https://ucum.org/ucum#para-44)<br>pressure – pascal – Pa: [§30](https://ucum.org/ucum#para-30)<br>pressure – pound per square inch – \[psi\]: [§47](https://ucum.org/ucum#para-47)<br>pressure – standard atmosphere – atm: [§32](https://ucum.org/ucum#para-32)<br>pressure – technical atmosphere – att: [§47](https://ucum.org/ucum#para-47)<br>prism, refraction of a – prism diopter – \[p'diop\]: [§44](https://ucum.org/ucum#para-44)<br>procedure defined amount of a poliomyelitis d-antigen substance – D-antigen<br> unit – \[D'ag'U\]: [§45](https://ucum.org/ucum#para-45)<br>procedure defined amount of a protein<br> substance – protein nitrogen unit – \[PNU\]: [§45](https://ucum.org/ucum#para-45)<br>procedure<br> defined amount of an allergen using some reference standard – allergen unit – \[AU\]: [§45](https://ucum.org/ucum#para-45)<br>procedure defined amount of an antigen substance – Limit of flocculation –<br> \[Lf\]: [§45](https://ucum.org/ucum#para-45)<br>procedure defined amount of the major allergen of<br> ragweed – allergen unit for Ambrosia artemisiifolia – \[Amb'a'1'U\]: [§45](https://ucum.org/ucum#para-45)<br>proliferating organism, amount of a – colony forming units – \[CFU\]: [§45](https://ucum.org/ucum#para-45)<br>proportional to ventricular stroke work – gram meter per<br> heartbeat – g.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>protein substance, procedure<br> defined amount of a – protein nitrogen unit – \[PNU\]: [§45](https://ucum.org/ucum#para-45)<br>radioactivity – Curie – Ci: [§33](https://ucum.org/ucum#para-33)<br>radioactivity – becquerel – Bq: [§30](https://ucum.org/ucum#para-30)<br>ragweed, procedure defined amount of the major allergen of – allergen unit<br> for Ambrosia artemisiifolia – \[Amb'a'1'U\]: [§45](https://ucum.org/ucum#para-45)<br>rate, signal<br> transmission – baud – Bd: [§48](https://ucum.org/ucum#para-48)<br>reference standard, procedure<br> defined amount of an allergen using some – allergen unit – \[AU\]: [§45](https://ucum.org/ucum#para-45)<br>refraction of a lens – diopter – \[diop\]: [§44](https://ucum.org/ucum#para-44)<br>refraction of a prism – prism diopter – \[p'diop\]: [§44](https://ucum.org/ucum#para-44)<br>resistance, electric – ohm – Ohm: [§30](https://ucum.org/ucum#para-30)<br>resistance, fluid – Wood unit – \[wood'U\]: [§44](https://ucum.org/ucum#para-44)<br>resistance, fluid – peripheral vascular resistance unit – \[PRU\]: [§44](https://ucum.org/ucum#para-44)<br>sedimentation coefficient – Svedberg unit – \[S\]: [§45](https://ucum.org/ucum#para-45)<br>signal transmission rate – baud – Bd: [§48](https://ucum.org/ucum#para-48)<br>slope – percent of slope – %\[slope\]: [§44](https://ucum.org/ucum#para-44)<br>solid angle – sphere – sph: [§47](https://ucum.org/ucum#para-47)<br>solid angle – steradian – sr: [§30](https://ucum.org/ucum#para-30)<br>some reference standard, procedure defined amount of an allergen using –<br> allergen unit – \[AU\]: [§45](https://ucum.org/ucum#para-45)<br>spectral density, amplitude – meter<br> per square seconds per square root of hertz – \[m/s2/Hz^(1/2)\]: [§47](https://ucum.org/ucum#para-47)<br>standard, procedure defined amount of an allergen using some reference –<br> allergen unit – \[AU\]: [§45](https://ucum.org/ucum#para-45)<br>stroke work, proportional to<br> ventricular – gram meter per heartbeat – g.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>stroke<br> work, ventricular – gram-force meter per heartbeat – gf.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>substance (dissolved particles), amount of – osmole – osm: [§45](https://ucum.org/ucum#para-45)<br>substance, amount of – equivalents – eq: [§45](https://ucum.org/ucum#para-45)<br>substance, amount of – mole – mol: [§30](https://ucum.org/ucum#para-30)<br>substance, procedure defined amount of a poliomyelitis d-antigen –<br> D-antigen unit – \[D'ag'U\]: [§45](https://ucum.org/ucum#para-45)<br>substance, procedure defined<br> amount of a protein – protein nitrogen unit – \[PNU\]: [§45](https://ucum.org/ucum#para-45)<br>substance, procedure defined amount of an antigen – Limit of flocculation –<br> \[Lf\]: [§45](https://ucum.org/ucum#para-45)<br>sum of erythema diameters, amount of an allergen<br> calibrated through in-vivo testing based on the ID50EAL method of (intradermal<br> dilution for 50mm – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>temperature – degree Celsius – Cel: [§30](https://ucum.org/ucum#para-30)<br>temperature – degree Fahrenheit – \[degF\]: [§43](https://ucum.org/ucum#para-43)<br>temperature – degree Rankine – \[degR\]: [§43](https://ucum.org/ucum#para-43)<br>temperature – degree Réaumur – \[degRe\]: [§43](https://ucum.org/ucum#para-43)<br>temperature – kelvin – K: [§28](https://ucum.org/ucum#para-28)<br>tension, magnetic – Gilbert – Gb: [§33](https://ucum.org/ucum#para-33)<br>testing based on the ID50EAL method of (intradermal dilution for 50mm sum<br> of erythema diameters, amount of an allergen calibrated<br> through in-vivo – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>testing using the Stallergenes® method, amount of an allergen calibrated<br> through in-vivo – index of reactivity – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>textile<br> thread), linear mass density (of – Denier – \[den\]: [§43](https://ucum.org/ucum#para-43)<br>textile<br> thread), linear mass density (of – tex – tex: [§43](https://ucum.org/ucum#para-43)<br>thread),<br> linear mass density (of textile – Denier – \[den\]: [§43](https://ucum.org/ucum#para-43)<br>thread),<br> linear mass density (of textile – tex – tex: [§43](https://ucum.org/ucum#para-43)<br>through<br> in-vivo testing based on the ID50EAL method of (intradermal dilution for 50mm sum of erythema diameters,<br> amount of<br> an allergen calibrated – bioequivalent allergen unit – \[BAU\]: [§45](https://ucum.org/ucum#para-45)<br>through in-vivo testing using the Stallergenes® method, amount of an<br> allergen calibrated – index of reactivity – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>time –<br> day – d: [§31](https://ucum.org/ucum#para-31)<br>time – hour – h: [§31](https://ucum.org/ucum#para-31)<br>time – mean Gregorian month – mo\_g: [§31](https://ucum.org/ucum#para-31)<br>time – mean Gregorian year – a\_g: [§31](https://ucum.org/ucum#para-31)<br>time – mean Julian month – mo\_j: [§31](https://ucum.org/ucum#para-31)<br>time – mean Julian year – a\_j: [§31](https://ucum.org/ucum#para-31)<br>time – minute – min: [§31](https://ucum.org/ucum#para-31)<br>time –<br> month – mo: [§31](https://ucum.org/ucum#para-31)<br>time – second – s: [§28](https://ucum.org/ucum#para-28)<br>time – synodal month – mo\_s: [§31](https://ucum.org/ucum#para-31)<br>time – tropical year – a\_t: [§31](https://ucum.org/ucum#para-31)<br>time – week – wk: [§31](https://ucum.org/ucum#para-31)<br>time – year<br> – a: [§31](https://ucum.org/ucum#para-31)<br>transmission rate, signal – baud – Bd: [§48](https://ucum.org/ucum#para-48)<br>tuberculin, biologic activity of – tuberculin unit –<br> \[tb'U\]: [§45](https://ucum.org/ucum#para-45)<br>turbidity – Formazin Nephelometric Unit – \[FNU\]: [§47](https://ucum.org/ucum#para-47)<br>turbidity – Nephelometric Turbidity Unit – \[NTU\]: [§47](https://ucum.org/ucum#para-47)<br>unit, Ehrlich – Ehrlich unit – \[EU\]: [§45](https://ucum.org/ucum#para-45)<br>unit, arbitrary ELISA – ELISA unit – \[ELU\]: [§45](https://ucum.org/ucum#para-45)<br>using some reference standard, procedure defined amount of an allergen –<br> allergen unit – \[AU\]: [§45](https://ucum.org/ucum#para-45)<br>using the Stallergenes® method,<br> amount of an allergen calibrated through in-vivo testing – index of reactivity – \[IR\]: [§45](https://ucum.org/ucum#para-45)<br>velocity – knot – \[kn\_br\]: [§36](https://ucum.org/ucum#para-36)<br>velocity – knot – \[kn\_i\]: [§34](https://ucum.org/ucum#para-34)<br>velocity – velocity of light – \[c\]: [§32](https://ucum.org/ucum#para-32)<br>ventricular stroke work – gram-force meter per heartbeat – gf.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>ventricular stroke work, proportional to – gram meter per<br> heartbeat – g.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>view area in microscope – high<br> power field – \[HPF\]: [§45](https://ucum.org/ucum#para-45)<br>view area in microscope – low power<br> field – \[LPF\]: [§45](https://ucum.org/ucum#para-45)<br>viscosity, dynamic – Poise – P: [§33](https://ucum.org/ucum#para-33)<br>viscosity, kinematic – Stokes – St: [§33](https://ucum.org/ucum#para-33)<br>volume – board foot – \[bf\_i\]: [§34](https://ucum.org/ucum#para-34)<br>volume – bushel – \[bu\_br\]: [§38](https://ucum.org/ucum#para-38)<br>volume – cord – \[cr\_i\]: [§34](https://ucum.org/ucum#para-34)<br>volume – cubic foot – \[cft\_i\]: [§34](https://ucum.org/ucum#para-34)<br>volume – cubic inch – \[cin\_i\]: [§34](https://ucum.org/ucum#para-34)<br>volume – cubic yard – \[cyd\_i\]: [§34](https://ucum.org/ucum#para-34)<br>volume – cup – \[cup\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume – drop – \[drp\]: [§44](https://ucum.org/ucum#para-44)<br>volume<br> – fluid dram – \[fdr\_br\]: [§38](https://ucum.org/ucum#para-38)<br>volume – fluid ounce – \[foz\_br\]:<br> [§38](https://ucum.org/ucum#para-38)<br>volume – gallon – \[gal\_br\]: [§38](https://ucum.org/ucum#para-38)<br>volume – gill – \[gil\_br\]: [§38](https://ucum.org/ucum#para-38)<br>volume – liter – L: [§31](https://ucum.org/ucum#para-31)<br>volume –<br> liter – l: [§31](https://ucum.org/ucum#para-31)<br>volume – metric cup – \[cup\_m\]: [§37](https://ucum.org/ucum#para-37)<br>volume – metric tablespoon – \[tbs\_m\]: [§37](https://ucum.org/ucum#para-37)<br>volume – metric teaspoon – \[tsp\_m\]: [§37](https://ucum.org/ucum#para-37)<br>volume – minim – \[min\_br\]: [§38](https://ucum.org/ucum#para-38)<br>volume – peck – \[pk\_br\]: [§38](https://ucum.org/ucum#para-38)<br>volume – pint – \[pt\_br\]: [§38](https://ucum.org/ucum#para-38)<br>volume – quart – \[qt\_br\]: [§38](https://ucum.org/ucum#para-38)<br>volume – stere – st: [§47](https://ucum.org/ucum#para-47)<br>volume –<br> tablespoon – \[tbs\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume – teaspoon – \[tsp\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, dry – bushel – \[bu\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, dry – dry pint – \[dpt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, dry – dry quart – \[dqt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, dry – historical winchester gallon – \[gal\_wi\]: [§37](https://ucum.org/ucum#para-37)<br>volume, dry – peck – \[pk\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, fluid – Queen Anne's wine gallon – \[gal\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, fluid – barrel – \[bbl\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, fluid – cord – \[crd\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, fluid – fluid dram – \[fdr\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, fluid – fluid ounce – \[foz\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, fluid – gill – \[gil\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, fluid – metric fluid ounce – \[foz\_m\]: [§37](https://ucum.org/ucum#para-37)<br>volume, fluid – minim – \[min\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, fluid – pint – \[pt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>volume, fluid – quart – \[qt\_us\]: [§37](https://ucum.org/ucum#para-37)<br>water, depth of – fathom – \[fth\_i\]: [§34](https://ucum.org/ucum#para-34)<br>work, proportional to ventricular stroke – gram meter per heartbeat –<br> g.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>work, ventricular stroke – gram-force meter per<br> heartbeat – gf.m/{H.B.}: [§50](https://ucum.org/ucum#para-50)<br>x-ray attenuation – Hounsfield<br> unit – \[hnsf'U\]: [§44](https://ucum.org/ucum#para-44) |\
\
The following table lists example unit terms that are commonly used in\
medicine. Since the space of possible unit terms is infinite in theory\
and very large in practice, no attempt has been made on a systematic\
coverage of possible units. All necessary units can be built from the\
rules of _The Unified Code for Units of Measure_ and there is no need of a particular term to be\
enumerated in order to be valid.\
\
\
\
The source of this table is the HL7 V2.4 table of units in chapter 7\
with many corrections and some modifications.\
\
\
\
The columns are: (1) the case sensitive unit term and variants; (2) a\
plain text reading; (3) example use; (4) canonical form. The canonical\
form, consisting of 3 columns: (4.1) the magnitude value of the unit term in\
terms of the canonical unit; (4.2) a canonical unit term; (4.3) if\
applicable a special conversion function code.\
\
\
\
> **NOTE:**\
>  When a special conversion function is specified, the conversion takes\
>  more than multiplication with a factor. Implementers should consult\
>  the UCUM specification or the reference implementation for details on\
>  how to apply these conversion functions.\
\
The example unit terms are given with alternatives for the following\
reason. The source of the example terms is the HL7 version 2.4\
specification of chapter 7. To show the essential differences between\
UCUM and the HL7 version 2.4 codes, the first column shows unit terms\
that are as similar to the HL7 2.4 published terms as\
possible. However, the HL7 version 2.4 suggested unit terms were\
sometimes unnecessarily complicated (e.g., the unit 1 dyn cast as 10\
μN; decimal factors instead of the standard multiplier prefixes,\
nested parenthetical terms in divisions, etc.), even sometimes\
suggesting deprecated conventional habits (e.g., using annotations\
like "/g{HGB}" instead of just "/g".) Hence, the second column\
"alternative suggestions" lists equivalent unit terms that are either\
more straightforward or more appropriate or both.\
\
\
\
| unit term | suggested alternatives | name or "reading" | example use | canonical form value | canonical form unit | c.f. func |\
| --- | --- | --- | --- | --- | --- | --- |\
| /\[arb'U\] |  | per arbitrary unit |  | 1 | 1 |  |\
| /\[HPF\] |  | per high power field |  | 1 | 1 |  |\
| /\[iU\] |  | per international unit |  | 1 | 1 |  |\
| /{tot} |  | per total count |  | 1 | 1 |  |\
| /g{creat} | /g | per gram of creatinine |  | 1 | g-1 |  |\
| /g{HGB} | /g | per gram of hemoglobin |  | 1 | g-1 |  |\
| /g{tot'nit} | /g | per gram of total nitrogen |  | 1 | g-1 |  |\
| /g{tot'ptot} | /g | per gram of total protein |  | 1 | g-1 |  |\
| /g{wet'tis} | /g | per gram of wet tissue |  | 1 | g-1 |  |\
| /kg |  | per kilogram |  | 0.001 | g-1 |  |\
| /kg{body'wt} | /kg | per kilogram body weight |  | .001 | g-1 |  |\
| /L |  | per liter |  | 1000 | m-3 |  |\
| /m2 |  | per square meter |  | 1 | m-2 |  |\
| /min |  | per minute |  | 0.0166666666666667 | s-1 |  |\
| /mL |  | per milliliter |  | 1000000 | m-3 |  |\
| /mL |  | per milliliter |  | 1000000 | m-3 |  |\
| \[iU\]/d |  | international unit per day |  | 1.15740740740741 × 10-5 | s-1 |  |\
| \[iU\]/h |  | international unit per hour |  | 0.000277777777777778 | s-1 |  |\
| \[iU\]/kg |  | international unit per kilogram |  | 0.001 | g-1 |  |\
| \[iU\]/L |  | international unit per liter |  | 1000 | m-3 |  |\
| \[iU\]/min |  | international unit per minute |  | 0.0166666666666667 | s-1 |  |\
| \[iU\]/mL |  | international unit per milliliter |  | 1000000 | m-3 |  |\
| 10\*12/L | /pL | trillion per liter |  | 1015 | m-3 |  |\
| 10\*3.{RBC} | 10\*3 | thousand red blood cells |  | 1000 | 1 |  |\
| 10\*3/L | /mL | thousand per liter |  | 1000000 | m-3 |  |\
| 10\*3/mL | /uL | thousand per milliliter |  | 1000000000 | m-3 |  |\
| 10\*3/mm3 | /nL | thousand cubic millimeter | white blood cell count | 1000000000000 | m-3 |  |\
| 10\*6/L | /uL | million per liter |  | 1000000000 | m-3 |  |\
| 10\*6/mL | /nL | million per milliliter |  | 1000000000000 | m-3 |  |\
| 10\*6/mm3 | /pL | million per cubic millimeter |  | 1015 | m-3 |  |\
| 10\*9/L | /nL | billion per liter |  | 1000000000000 | m-3 |  |\
| 10\*9/mL | /pL | billion per milliliter |  | 1015 | m-3 |  |\
| 10\*9/mm3 | /fL | billion per cubic millimeter |  | 1018 | m-3 |  |\
| 10.L/(min.m2) | daL/min/m2 | ten liter per minute and square meter (dekaliter per minute and square meter) |  | 0.000166666666666667 | m.s-1 |  |\
| 10.L/min | daL/min | ten liter per minute (dekaliter per minute) |  | 0.000166666666666667 | m3.s-1 |  |\
| 10.uN.s/(cm5.m2) | dyn.s/(cm5.m2) dyn.s/cm5/m2 | dyne second per centimeter5 and square meter | systemic vascular resistance/body surface area | 100000000 | m-6.g.s-1 |  |\
| 10.uN.s/cm5 | dyn.s/cm5 | dyne second per centimeter5 | systemic vascular resistance | 100000000 | m-4.g.s-1 |  |\
| A/m |  | ampere per meter |  | 1 | m-1.s-1.C |  |\
| cm |  | centimeter |  | 0.01 | m |  |\
| cm\[H2O\] |  | centimeter H2O |  | 98066.5 | m-1.g.s-2 |  |\
| cm\[H2O\].s/L | cm\[H2O\]/(L/s) | centimeter H20 per ( liter per second ) (centimeter H20 second per liter) | mean pulmonary resistance | 98066500 | m-4.g.s-1 |  |\
| cm\[H2O\]/(s.m) | cm\[H2O\]/s/m | centimeter H20 per second and meter | pulmonary pressure time product | 98066.5 | m-2.g.s-3 |  |\
| cm2/s |  | square centimeter per second |  | 0.0001 | m2.s-1 |  |\
| dm2/s2 |  | square dekameter per square second |  | 0.01 | m2.s-2 |  |\
| fg |  | femtogram |  | 10-15 | g |  |\
| fL |  | femtoliter |  | 10-18 | m3 |  |\
| fmol |  | femtomole |  | 602214076 | 1 |  |\
| g.m |  | gram meter |  | 1 | m.g |  |\
| gf.m |  | gram-force meter |  | 9.80665 | m2.s-2.g |  |\
| gf.m/({hb}.m2) | gf.m/{hb}/m2 gf/m | gram-force meter per heartbeat and square meter |  | 9.80665 | s-2.g |  |\
| gf.m/{hb} | gf.m | gram-force meter per heartbeat | ventricular stroke work | 9.80665 | m2.s-2.g |  |\
| g/(8.h) |  | gram per 8-hour shift |  | 3.47222222222222 × 10-5 | g.s-1 |  |\
| g/(8.kg.h) | g/kg/(8.h) 125/h | gram per kilogram and 8-hour shift | mass dose rate per body mass | 3.47222222222222 × 10-8 | s-1 |  |\
| g/(kg.d) | g/kg/d | gram per kilogram and day | mass dose rate per body mass | 1.15740740740741 × 10-8 | s-1 |\
| g/(kg.h) | g/kg/h 10\*-3/h | gram per kilogram and hour | mass dose rate per body mass | 2.77777777777778 × 10-7 | s-1 |  |\
| g/(kg.min) | g/kg/min 10\*-3/min | gram per kilogram and minute | mass dose rate per body mass | 1.66666666666667 × 10-5 | s-1 |  |\
| g/d |  | gram per day |  | 1.15740740740741 × 10-5 | g.s-1 |  |\
| g/dL |  | gram per deciliter |  | 10000 | m-3.g |  |\
| g/h |  | gram per hour |  | 0.000277777777777778 | g.s-1 |  |\
| g/kg | 1/1000 | gram per kilogram | mass dose per body mass | 0.001 | 1 |  |\
| g/L |  | gram per liter |  | 1000 | m-3.g |  |\
| g/m2 |  | gram per square meter | mass does per body surface area | 1 | m-2.g |  |\
| g/min |  | gram per minute |  | 0.0166666666666667 | g.s-1 |  |\
| hL |  | hectoliter |  | 0.1 | m3 |  |\
| J/L |  | joule per liter | work of breathing | 1000000 | m-1.g.s-2 |  |\
| K/W |  | kelvin per watt |  | 0.001 | m-2.g-1.s3.K |  |\
| kat/kg |  | katal per kilogram |  | 6.02214076 × 1020 | g-1.s-1 |  |\
| kat/L |  | katal per liter |  | 6.02214076 × 1026 | m-3.s-1 |  |\
| kcal |  | kilocalorie |  | 4184000 | m2.g.s-2 |  |\
| kcal/(8.h) |  | kilocalorie per 8-hour shift |  | 145.277777777778 | m2.g.s-3 |  |\
| kcal/d |  | kilocalorie per day |  | 48.4259259259259 | m2.g.s-3 |  |\
| kcal/h |  | kilocalorie per hour |  | 1162.22222222222 | m2.g.s-3 |  |\
| kg |  | kilogram |  | 1000 | g |  |\
| kg.m/s |  | kilogram meter per second |  | 1000 | m.g.s-1 |  |\
| kg/(s.m2) |  | kilogram per second and square meter |  | 1000 | m-2.g.s-1 |  |\
| kg/h |  | kilogram per hour |  | 0.277777777777778 | g.s-1 |  |\
| kg/L |  | kilogram per liter |  | 1000000 | m-3.g |  |\
| kg/m2 |  | kilogram per square meter |  | 1000 | m-2.g |  |\
| kg/m3 |  | kilogram per cubic meter |  | 1000 | m-3.g |  |\
| kg/min |  | kilogram per minute |  | 16.6666666666667 | g.s-1 |  |\
| kg/mol |  | kilogram per mole |  | 1.66054018667494 × 10-21 | g |  |\
| kg/s |  | kilogram per second |  | 1000 | g.s-1 |  |\
| kPa |  | kilopascal |  | 1000000 | m-1.g.s-2 |  |\
| ks |  | kilosecond |  | 1000 | s |  |\
| L.s2/s | L.s | liter square second per second |  | 0.001 | m3.s |  |\
| L/(8.h) |  | liter per 8-hour shift |  | 3.47222222222222 × 10-8 | m3.s-1 |  |\
| L/(min.m2) |  | liter per minute and square meter | cardiac index (cardiac output per body surface area) | 1.66666666666667 × 10-5 | m.s-1 |  |\
| L/d |  | liter per day |  | 1.15740740740741 × 10-8 | m3.s-1 |  |\
| L/h |  | liter per hour |  | 2.77777777777778 × 10-7 | m3.s-1 |  |\
| L/kg |  | liter per kilogram |  | 10-6 | m3.g-1 |  |\
| L/min |  | liter per minute |  | 1.66666666666667 × 10-5 | m3.s-1 |  |\
| L/s |  | liter per second | peak expiratory flow | 0.001 | m3.s-1 |  |\
| lm/m2 |  | lumen per square meter |  | 1 | m-2.rad2.cd |  |\
| m/s |  | meter per second |  | 1 | m.s-1 |  |\
| m/s2 |  | meter per square second |  | 1 | m.s-2 |  |\
| m\[iU\]/mL |  | milli-international unit per milliliter |  | 1000 | m-3 |  |\
| m2 |  | square meter | body surface area | 1 | m2 |  |\
| m2/s |  | square meter per second |  | 1 | m2.s-1 |  |\
| m3/s |  | cubic meter per second |  | 1 | m3.s-1 |  |\
| mbar |  | millibar |  | 100000 | m-1.g.s-2 |  |\
| mbar.s/L | mbar/(L.s) | millibar per (liter per second) = millibar second per liter | expiratory resistance | 100000000 | m-4.g.s-1 |  |\
| meq |  | milliequivalent |  | 6.02214076 × 1020 | 1 |  |\
| meq/(8.h) |  | milliequivalent per 8-hour shift |  | 2.0910196875 × 1016 | s-1 |  |\
| meq/(8.h.kg) | meq/kg/(8.h) | milliequivalent per kilogram and 8-hour shift | dose rate per patient body mass | 20910196875000 | g-1.s-1 |  |\
| meq/(kg.d) | meq/kg/d | milliequivalent per kilogram per day | dose rate per patient body mass | 6970065625000 | g-1.s-1 |  |\
| meq/(kg.h) | meq/kg/h | milliequivalent per kilogram per hour | dose rate per patient body mass | 167281575000000 | g-1.s-1 |  |\
| meq/(kg.min) | meq/kg/min | milliequivalent per kilogram and minute | dose rate per patient body mass | 1.00368945 × 1016 | g-1.s-1 |  |\
| meq/d |  | milliequivalent per day |  | 6.970065625 × 1015 | s-1 |  |\
| meq/h |  | milliequivalent per hour |  | 1.67281575 × 1017 | s-1 |  |\
| meq/kg |  | milliequivalent per kilogram | dose per patient body mass | 6.02214076 × 1017 | g-1 |  |\
| meq/L |  | milliequivalent per liter |  | 6.02214076 × 1023 | m-3 |  |\
| meq/m2 |  | milliequivalent per square meter | dose per patient body surface area | 6.02214076 × 1020 | m-2 |  |\
| meq/min |  | milliequivalent per minute |  | 1.00368945 × 1019 | s-1 |  |\
| mg |  | milligram |  | 0.001 | g |  |\
| mg/(8.h) |  | milligram per 8-hour shift |  | 3.47222222222222 × 10-8 | g.s-1 |  |\
| mg/(8.h.kg) | mg/kg/(8.h) 10\*-6/(8.h) | milligram per kilogram and 8-hour shift | mass dose rate per patient body mass | 3.47222222222222 × 10-11 | s-1 |  |\
| mg/(kg.d) | mg/kg/d 10\*-6/d | milligram per kilogram and day | mass dose rate per patient body mass | 1.15740740740741 × 10-11 | s-1 |  |\
| mg/(kg.h) | mg/kg/h 10\*-6/h | milligram per kilogram and hour | mass dose rate per patient body mass | 2.77777777777778 × 10-10 | s-1 |  |\
| mg/(kg.min) | mg/kg/min 10\*-6/min | milligram per kilogram and minute | mass dose rate per patient body mass | 1.66666666666667 × 10-8 | s-1 |  |\
| mg/d |  | milligram per day |  | 1.15740740740741 × 10-8 | g.s-1 |  |\
| mg/dL |  | milligram per deciliter |  | 10 | m-3.g |  |\
| mg/h |  | milligram per hour |  | 2.77777777777778 × 10-7 | g.s-1 |  |\
| mg/kg | 10\*-6 | milligram per kilogram |  | 10-6 | 1 |  |\
| mg/L |  | milligram per liter |  | 1 | m-3.g |  |\
| mg/m2 |  | milligram per square meter | mass dose per patient body surface area | 0.001 | m-2.g |  |\
| mg/m3 |  | milligram per cubic meter |  | 0.001 | m-3.g |  |\
| mg/min |  | milligram per minute |  | 1.66666666666667 × 10-5 | g.s-1 |  |\
| mL |  | milliliter |  | 10-6 | m3 |  |\
| mL/({h'b}.m2) | mL/m2 | milliliter per heartbeat per square meter | ventricular stroke volume index | 10-6 | m |  |\
| mL/(8.h) |  | milliliter per 8-hour shift |  | 3.47222222222222 × 10-11 | m3.s-1 |  |\
| mL/(8.h.kg) | mL/kg/(8.h) | milliliter per kilogram and 8-hour shift | renal excretion volume rate per body mass | 3.47222222222222 × 10-14 | m3.g-1.s-1 |  |\
| mL/(kg.d) | mL/kg/d | milliliter per kilogram and day | renal excretion volume rate per body mass | 1.15740740740741 × 10-14 | m3.g-1.s-1 |  |\
| mL/(kg.h) | mL/kg/h | milliliter per kilogram and hour | renal excretion volume rate per body mass | 2.77777777777778 × 10-13 | m3.g-1.s-1 |  |\
| mL/(kg.min) | mL/kg/min | milliliter per kilogram and minute | respiratory volume rate per body mass | 1.66666666666667 × 10-11 | m3.g-1.s-1 |  |\
| mL/(min.m2) | mL/m2/min | milliliter per minute and square meter | volume per body surface area; oxygen consumption index | 1.66666666666667 × 10-8 | m.s-1 |  |\
| mL/{h'b} |  | milliliter per heartbeat | stroke volume | 10-6 | m3 |  |\
| mL/cm\[H2O\] |  | milliliter per centimeters H20 | dynamic lung compliance | 1.01971621297793 × 10-11 | m4.g-1.s2 |  |\
| mL/d |  | milliliter per day |  | 1.15740740740741 × 10-11 | m3.s-1 |  |\
| mL/h |  | milliliter per hour |  | 2.77777777777778 × 10-10 | m3.s-1 |  |\
| mL/kg |  | milliliter per kilogram | tidal volume per body mass | 10-9 | m3.g-1 |  |\
| mL/m2 |  | milliliter per square meter | volume per patient body surface area | 10-6 | m |  |\
| mL/mbar |  | milliliter per millibar | dynamic lung compliance | 10-11 | m4.g-1.s2 |  |\
| mL/min |  | milliliter per minute |  | 1.66666666666667 × 10-8 | m3.s-1 |  |\
| mL/s |  | milliliter per second |  | 10-6 | m3.s-1 |  |\
| mm |  | millimeter |  | 0.001 | m |  |\
| mm/h |  | millimeter hour |  | 2.77777777777778 × 10-7 | m.s-1 |  |\
| mm\[Hg\] |  | millimeter Mercury column |  | 133322 | m-1.g.s-2 |  |\
| mmol/(8.h) |  | millimole per 8-hour shift |  | 2.0910196875 × 1016 | s-1 |  |\
| mmol/(8.h.kg) | mmol/kg/(8.h) | millimole per kilogram and 8-hour shift | molar dose rate per patient body mass | 20910196875000 | g-1.s-1 |  |\
| mmol/(kg.d) | mmol/kg/d | millimole per kilogram and day | molar dose rate per patient body mass | 6970065625000 | g-1.s-1 |  |\
| mmol/(kg.h) | mmol/kg/h | millimole per kilogram and hour | molar dose rate per patient body mass | 167281575000000 | g-1.s-1 |  |\
| mmol/(kg.min) | mmol/kg/min | millimole per kilogram and minute | molar dose rate per patient body mass | 1.00368945 × 1016 | g-1.s-1 |  |\
| mmol/h |  | millimole per hour |  | 1.67281575 × 1017 | s-1 |  |\
| mmol/kg |  | millimole per kilogram | molar dose per patient body mass | 6.02214076 × 1017 | g-1 |  |\
| mmol/L |  | millimole per liter |  | 6.02214076 × 1023 | m-3 |  |\
| mmol/m2 |  | millimole per square meter | molar dose per patient body surface area | 6.02214076 × 1020 | m-2 |  |\
| mmol/min |  | millimole per minute |  | 1.00368945 × 1019 | s-1 |  |\
| mol/(kg.s) | mol/kg/s | mole per kilogram and second |  | 6.02214076 × 1020 | g-1.s-1 |  |\
| mol/kg |  | mole per Kilogram |  | 6.02214076 × 1020 | g-1 |  |\
| mol/L |  | mole per liter |  | 6.02214076 × 1026 | m-3 |  |\
| mol/m3 |  | mole per cubic meter |  | 6.02214076 × 1023 | m-3 |  |\
| mol/s |  | mole per second |  | 6.02214076 × 1023 | s-1 |  |\
| mosm/L |  | milliosmole per liter |  | 6.02214076 × 1023 | m-3 |  |\
| Ms |  | megasecond |  | 1000000 | s |  |\
| ms |  | millisecond |  | 0.001 | s |  |\
| mV |  | millivolt |  | 1 | m2.g.s-2.C-1 |  |\
| N.s |  | newton second |  | 1000 | m.g.s-1 |  |\
| ng |  | nanogram |  | 10-9 | g |  |\
| ng/(8.h) |  | nanogram per 8-hour shift |  | 3.47222222222222 × 10-14 | g.s-1 |  |\
| ng/(8.h.kg) | ng/kg/(8.h) | nanogram per kilogram and 8-hour shift | mass dose rate per patient body mass | 3.47222222222222 × 10-17 | s-1 |  |\
| ng/(kg.d) | ng/kg/d | nanogram per kilogram and day | mass dose rate per patient body mass | 1.15740740740741 × 10-17 | s-1 |  |\
| ng/(kg.h) | ng/kg/h | nanogram per kilogram and hour | mass dose rate per patient body mass | 2.77777777777778 × 10-16 | s-1 |  |\
| ng/(kg.min) | ng/kg/min | nanogram per kilogram and minute | mass dose rate per patient body mass | 1.66666666666667 × 10-14 | s-1 |  |\
| ng/d |  | nanogram per day |  | 1.15740740740741 × 10-14 | g.s-1 |  |\
| ng/h |  | nanogram per hour |  | 2.77777777777778 × 10-13 | g.s-1 |  |\
| ng/kg |  | nanogram per kilogram | mass dose per patient body mass | 10-12 | 1 |  |\
| ng/L |  | nanogram per liter |  | 10-6 | m-3.g |  |\
| ng/m2 |  | nanogram per square meter | mass dose per patient body surface area | 10-9 | m-2.g |  |\
| ng/min |  | nanogram per minute |  | 1.66666666666667 × 10-11 | g.s-1 |  |\
| ng/mL |  | nanogram per milliliter |  | 0.001 | m-3.g |  |\
| ng/s |  | nanogram per second |  | 10-9 | g.s-1 |  |\
| nkat |  | nanokatal |  | 602214076000000 | s-1 |  |\
| nm |  | nanometer |  | 10-9 | m |  |\
| nmol/s |  | nanomole per second |  | 602214076000000 | s-1 |  |\
| ns |  | nanosecond |  | 10-9 | s |  |\
| Ohm.m |  | ohm meter |  | 1000 | m3.g.s-1.C-2 |  |\
| osm/kg |  | osmole per kilogram |  | 6.02214076 × 1020 | g-1 |  |\
| osm/L |  | osmole per liter |  | 6.02214076 × 1026 | m-3 |  |\
| pA |  | picoampere |  | 10-12 | s-1.C |  |\
| pg |  | picogram |  | 10-12 | g |  |\
| pg/L |  | picogram per liter |  | 10-9 | m-3.g |  |\
| pg/mL |  | picogram per milliliter |  | 10-6 | m-3.g |  |\
| pkat |  | picokatal |  | 602214076000 | s-1 |  |\
| pm |  | picometer |  | 10-12 | m |  |\
| pmol |  | picomole |  | 602214076000 | 1 |  |\
| ps |  | picosecond |  | 10-12 | s |  |\
| pT |  | picotesla |  | 10-9 | g.s-1.C-1 |  |\
| u\[iU\] |  | micro international unit |  | 10-6 | 1 |  |\
| ueq |  | microequivalents |  | 6.02214076 × 1017 | 1 |  |\
| ug |  | microgram |  | 10-6 | g |  |\
| ug/(8.h) |  | microgram per 8-hour shift |  | 3.47222222222222 × 10-11 | g.s-1 |  |\
| ug/(kg.d) | ug/kg/d | microgram per kilogram and day | mass dose rate per patient body mass | 1.15740740740741 × 10-14 | s-1 |  |\
| ug/(kg.h) | ug/kg/h | microgram per kilogram and hour | mass dose rate per patient body mass | 2.77777777777778 × 10-13 | s-1 |  |\
| ug/(kg.min) | ug/kg/min | microgram per kilogram and minute | mass dose rate per patient body mass | 1.66666666666667 × 10-11 | s-1 |  |\
| ug/d |  | microgram per day |  | 1.15740740740741 × 10-11 | g.s-1 |  |\
| ug/dL |  | microgram per deciliter |  | 0.01 | m-3.g |  |\
| ug/g |  | microgram per gram |  | 10-6 | 1 |  |\
| ug/h |  | microgram per hour |  | 2.77777777777778 × 10-10 | g.s-1 |  |\
| ug/kg |  | microgram per kilogram |  | 10-9 | 1 |  |\
| ug/kg/(8.h) |  | microgram per kilogram and 8-hour shift | mass dose rate per patient body mass | 3.47222222222222 × 10-14 | s-1 |  |\
| ug/L |  | microgram per liter |  | 0.001 | m-3.g |  |\
| ug/m2 |  | microgram per square meter | mass dose per patient body surface area | 10-6 | m-2.g |  |\
| ug/min |  | microgram per minute |  | 1.66666666666667 × 10-8 | g.s-1 |  |\
| ukat |  | microkatal |  | 6.02214076 × 1017 | s-1 |  |\
| um |  | micrometer |  | 10-6 | m |  |\
| umol |  | micromole |  | 6.02214076 × 1017 | 1 |  |\
| umol/d |  | micromole per day |  | 6970065625000 | s-1 |  |\
| umol/L |  | micromole per liter |  | 6.02214076 × 1020 | m-3 |  |\
| umol/min |  | micromole per minute |  | 1.00368945 × 1016 | s-1 |  |\
| us |  | microsecond |  | 10-6 | s |  |\
| uV |  | microvolt |  | 0.001 | m2.g.s-2.C-1 |  |\
\
Table\
26: Example Unit Terms by Term\
\
\
See https://unitsofmeasure.org/license for the full UCUM License and Copyright notice.\
\
\
\
## Endnotes\
\
1. \[ [source](https://ucum.org/ucum#fn-src1)\]\
\
    Interestingly the authors of ENV 12435 forgot to include\
    superscripts in the minimum requirements as given by subclause 7.1.4\
    for which they do not specify an alternative.\
\
\
2. \[ [source](https://ucum.org/ucum#fn-src2)\]\
\
    A more extensive introduction into this semantics of units can be\
    found in: Schadow G, McDonald CJ et al: Units of Measure in Clinical\
    Information Systems; JAMIA 6(2); Mar/Apr 1999;\
    p. 151–162.\
\
\
3. \[ [source](https://ucum.org/ucum#fn-src3)\]\
\
    see the section about style in [§§12ff](https://ucum.org/ucum#para-12), to find out\
    how square brackets are actually used. Note, however, that the user\
    has no choice about square bracket symbols, as these are fixed in the\
    list of atomic unit symbols.
